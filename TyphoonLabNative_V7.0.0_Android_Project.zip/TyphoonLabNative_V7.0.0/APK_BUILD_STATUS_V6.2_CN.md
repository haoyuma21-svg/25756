# Typhoon Lab V6.2.0 APK 构建状态

## 目标产物

- APK：`dist/TyphoonLab-V6.2.0-debug.apk`
- SHA-256：`dist/TyphoonLab-V6.2.0-debug.apk.sha256`
- 包名：`com.typhoonlab.mobile`
- versionCode：`63`
- targetSdk：`36`
- minSdk：`26`
- 类型：Debug 侧载测试包，不是商店 Release 包。

## 本次真实构建结果

尚未生成 APK。已执行：

```bash
./tools/build_debug_apk.sh
```

真实返回：

```text
BLOCKED: 未找到 Android SDK。请设置 ANDROID_SDK_ROOT/ANDROID_HOME，或在 local.properties 写入 sdk.dir。
APK_BUILD_EXIT_CODE=20
```

环境检查也未找到 `sdkmanager`、`aapt2`、`apksigner`、`zipalign`、`adb`。Gradle 8.14.6 首次下载需要联网，但本次容器无法解析 `services.gradle.org`。

因此本项目没有提供虚假的 APK 文件，也没有把 ZIP 项目包改名为 APK。

## 本机生成 APK

### Windows

```powershell
$env:ANDROID_SDK_ROOT = "$env:LOCALAPPDATA\Android\Sdk"
.\tools\build_debug_apk.ps1
```

### Linux / macOS / Git Bash

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"
./tools/build_debug_apk.sh
```

需要 Android SDK Platform 36、Build-Tools 35.0.0 或更新版本、Android NDK（含 `llvm-readelf`）、Python 3、JDK 17+、Gradle 下载和 Maven 仓库网络。脚本会检查包名/版本、签名、ZIP 16 KB 对齐和每个 `.so` 的 ELF LOAD 段；任何检查缺失或失败都会终止，不会将产物标为构建成功。

## 构建后安装到手机

启用手机 USB 调试并授权电脑后，运行 `tools/install_debug_apk.ps1`（Windows）或 `tools/install_debug_apk.sh`（Linux/macOS）。工具会要求仅一台已授权设备，或通过序列号显式选定设备；只执行 `adb install -r`，不会自动卸载。

## GitHub Actions 云构建

工作流：`.github/workflows/android-apk.yml`，使用 checkout v7.0.1、setup-java v6.1.0、setup-android v4.0.4、upload-artifact v7.0.2。上传工程至自己有权限的 GitHub 仓库后，在 Actions 中手动运行 `Build Typhoon Lab Android APK`，或推送到 main/master。成功后从 workflow 的 Artifacts 下载 `TyphoonLab-V6.2.0-debug-apk`。

本工作流在本次会话中尚未运行；不能提前保证 MapLibre 预编译 native libraries 的 ELF 16 KB 检查一定通过。若检查失败，应升级到实际提供 16 KB ELF 对齐的 MapLibre 依赖版本，再重新构建并验收。

## 安装与覆盖升级注意

Debug APK 由构建机本地 debug keystore 签名。只有签名证书与手机中旧版 APK 一致时，Android 才允许直接覆盖安装。不同电脑的 debug 证书通常不一致。升级前请导出游戏存档并备份 PMTiles 影像包。正式长期发布应使用同一把自有 Release keystore 签署所有版本；不要把私钥提交到仓库或 CI 日志。
