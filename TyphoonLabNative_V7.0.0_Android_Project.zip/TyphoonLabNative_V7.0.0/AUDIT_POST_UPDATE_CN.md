# V6.0 更新后全量排查报告

检查对象：Typhoon Lab V6.0 源码工作树（功能与优化更新完成后）

## 更新后检查项目

| 检查项 | 结果 | 说明 |
|---|---|---|
| Gradle 目标版本 | PASS（配置） | compileSdk 36、targetSdk 36、versionCode 60 |
| Android 16 edge-to-edge | PASS（源码） | WindowCompat + systemBars/displayCutout inset |
| 大屏/可调整窗口 | PASS（源码） | resizeableActivity、smallestScreenSize、screenLayout、宽度断点布局 |
| 返回键回调 | PASS（源码） | AndroidX dispatcher，避免旧式 onBackPressed 覆写与回调递归 |
| MapView 生命周期 | PASS（源码审查） | started/resumed 状态标记，统一销毁入口 |
| 状态恢复 | PASS（源码） | 完整模拟 JSON 不进入 Binder Bundle；读取自动存档，失败则创建演练风暴 |
| AtomicFile 存档 | PASS（源码审查） | 自动/手动大存档独立原子文件；读取支持备份恢复与旧 SharedPreferences 迁移 |
| 固定步长物理 | PASS | 30 Hz 累计器；与显示刷新频率解耦 |
| 物理循环复用缓冲 | PASS（源码审查+核心测试） | 每步复用活动风暴 scratch buffer；公共环境项每步只计算一次 |
| 渲染 LOD | PASS（源码审查） | 按性能模式/风暴数量调整圆环、雨带顶点和历史轨迹抽稀 |
| 集合预报 RNG 隔离 | PASS | 独立 forecastRandom |
| 活动风暴限制 | PASS | 最多 12 个活动风暴 |
| 存档边界 | PASS（源码审查） | 8 MiB JSON、风暴/轨迹/事件/回放上限和数值范围 |
| 全球气象中心 | PASS（核心测试） | 七海盆、活动风暴和风险汇总；日期变更线回归通过 |
| MapPack 下载 | PASS（既有源码审查） | HTTPS、Range 起点/终点/总长检查、identity 编码、残片保留 |
| MapPack 导入中断 | PASS（源码审查） | 检查线程中断，清理临时文件，保留旧影像包 |
| 后台 UI 生命周期 | PASS（源码审查） | postUiIfAlive 过滤已结束 Activity 的延迟回调 |
| 60 GB 配额 | PASS（源码审查） | 十进制 Long 配额；包含已安装包、未完成下载和本次文件 |
| Kotlin 核心编译 | PASS | StormEngine + GlobalCommandCenter 独立编译与 smoke test |
| Kotlin parser scan | PASS（语法） | 未发现 expecting/unexpected tokens；缺少 Android/MapLibre 类型依赖，不能做完整语义编译 |
| Android 资源 XML | PASS | 4 个 XML 文件通过解析 |
| Shell 脚本语法 | PASS | Gradle wrapper、PMTiles 制作和 16 KB 检查脚本通过 `bash -n` |

## 引擎回归测试记录

测试使用真实 `StormEngine.kt` 与 `GlobalCommandCenter.kt`；只为 `org.json` 提供临时测试 stub，不覆盖 JSON 解析/恢复路径：

- 30、60、90、120 Hz 输入各运行 10 秒。
- 四种帧率结果均约 1.333333333 小时模拟时间，300 个 30 Hz 物理步。
- 路径和风速在设定容差内一致。
- 对一份模拟生成 32 条集合路径，不改变物理 RNG 后续结果。
- 同时活动风暴 12 个上限有效；第 13 个副风暴请求被拒绝。
- 全球指挥中心 7 个海盆统计与活动风暴数量边界有效。
- 东经 181°/西经 179°附近的北半球风暴正确归类到西北太平洋；南半球日期变更线风暴归入澳洲—南太平洋。
- 2 秒卡顿输入被上限保护并计入被丢弃墙钟时间。

结果：`V6 CORE SMOKE TEST PASSED`。

## 更新后发现并修正

1. 大型自动/手动存档原先保存在 SharedPreferences XML，迁移到 AtomicFile 独立文件。
2. AtomicFile 读取支持备份恢复，并将 V5.x/V6.0 偏好存档迁移到新文件。
3. Activity 销毁后后台下载/导入回调不再触碰已销毁 UI。
4. 地图包导入循环响应线程中断，避免退出时继续复制大型文件。
5. 高密度地图渲染使用 LOD 和历史轨迹抽稀；避免重复写风暴中心 GeoJSON。
6. 全球态势日期变更线海盆分类修正。

## 本轮尚未执行的设备级验证

- Gradle 完整 Android 编译 / APK / AAB：需要 Android SDK 与依赖下载环境。
- 最终 `.so` 的 16 KB ELF LOAD alignment：需要真实 APK 后运行检查工具。
- Android 16 真机 / 16 KB 页设备启动：未执行。
- 真正 GPU 帧率、温度、功耗、长时间压力：未执行。
