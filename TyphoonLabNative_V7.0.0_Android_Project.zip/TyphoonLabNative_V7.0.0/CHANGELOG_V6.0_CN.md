# Typhoon Lab V6.0「全球气象指挥中心」更新日志

版本：`6.0.0-global-weather-command`  
versionCode：`60`  
compileSdk / targetSdk：`36 / 36`  
最低系统：Android 8.0（API 26）

## 主要更新：全球气象指挥中心

- 七大热带气旋海盆模拟态势：西北太平洋、东北太平洋、北大西洋、北印度洋、南印度洋、澳洲—南太平洋、南大西洋。
- 汇总活动风暴数量、最强持续风速、最低中心气压、最高模拟风险。
- 支持按海盆定位、在指定海盆创建演练风暴、从全球风暴列表切换主控风暴。
- 修正国际日期变更线附近经度环绕导致的西北太平洋/东北太平洋海盆误分类。
- 所有态势卡片明确标注为本地模拟，不会将模拟结果冒充实时观测或官方预警。

## 两次模拟引擎优化

### 引擎优化 1：固定物理步长与显示帧率解耦

- 物理积分固定为 30 Hz；Android `Choreographer` 负责显示刷新，两条时钟分离。
- 物理累计器吸收 30/60/90/120 Hz 的帧间隔差异，降低不同刷新率设备造成的模拟漂移。
- 单帧追赶步数、墙钟时间均有限制；应用从后台恢复时不会无限追赶而长时间卡死。
- `simulationSpeed` 只控制模拟时钟，`motionMultiplier` 单独控制平移速度。

### 引擎优化 2：减少物理循环短命对象和重复计算

- 使用复用的活动风暴缓冲区，不再每一个 30 Hz 物理步都创建过滤列表。
- 海温、海洋热含量、湿度和风切变的公共环境项每步只计算一次，再应用到各风暴。
- 集合预报使用独立随机数流，生成集合成员不会扰动主模拟随机序列。
- 活动风暴、保留风暴、单风暴轨迹、事件日志、回放帧和存档大小均有硬上限。

## 地图渲染优化

- 风圈环形几何按性能模式和活动风暴数量动态调整顶点数。
- 螺旋雨带在省电/均衡/高性能模式下使用不同细分等级。
- 历史轨迹显示前抽稀，避免在高密度历史路径下反复提交数千个冗余点。
- 风暴中心位置 GeoJSON 与复杂风场/雨带更新分离；复杂图层约 12 Hz，位置更新上限约 60 Hz。

## Android 16 与大屏适配

- compileSdk / targetSdk 升级到 API 36。
- edge-to-edge 系统栏安全区处理，覆盖 system bars 和 display cutout。
- Activity 可调整大小，监听方向、屏幕尺寸、最小尺寸和 screenLayout 变化。
- 使用 AndroidX `OnBackPressedDispatcher`，避免旧式返回键覆盖。
- MapView 生命周期统一状态跟踪，避免重复转发生命周期。
- 进程重建只将小型 UI 状态放入系统 Bundle；完整模拟 JSON 放在应用私有存档。
- 使用 MapLibre Native OpenGL 后端；不宣称未扫描的最终 `.so` 已通过 16 KB ELF 对齐。

## 稳定性与存档修复

- 自动存档和手动存档从 SharedPreferences 大文本迁移至 `AtomicFile`，减少 SharedPreferences XML 被大型 JSON 撑大的风险，并在首次读取时兼容迁移 V5.x/V6.0 旧偏好设置存档。
- AtomicFile 读取可恢复写入中断时的备份文件；写入时 `fsync` 并提交原子文件。
- 下载/导入后台任务通过 Activity 生命周期安全的 UI dispatcher 更新界面，Activity 已销毁时不再弹出窗口。
- 地图包导入响应线程中断，Activity 关闭后取消复制并清理临时文件，原影像包保持不变。
- 修正风圈 ring 几何重复闭合点。
- 修正日期变更线海盆分类。
- 保留 HTTPS、Range 续传、PMTiles v3 头校验与 60 GB 地图资源总配额。

## 测试与边界说明

- StormEngine + GlobalCommandCenter 独立 Kotlin smoke test：通过。
- 30/60/90/120 Hz 输入各运行 10 秒：模拟时长与路径一致，均完成 300 个 30 Hz 物理步。
- 32 成员集合 RNG 隔离：通过。
- 12 个活动风暴硬上限：通过。
- 七海盆聚合与日期变更线归类：通过。
- 异常卡顿追赶上限：通过。
- MainActivity/MapPackManager Kotlin parser 扫描：未发现语法解析错误；由于当前环境缺少 Android SDK/MapLibre 依赖，不能视为完整类型编译。
- AndroidManifest 和资源 XML：解析通过；shell 脚本语法检查通过。
- 当前环境没有 Android SDK/完整 Gradle 缓存，未生成 APK/AAB；未做 Android 16 真机、GPU FPS、折叠屏和超大地图下载真机测试。
- 最终 APK 的所有 `.so` 仍须执行 16 KB zip/ELF 对齐检查，并在 16 KB 页设备安装运行。
- 全球指挥中心是本机模拟态势，不是实时全球观测系统；风暴模型为教学/娱乐用途。
- 不捆绑全球高清卫星影像，用户需导入有使用权的 PMTiles v3 地图数据。
