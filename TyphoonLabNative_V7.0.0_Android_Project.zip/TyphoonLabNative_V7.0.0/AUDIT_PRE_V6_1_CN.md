# V6.1 更新前超级大排查报告

审查对象：Typhoon Lab V6.0.0 源码树（package `com.typhoonlab.mobile`）  
审查日期：2026-10-31  
审查方式：Gradle/Manifest/XML 静态核对、Kotlin 源码阅读、已有 StormEngine 独立回归测试、构建工具链探测。

## 基线结果

| 项目 | 结果 | 说明 |
|---|---|---|
| compileSdk / targetSdk | 通过 | 均为 36，面向 Android 16 |
| minSdk | 通过 | 26（Android 8.0） |
| 网络明文策略 | 通过 | `usesCleartextTraffic=false`，地图下载器强制 HTTPS |
| Internet 权限 | 通过 | 已声明 INTERNET 与 ACCESS_NETWORK_STATE |
| Edge-to-Edge / Back | 通过（静态） | 使用 WindowCompat insets 和 AndroidX OnBackPressedDispatcher |
| 可调整窗口 | 通过（静态） | Activity 声明 resizeable，窗口尺寸变化时更新主要 UI |
| Gradle/AGP/Kotlin 版本范围 | 通过（官方矩阵） | AGP 8.13.2、Gradle 8.14.6、KGP 2.3.21；KGP 2.3 支持 AGP 8.2.2–9.0.0，AGP 8.13.2 内置 R8 8.13.19 支持 Kotlin 2.3 |
| StormEngine 回归 | 通过 | 30/60/90/120 Hz 输入一致；固定物理步、ensemble 随机数隔离、12 风暴上限、32×高载、海盆分区、日期变更线、滞后保护均通过 |
| 地图包输入边界 | 部分通过 | 流式复制、PMTiles v3 文件头、HTTPS、Range 校验已有实现；仍需真实服务器/Android SAF/大文件端到端测试 |
| 实时气象数据 | 未实现 | V6.0 全球指挥中心只统计本地模拟风暴，未获取外部天气模型数据 |
| APK 构建环境 | 阻塞 | JDK 21、kotlinc 可用；Android SDK、sdkmanager、aapt2、apksigner 缺失；Gradle 8.14.6 wrapper 未缓存，下载因 DNS `Could not resolve host: services.gradle.org` 失败 |
| 16 KB ELF / 真机性能 | 未验证 | 没有最终 APK 和 Android 真机，不能给出通过结论 |

## 发现与 V6.1 处置

1. 全球气象指挥中心的指标仅来自模拟器，容易被用户误认为实时气象态势。V6.1 增加独立的“气象环境探针”，读取明确标注为数值模式/预报的天气和海洋网格数据，并与模拟参数分栏显示。
2. 外部数据请求不能在 UI 线程执行。V6.1 将使用后台单线程执行器、连接/读取超时、响应体字节上限、HTTPS 限制、异常回退及用户主动触发，禁止自动高频请求。
3. 海洋接口在部分位置/时段可能无可用值。V6.1 将海温、浪高、海平面和海流字段全部作为可空数据，不使用 0 值冒充观测。
4. 天气模型网格值不是台风中心实测值。V6.1 界面明确显示请求坐标、服务返回网格坐标、模式时间、数据源与限制，且不会自动把天气模型值写入全局模拟环境。
5. APK 不能在缺少 Android SDK/Build Tools/Gradle 依赖的当前容器中实际构建。V6.1 增加可复现的 Debug APK 构建与最终 APK 16 KB 原生库检查脚本，并记录当前构建阻塞，不生成伪 APK。

## 依据

- Android 16 目标 API 36 行为变更与大屏自适应要求：<https://developer.android.com/about/versions/16/behavior-changes-16>
- Open-Meteo Forecast API：<https://open-meteo.com/en/docs>
- Open-Meteo Marine API：<https://open-meteo.com/en/docs/marine-weather-api>
