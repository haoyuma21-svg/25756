# 台风实验室 V7.0.0（Typhoon Lab Android Native）

**本项目只开发 Android 手机和平板应用。** Windows 脚本只负责构建/安装 Android APK；GitHub Actions 只承担 Android APK 云端编译，不是 Windows/macOS/Linux 桌面应用。

- 版本：`7.0.0-android16-xiaomi`（`versionCode=70`）
- 包名：`com.typhoonlab.mobile`（升级覆盖仍要求签名证书一致）
- 最低系统：Android 8.0 / API 26
- 编译/目标：Android SDK 36 / Android 16
- 重点适配：Android 15（API 35）、Android 16（API 36）
- 小米系统：澎湃 OS / HyperOS、MIUI（通过公开 Build 信息识别）
- 引擎：Kotlin + MapLibre Native Android + PMTiles v3
- 离线地图容量：60,000,000,000 字节应用配额；APK 不包含全球地图数据

## V7.0 大更新

V7 情景挑战中心包含五个任务：暖海快速增强、强风切变生存、近岸登陆、藤原效应双风暴、多风暴协同监测。每项任务有独立的随机种子、环境条件、初始风暴编队和可追踪目标。开始挑战会重置当前模拟运行状态，但不会删除用户已保存的手动存档或地图包。

五项中等更新：挑战状态保存；藤原效应相互作用步数统计；集合预报离散度摘要；自适应地图几何细节；一级挑战菜单与进度复盘。

四项小更新：V7 版本元数据；首页文案；Windows 构建/安装器版本检查；无需 Android Studio 的手机端云构建安装流程。

详细变化见 `CHANGELOG_V7.0_CN.md`；功能操作见 `USER_MANUAL_V7_CN.md`。

## 推荐安装方式（没有 Android Studio 也可以）

优先使用 `PHONE_INSTALL_NO_ANDROID_STUDIO_V7_CN.md` 中的 GitHub Actions 云端构建流程：工程上传到自己的 GitHub 仓库后，在手机浏览器打开 Actions、运行 `Typhoon Lab Android APK`、下载 Artifact ZIP、解压后点击 APK 安装。该方法不要求手机或电脑安装 Android Studio/SDK/ADB，但要求有 GitHub 账号、仓库和网络访问。该指南另附 Termux 手机本机编译备选法（第三方方案，尚未对本项目实机验证）。

## Windows 本地命令行构建

Windows 用户可以不安装 Android Studio 图形界面，改用 JDK 17 + Android SDK Command-line Tools + Platform 36 + Build-Tools 36 + NDK + Python 3，然后运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\build_debug_apk.ps1
```

如需连接 USB 安装，可运行：

```bat
tools\install_one_click.bat
```

本地构建输出为 `dist/TyphoonLab-V7.0.0-debug.apk` 与 SHA-256 文件。脚本检查 APK 包名/版本、签名、ZIP 16 KB 对齐和 native ELF 16 KB LOAD 对齐；检查失败时拒绝认定构建成功。

## 手机安装注意事项

1. 下载 ZIP 后先解压，点击 `.apk`，不是点击 ZIP 或 Kotlin 文件。
2. 只为实际下载来源（浏览器/文件管理器）临时允许“安装未知应用”。
3. Debug APK 使用调试签名。不同电脑/云端可能产生不同 Debug 证书，可能无法覆盖安装旧版。覆盖失败时先导出模拟存档和备份离线地图包，再自行判断是否卸载旧版。
4. GitHub Actions Debug APK 不是 Google Play 发布版。正式持续升级应配置专用签名证书和安全 Secrets，不能把密钥提交到仓库。

## 引擎与性能边界

- 物理模拟固定 30 Hz，渲染独立；省电、热状态、风暴数量和帧回调状态只会降低非关键地图细节更新。
- 地图风圈几何细节动态分级，不能据此承诺固定 FPS。真实 FPS/耗电/发热必须在目标手机实测。
- 最大活动风暴数保持 12。
- 集合预报离散度是沙盒几何统计，不是官方预报概率。

## 当前构建状态

开发容器没有 Android SDK/Build-Tools/NDK/ADB/apksigner/zipalign。已实际尝试 `./gradlew --no-daemon clean assembleDebug`，但 Gradle 分发下载因 DNS 无法解析 `services.gradle.org` 失败；因此本轮没有生成 APK，也没有设备可供安装。GitHub 云端工作流已加入项目，需用户先上传工程到自己的 GitHub 仓库并触发 Actions。

## 免责声明

本应用是教学与娱乐用途的台风沙盒。台风路径、强度、风圈、降雨、风暴潮、登陆掩膜及风险指数均为简化模型，不能作为真实天气预警、疏散或专业防灾决策依据。
