#!/usr/bin/env bash
# Syntax-only parser scan for the Android source tree when Android SDK dependencies are absent.
# This does NOT type-check Android/AndroidX/MapLibre APIs and is not an app build.
set -euo pipefail
: "${JAVA_OPTS:=-Xmx1536M -Xms128M}"
export JAVA_OPTS
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
if [[ -z "$KOTLINC" ]]; then
  echo "SKIP: kotlinc unavailable." >&2
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find "$ROOT/app/src/main/java" -name '*.kt' -type f | sort)
KOTLIN_EXTRA=()
if "$KOTLINC" -version 2>&1 | grep -q 'kotlinc-jvm 1\.9'; then KOTLIN_EXTRA=(-Xuse-k2); fi
set +e
"$KOTLINC" "${KOTLIN_EXTRA[@]}" "${SOURCES[@]}" -d "$TMP/parser-scan.jar" >"$TMP/compiler.log" 2>&1
RC=$?
set -e
# Android/AndroidX/MapLibre classpath is deliberately absent here; unresolved references are expected.
# Parser errors are independent and must be absent.
if grep -E 'error: (expecting|unexpected tokens|missing .*\)|missing .*\}|missing .*\]|unclosed comment|unclosed string literal)' "$TMP/compiler.log"; then
  echo "FAIL: Kotlin parser diagnostics detected." >&2
  exit 1
fi
if [[ "$RC" -eq 0 ]]; then
  echo "PASS: Kotlin sources compiled without additional Android classpath." 
else
  if ! grep -q 'unresolved reference: android\|unresolved reference: androidx\|unresolved reference: org.maplibre' "$TMP/compiler.log"; then
    echo "FAIL: Kotlin compilation failed for reasons not identified as missing Android platform dependencies." >&2
    sed -n '1,120p' "$TMP/compiler.log" >&2
    exit 1
  fi
  echo "PASS: No Kotlin parser syntax diagnostics; semantic compilation blocked by missing Android/AndroidX/MapLibre dependencies (expected in this environment)."
fi
