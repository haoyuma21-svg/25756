$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $Root

$Sdk = $env:ANDROID_SDK_ROOT
if ([string]::IsNullOrWhiteSpace($Sdk)) { $Sdk = $env:ANDROID_HOME }
if ([string]::IsNullOrWhiteSpace($Sdk)) { $Sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path $Sdk)) { throw "未找到 Android SDK。请使用 Android SDK Command-line Tools 安装 API 36、Build-Tools、Platform-Tools 和 NDK，并设置 ANDROID_SDK_ROOT。" }
$env:ANDROID_SDK_ROOT = $Sdk

& (Join-Path $Root 'gradlew.bat') --no-daemon clean assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Gradle 构建失败，退出代码 $LASTEXITCODE。" }

$Apk = Join-Path $Root 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $Apk)) { throw "没有生成预期 APK：$Apk" }
$BuildToolsRoot = Join-Path $Sdk 'build-tools'
$BuildTools = Get-ChildItem $BuildToolsRoot -Directory | Sort-Object { try { [version]$_.Name } catch { [version]'0.0' } } -Descending | Select-Object -First 1
if (-not $BuildTools) { throw '未安装 Android SDK Build-Tools。' }
$ApkSigner = Join-Path $BuildTools.FullName 'apksigner.bat'
$ZipAlign = Join-Path $BuildTools.FullName 'zipalign.exe'
$Aapt = Join-Path $BuildTools.FullName 'aapt.exe'
if (-not (Test-Path $ApkSigner) -or -not (Test-Path $ZipAlign) -or -not (Test-Path $Aapt)) { throw 'Build-Tools 缺少 aapt、apksigner 或 zipalign。' }
$Badging = & $Aapt dump badging $Apk
if ($LASTEXITCODE -ne 0) { throw 'aapt 无法读取 APK Manifest，APK 可能损坏。' }
$BadgingText = $Badging -join "`n"
if ($BadgingText -notmatch "package: name='com\.typhoonlab\.mobile' versionCode='70' versionName='7\.0\.0-android16-xiaomi'") { throw 'APK 包名、versionCode 或 versionName 不匹配 V7.0.0。' }
if ($BadgingText -notmatch "sdkVersion:'26'" -or $BadgingText -notmatch "targetSdkVersion:'36'") { throw 'APK minSdk/targetSdk 与项目设置不匹配。' }
& $ApkSigner verify --verbose --print-certs $Apk
if ($LASTEXITCODE -ne 0) { throw 'APK 签名校验失败。' }
& $ZipAlign -c -P 16 -v 4 $Apk
if ($LASTEXITCODE -ne 0) { throw 'APK 16 KB ZIP 对齐检查失败。' }

$Readelf = $env:READELF
if ([string]::IsNullOrWhiteSpace($Readelf)) {
    $Readelf = Get-ChildItem (Join-Path $Sdk 'ndk') -Filter 'llvm-readelf.exe' -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match 'windows-x86_64\bin\llvm-readelf\.exe$' } |
        Select-Object -First 1 -ExpandProperty FullName
}
if ([string]::IsNullOrWhiteSpace($Readelf)) { throw '未找到 NDK llvm-readelf；为避免漏检 16 KB ELF 对齐，拒绝标记构建成功。' }
$Python = Get-Command python -ErrorAction SilentlyContinue
$PythonPrefix = @()
if (-not $Python) {
    $Python = Get-Command py -ErrorAction SilentlyContinue
    if (-not $Python) { throw '需要安装 Python 3 才能执行 APK ELF 16 KB 检查。' }
    $PythonPrefix = @('-3')
}
& $Python.Source @PythonPrefix (Join-Path $Root 'tools\check_elf_16kb.py') $Apk $Readelf
if ($LASTEXITCODE -ne 0) { throw 'APK native library ELF 16 KB alignment check failed.' }

$Dist = Join-Path $Root 'dist'
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
$FinalApk = Join-Path $Dist 'TyphoonLab-V7.0.0-debug.apk'
Copy-Item -Force $Apk $FinalApk
$Hash = (Get-FileHash $FinalApk -Algorithm SHA256).Hash.ToLower()
Set-Content -Encoding ascii -Path "$FinalApk.sha256" -Value "$Hash  TyphoonLab-V7.0.0-debug.apk"
Write-Host "APK 构建、包名/版本、签名及 16 KB 检查均通过：$FinalApk"
Write-Host "SHA-256：$Hash"
Write-Host '此 Debug APK 使用本机调试密钥；升级旧安装仅在签名证书一致时可直接覆盖。'
