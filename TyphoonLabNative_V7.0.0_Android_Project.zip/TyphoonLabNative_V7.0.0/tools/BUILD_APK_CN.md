# V7.0 Android APK 构建与手机安装

## 推荐：不安装 Android Studio

使用项目根目录中的 `.github/workflows/android-apk.yml`：将工程上传到自己的 GitHub 仓库，在 Actions 页面运行 `Typhoon Lab Android APK`，成功后下载 `TyphoonLab-V7.0.0-Android-Debug-APK` Artifact。手机可直接用浏览器打开仓库、下载 Artifact ZIP、解压并点击 APK 安装。完整步骤见 `PHONE_INSTALL_NO_ANDROID_STUDIO_V7_CN.md`。

云端工作流会安装 JDK 17、Android SDK Platform 36、Build-Tools 36.0.0 和 NDK 27.2.12479018，然后执行 `assembleDebug`。通过构建后还必须经过包名/版本、APK 签名、ZIP 16 KB 对齐和 native ELF 16 KB LOAD 对齐检查，全部通过才会上传 APK。

## Windows 命令行本地构建（不要求 Android Studio IDE）

准备 JDK 17、Android SDK Command-line Tools、API 36、Build-Tools 36、Platform-Tools、NDK 和 Python 3。设置 `ANDROID_SDK_ROOT` 后运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\build_debug_apk.ps1
```

本地构建输出：

- `dist/TyphoonLab-V7.0.0-debug.apk`
- `dist/TyphoonLab-V7.0.0-debug.apk.sha256`

USB 安装已构建 APK：

```bat
tools\install_one_click.bat
```

## 覆盖安装说明

安装器使用 `adb install -r`，不会自动卸载或清空数据。Debug APK 的签名证书若与手机中旧安装版本不同，Android 会拒绝覆盖；需要用户先导出模拟存档和备份离线地图，再自行决定是否卸载旧版。Debug APK 不是 Play Store 发布包。
