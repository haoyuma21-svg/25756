param(
    [string]$Serial = '',
    [string]$ApkPath = ''
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if ([string]::IsNullOrWhiteSpace($ApkPath)) {
    $ApkPath = Join-Path $Root 'dist\TyphoonLab-V7.0.0-debug.apk'
}
$Apk = (Resolve-Path $ApkPath -ErrorAction Stop).Path
if (-not (Test-Path -LiteralPath $Apk -PathType Leaf)) { throw "APK 文件不存在：$Apk" }

$Sdk = $env:ANDROID_SDK_ROOT
if ([string]::IsNullOrWhiteSpace($Sdk)) { $Sdk = $env:ANDROID_HOME }
if ([string]::IsNullOrWhiteSpace($Sdk)) { $Sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$Adb = Join-Path $Sdk 'platform-tools\adb.exe'
if (-not (Test-Path $Adb)) {
    $adbCommand = Get-Command adb -ErrorAction SilentlyContinue
    if ($adbCommand) { $Adb = $adbCommand.Source }
}
if (-not (Test-Path $Adb)) { throw '未找到 adb。请安装 Android SDK Platform-Tools，并开启手机 USB 调试。' }

$BuildToolsRoot = Join-Path $Sdk 'build-tools'
$BuildTools = if (Test-Path $BuildToolsRoot) {
    Get-ChildItem $BuildToolsRoot -Directory | Sort-Object { try { [version]$_.Name } catch { [version]'0.0' } } -Descending | Select-Object -First 1
} else { $null }
if (-not $BuildTools) { throw '找不到 Android Build-Tools，无法核验 APK 包名和版本。' }
$Aapt = Join-Path $BuildTools.FullName 'aapt.exe'
$ApkSigner = Join-Path $BuildTools.FullName 'apksigner.bat'
if (-not (Test-Path $Aapt)) { throw 'Build-Tools 缺少 aapt.exe。' }
$Badging = & $Aapt dump badging $Apk 2>&1
if ($LASTEXITCODE -ne 0) { throw '无法读取 APK Manifest，文件可能损坏。' }
$BadgingText = $Badging -join "`n"
if ($BadgingText -notmatch "package: name='com\.typhoonlab\.mobile' versionCode='70' versionName='7\.0\.0-android16-xiaomi'") {
    throw 'APK 包名或版本不是 Typhoon Lab V7.0.0，拒绝安装。'
}
if ($BadgingText -notmatch "sdkVersion:'26'" -or $BadgingText -notmatch "targetSdkVersion:'36'") {
    throw 'APK 的 minSdk/targetSdk 与本项目声明不符，拒绝安装。'
}
if (-not (Test-Path $ApkSigner)) { throw 'Build-Tools 缺少 apksigner.bat，无法核验签名；拒绝安装。' }
& $ApkSigner verify --verbose $Apk
if ($LASTEXITCODE -ne 0) { throw 'APK 签名无效，拒绝安装。' }

& $Adb start-server | Out-Null
$DeviceOutput = & $Adb devices
$Devices = @($DeviceOutput | Where-Object { $_ -match '^\S+\s+device$' } | ForEach-Object { ($_ -split '\s+')[0] })
$Unauthorized = @($DeviceOutput | Where-Object { $_ -match '^\S+\s+unauthorized$' })
if ($Devices.Count -eq 0) {
    if ($Unauthorized.Count -gt 0) { throw '手机已连接但尚未授权。请解锁手机，在 USB 调试 RSA 提示中选择允许。' }
    throw '没有发现已授权的 Android 手机。请连接 USB、开启开发者选项中的 USB 调试，并选择文件传输模式。'
}
if ([string]::IsNullOrWhiteSpace($Serial)) {
    if ($Devices.Count -eq 1) {
        $Serial = $Devices[0]
    } else {
        Write-Host '检测到多台设备，请选择安装目标：'
        for ($i = 0; $i -lt $Devices.Count; $i++) { Write-Host "[$($i + 1)] $($Devices[$i])" }
        $choice = Read-Host '输入设备序号'
        $index = 0
        if (-not [int]::TryParse($choice, [ref]$index) -or $index -lt 1 -or $index -gt $Devices.Count) {
            throw '设备选择无效，已停止；没有执行安装。'
        }
        $Serial = $Devices[$index - 1]
    }
}
if ($Devices -notcontains $Serial) { throw "指定设备 $Serial 不在已授权设备列表中。" }
$Api = (& $Adb -s $Serial shell getprop ro.build.version.sdk 2>$null).Trim()
$Release = (& $Adb -s $Serial shell getprop ro.build.version.release 2>$null).Trim()
$Manufacturer = (& $Adb -s $Serial shell getprop ro.product.manufacturer 2>$null).Trim()
$Brand = (& $Adb -s $Serial shell getprop ro.product.brand 2>$null).Trim()
$Model = (& $Adb -s $Serial shell getprop ro.product.model 2>$null).Trim()
$Display = (& $Adb -s $Serial shell getprop ro.build.display.id 2>$null).Trim()
$MiuiVersion = (& $Adb -s $Serial shell getprop ro.miui.ui.version.name 2>$null).Trim()
$HyperOsVersion = (& $Adb -s $Serial shell getprop ro.mi.os.version.name 2>$null).Trim()
$ApiNumber = 0
if (-not [int]::TryParse($Api, [ref]$ApiNumber)) { throw '无法读取手机 Android API 版本，拒绝继续。' }
if ($ApiNumber -lt 26) { throw "设备 API $ApiNumber 低于最低要求 API 26（Android 8.0）。" }
Write-Host "目标设备：$Serial"
Write-Host "设备：$Manufacturer / $Brand / $Model"
Write-Host "Android：$Release（API $ApiNumber）"
if (-not [string]::IsNullOrWhiteSpace($HyperOsVersion)) { Write-Host "澎湃 OS：$HyperOsVersion" }
elseif (-not [string]::IsNullOrWhiteSpace($MiuiVersion)) { Write-Host "MIUI：$MiuiVersion" }
elseif ($Display) { Write-Host "系统构建：$Display" }
if ($ApiNumber -eq 35) { Write-Host 'Android 15：支持范围内。' }
elseif ($ApiNumber -eq 36) { Write-Host 'Android 16：支持范围内；首次启动请重点检查边到边布局。' }
elseif ($ApiNumber -gt 36) { Write-Host 'Android 新版本：最低 API 满足要求，建议额外进行兼容测试。' }
Write-Host '正在执行覆盖安装（adb install -r）；不会卸载旧应用，也不会清除用户数据。'
$InstallOutput = & $Adb -s $Serial install -r $Apk 2>&1
$InstallOutput | ForEach-Object { Write-Host $_ }
if ($LASTEXITCODE -ne 0) {
    throw '安装失败。常见原因：旧版签名证书不同、设备空间不足或系统安装来源未授权。助手不会自动卸载旧版，以免删除存档和离线地图。'
}
Write-Host '安装命令成功。请在手机上首次打开，并检查模拟存档与离线地图仓库。'
