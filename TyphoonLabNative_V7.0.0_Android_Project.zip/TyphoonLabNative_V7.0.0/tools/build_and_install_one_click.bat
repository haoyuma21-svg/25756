@echo off
setlocal
cd /d "%~dp0.."
echo [1/2] 构建并检查 Android Debug APK...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_debug_apk.ps1"
if errorlevel 1 goto :failed
echo.
echo [2/2] 安装到已授权 Android 手机...
call "%~dp0install_one_click.bat"
exit /b %ERRORLEVEL%
:failed
echo.
echo 构建失败。请查看上方错误信息；没有执行安装。
pause
exit /b 1
