#!/usr/bin/env python3
"""Check ELF LOAD segment p_align for all native libraries inside an APK."""
from __future__ import annotations
import pathlib
import re
import subprocess
import sys
import tempfile
import zipfile


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: check_elf_16kb.py APK llvm-readelf", file=sys.stderr)
        return 2
    apk = pathlib.Path(sys.argv[1])
    readelf = sys.argv[2]
    if not apk.is_file():
        print(f"FAIL: APK not found: {apk}", file=sys.stderr)
        return 2

    with tempfile.TemporaryDirectory(prefix="typhoonlab-elf-") as tmp:
        root = pathlib.Path(tmp)
        with zipfile.ZipFile(apk) as archive:
            libs = [name for name in archive.namelist() if re.fullmatch(r"lib/[^/]+/[^/]+\.so", name)]
            for name in libs:
                archive.extract(name, root)
        if not libs:
            print("FAIL: APK contains no native .so files; check the expected MapLibre artifact.", file=sys.stderr)
            return 1

        failed: list[str] = []
        for name in sorted(libs):
            path = root / name
            try:
                output = subprocess.check_output([readelf, "-lW", str(path)], text=True, stderr=subprocess.STDOUT)
            except (subprocess.CalledProcessError, OSError) as exc:
                failed.append(f"{name}: readelf failed: {exc}")
                continue
            aligns: list[int] = []
            for line in output.splitlines():
                stripped = line.strip()
                if stripped.startswith("LOAD "):
                    token = stripped.split()[-1]
                    try:
                        aligns.append(int(token, 16))
                    except ValueError:
                        failed.append(f"{name}: invalid LOAD p_align {token}")
                        break
            if not aligns:
                failed.append(f"{name}: no ELF LOAD segments found")
            elif any(value < 0x4000 or value % 0x4000 for value in aligns):
                failed.append(f"{name}: LOAD p_align values {', '.join(hex(v) for v in aligns)}")
            else:
                print(f"PASS {name}: {', '.join(hex(v) for v in aligns)}")

        if failed:
            for item in failed:
                print("FAIL " + item, file=sys.stderr)
            return 1
        print(f"PASS: {len(libs)} native libraries meet the 16 KB ELF LOAD alignment check.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
