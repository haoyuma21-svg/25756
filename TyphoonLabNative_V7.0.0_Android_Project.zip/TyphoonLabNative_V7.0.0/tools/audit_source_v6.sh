#!/usr/bin/env bash
# Full source audit entry point for the current Android-only V7 release.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 tools/tests/audit_v70.py
python3 tools/tests/install_assistant_static_test.py
python3 tools/tests/kotlin_lexical_audit.py
python3 -m py_compile tools/check_elf_16kb.py tools/tests/audit_v70.py tools/tests/install_assistant_static_test.py tools/tests/kotlin_lexical_audit.py
bash -n gradlew tools/run_core_smoke_test.sh tools/run_device_compatibility_test.sh tools/audit_source_v6.sh tools/kotlin_parser_scan.sh
printf 'V7.0 SOURCE AUDIT PASS\\n'
printf 'Also run tools/run_device_compatibility_test.sh, tools/run_core_smoke_test.sh and the WeatherProbeRoundTripTest separately.\\n'
