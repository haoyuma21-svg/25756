#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
if [[ -z "$KOTLINC" ]]; then echo 'SKIP: kotlinc unavailable' >&2; exit 2; fi
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
"$KOTLINC" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/AndroidRomProfile.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/DeviceCompatibility.kt" \
  "$ROOT/tools/tests/DeviceCompatibilitySmokeTest.kt" \
  -include-runtime -d "$TMP/device-compatibility.jar"
java -jar "$TMP/device-compatibility.jar"
