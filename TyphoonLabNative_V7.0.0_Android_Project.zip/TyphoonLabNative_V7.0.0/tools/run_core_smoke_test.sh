#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
if [[ -z "$KOTLINC" ]]; then
  echo "FAIL: 需要安装 Kotlin 命令行编译器（kotlinc）。" >&2
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
KOTLIN_EXTRA=()
if "$KOTLINC" -version 2>&1 | grep -q 'kotlinc-jvm 1\.9'; then KOTLIN_EXTRA=(-Xuse-k2); fi
: "${JAVA_OPTS:=-Xmx1536M -Xms128M}"
export JAVA_OPTS
"$KOTLINC" "${KOTLIN_EXTRA[@]}" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/StormEngine.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/GlobalCommandCenter.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/EnvironmentPresets.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/TrackGeometry.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/AdaptiveFrameBudget.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/ScenarioChallengeCenter.kt" \
  "$ROOT/app/src/main/java/com/typhoonlab/mobile/EnsembleDiagnostics.kt" \
  "$ROOT/tools/tests/org/json/JsonStubs.kt" \
  "$ROOT/tools/tests/CoreSmokeTest.kt" \
  -include-runtime -d "$TMP/core-smoke.jar"
java -jar "$TMP/core-smoke.jar"
