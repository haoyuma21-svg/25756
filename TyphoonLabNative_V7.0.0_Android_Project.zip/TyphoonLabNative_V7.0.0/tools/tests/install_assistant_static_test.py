from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
installer = (ROOT / "tools/install_one_click.ps1").read_text(encoding="utf-8")
builder = (ROOT / "tools/build_debug_apk.ps1").read_text(encoding="utf-8")
bat = (ROOT / "tools/build_and_install_one_click.bat").read_text(encoding="utf-8")
assert "versionCode='70'" in installer and r"7\.0\.0-android16-xiaomi" in installer
assert "versionCode='70'" in builder and r"7\.0\.0-android16-xiaomi" in builder
assert "adb install -r" in installer and "uninstall" not in installer.lower()
assert "dist" in builder and "TyphoonLab-V7.0.0-debug.apk" in builder
assert "check_elf_16kb.py" in builder and "apksigner" in builder and "zipalign" in builder
assert "build_debug_apk.ps1" in bat and "install_one_click.bat" in bat
print("V7 INSTALL ASSISTANT STATIC TEST PASS")
