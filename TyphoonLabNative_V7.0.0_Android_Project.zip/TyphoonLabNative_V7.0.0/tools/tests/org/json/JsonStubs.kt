package org.json

/**
 * Small JSON implementation used only by local JVM smoke tests where Android's org.json
 * runtime is unavailable. It intentionally covers the JSONObject/JSONArray surface used by
 * StormEngine and WeatherModelClient; production Android builds use the platform library.
 */
class JSONArray {
    private val values = mutableListOf<Any?>()
    constructor()
    constructor(collection: Collection<*>) { values.addAll(collection) }
    fun put(value: Any?): JSONArray { values.add(value); return this }
    fun length(): Int = values.size
    fun optJSONObject(index: Int): JSONObject? = values.getOrNull(index) as? JSONObject
    fun optJSONArray(index: Int): JSONArray? = values.getOrNull(index) as? JSONArray
    fun optDouble(index: Int, fallback: Double = Double.NaN): Double = (values.getOrNull(index) as? Number)?.toDouble() ?: fallback
    fun optString(index: Int, fallback: String = ""): String = values.getOrNull(index)?.toString() ?: fallback
    override fun toString(): String = JsonWriter.write(values)
}

class JSONObject {
    private val values = linkedMapOf<String, Any?>()
    constructor()
    constructor(json: String) {
        val parsed = JsonParser(json).parse()
        require(parsed is Map<*, *>) { "JSON root must be an object" }
        parsed.forEach { (key, value) ->
            require(key is String) { "JSON object key must be a string" }
            values[key] = wrap(value)
        }
    }
    fun put(key: String, value: Any?): JSONObject {
        require(key.isNotEmpty())
        if (value is Double) require(value.isFinite()) { "JSON cannot encode non-finite numbers" }
        if (value is Float) require(value.isFinite()) { "JSON cannot encode non-finite numbers" }
        values[key] = wrap(value)
        return this
    }
    fun has(key: String): Boolean = values.containsKey(key)
    fun isNull(key: String): Boolean = !values.containsKey(key) || values[key] == null
    fun getDouble(key: String): Double = (values[key] as? Number)?.toDouble() ?: throw IllegalArgumentException("Missing number: $key")
    fun optDouble(key: String, fallback: Double = Double.NaN): Double = (values[key] as? Number)?.toDouble() ?: fallback
    fun optInt(key: String, fallback: Int = 0): Int = (values[key] as? Number)?.toInt() ?: fallback
    fun optLong(key: String, fallback: Long = 0L): Long = (values[key] as? Number)?.toLong() ?: fallback
    fun optBoolean(key: String, fallback: Boolean = false): Boolean = values[key] as? Boolean ?: fallback
    fun optString(key: String, fallback: String = ""): String = values[key]?.toString() ?: fallback
    fun optJSONArray(key: String): JSONArray? = values[key] as? JSONArray
    fun optJSONObject(key: String): JSONObject? = values[key] as? JSONObject
    fun toString(indent: Int): String = toString()
    override fun toString(): String = JsonWriter.write(values)

    private fun wrap(value: Any?): Any? = when (value) {
        is Map<*, *> -> JSONObject().apply { value.forEach { (k, v) -> if (k is String) put(k, v) } }
        is Collection<*> -> JSONArray(value)
        else -> value
    }
}

private object JsonWriter {
    fun write(value: Any?): String = when (value) {
        null -> "null"
        is String -> quote(value)
        is Number -> value.toString()
        is Boolean -> value.toString()
        is JSONObject -> value.toString()
        is JSONArray -> value.toString()
        is Map<*, *> -> value.entries.joinToString(prefix = "{", postfix = "}") { (k, v) -> quote(k.toString()) + ":" + write(v) }
        is Collection<*> -> value.joinToString(prefix = "[", postfix = "]") { write(it) }
        else -> quote(value.toString())
    }
    private fun quote(value: String): String = buildString {
        append('"')
        value.forEach { ch ->
            when (ch) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (ch.code < 0x20) append("\\u%04x".format(ch.code)) else append(ch)
            }
        }
        append('"')
    }
}

private class JsonParser(private val input: String) {
    private var index = 0
    fun parse(): Any? {
        val result = value()
        whitespace()
        require(index == input.length) { "Trailing JSON data at $index" }
        return result
    }
    private fun value(): Any? {
        whitespace()
        require(index < input.length) { "Unexpected end of JSON" }
        return when (input[index]) {
            '{' -> objectValue()
            '[' -> arrayValue()
            '"' -> stringValue()
            't' -> literal("true", true)
            'f' -> literal("false", false)
            'n' -> literal("null", null)
            '-', in '0'..'9' -> numberValue()
            else -> error("Unexpected JSON token at $index")
        }
    }
    private fun objectValue(): Map<String, Any?> {
        expect('{'); whitespace()
        val map = linkedMapOf<String, Any?>()
        if (take('}')) return map
        while (true) {
            whitespace(); require(index < input.length && input[index] == '"') { "Object key expected" }
            val key = stringValue(); whitespace(); expect(':')
            map[key] = value(); whitespace()
            if (take('}')) return map
            expect(',')
        }
    }
    private fun arrayValue(): List<Any?> {
        expect('['); whitespace()
        val list = mutableListOf<Any?>()
        if (take(']')) return list
        while (true) {
            list += value(); whitespace()
            if (take(']')) return list
            expect(',')
        }
    }
    private fun stringValue(): String {
        expect('"'); val out = StringBuilder()
        while (index < input.length) {
            val ch = input[index++]
            when (ch) {
                '"' -> return out.toString()
                '\\' -> {
                    require(index < input.length) { "Invalid escape" }
                    when (val escaped = input[index++]) {
                        '"', '\\', '/' -> out.append(escaped)
                        'b' -> out.append('\b')
                        'f' -> out.append('\u000C')
                        'n' -> out.append('\n')
                        'r' -> out.append('\r')
                        't' -> out.append('\t')
                        'u' -> {
                            require(index + 4 <= input.length) { "Invalid unicode escape" }
                            out.append(input.substring(index, index + 4).toInt(16).toChar()); index += 4
                        }
                        else -> error("Invalid escape sequence")
                    }
                }
                else -> { require(ch.code >= 0x20) { "Unescaped control character" }; out.append(ch) }
            }
        }
        error("Unterminated JSON string")
    }
    private fun numberValue(): Number {
        val start = index
        if (take('-')) Unit
        if (take('0')) Unit else { require(index < input.length && input[index] in '1'..'9'); while (index < input.length && input[index].isDigit()) index++ }
        var fractional = false
        if (take('.')) { fractional = true; require(index < input.length && input[index].isDigit()); while (index < input.length && input[index].isDigit()) index++ }
        if (index < input.length && (input[index] == 'e' || input[index] == 'E')) {
            fractional = true; index++; if (index < input.length && (input[index] == '+' || input[index] == '-')) index++
            require(index < input.length && input[index].isDigit()); while (index < input.length && input[index].isDigit()) index++
        }
        val raw = input.substring(start, index)
        return if (!fractional) raw.toLongOrNull() ?: raw.toDouble() else raw.toDouble()
    }
    private fun <T> literal(raw: String, result: T): T { require(input.startsWith(raw, index)); index += raw.length; return result }
    private fun whitespace() { while (index < input.length && input[index].isWhitespace()) index++ }
    private fun take(ch: Char): Boolean = if (index < input.length && input[index] == ch) { index++; true } else false
    private fun expect(ch: Char) { require(take(ch)) { "Expected '$ch' at $index" } }
}
