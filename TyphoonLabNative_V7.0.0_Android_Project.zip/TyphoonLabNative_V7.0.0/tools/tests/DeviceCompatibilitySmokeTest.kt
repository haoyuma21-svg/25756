import com.typhoonlab.mobile.AndroidRomProfile
import com.typhoonlab.mobile.DeviceCompatibility
import com.typhoonlab.mobile.RomFamily

fun main() {
    val hyper = DeviceCompatibility.detect("Xiaomi", "Redmi", "HyperOS OS2.0.202.TEST", "16", 36)
    check(hyper.isXiaomiFamily && hyper.isHyperOs && !hyper.isMiui)
    check(hyper.minimumSdkSupported && hyper.romLabel.contains("HyperOS"))
    check(hyper.guidance.any { it.contains("Android 16") })
    check(hyper.guidance.any { it.contains("不会注册开机自启") })

    val hyperOs1 = DeviceCompatibility.detect("Xiaomi", "Xiaomi", "OS1.0.9.0.TEST", "14", 34)
    check(hyperOs1.isHyperOs && hyperOs1.romLabel.contains("OS1.0.9.0"))

    val hyperOs3 = DeviceCompatibility.detect("Xiaomi", "Redmi", "HYPEROS OS3.0.1.0.TEST", "16", 36)
    check(hyperOs3.isHyperOs && hyperOs3.romLabel.contains("OS3.0.1.0"))

    val miui = DeviceCompatibility.detect("Xiaomi", "Xiaomi", "MIUI V14.0.8.0", "15", 35)
    check(miui.isXiaomiFamily && miui.isMiui && !miui.isHyperOs)
    check(miui.guidance.any { it.contains("Android 15") })
    check(miui.romLabel.contains("V14.0.8.0")) { "MIUI version string was not extracted" }

    val poco = DeviceCompatibility.detect("Xiaomi", "POCO", "UNKNOWN_BUILD", "14", 34)
    check(poco.isXiaomiFamily && !poco.isMiui && !poco.isHyperOs)
    check(poco.romLabel.contains("未能从构建标识确认"))

    val pixel = DeviceCompatibility.detect("Google", "google", "AP2A.240905.003", "16", 36)
    check(!pixel.isXiaomiFamily && !pixel.isHyperOs && !pixel.isMiui)

    val tooOld = DeviceCompatibility.detect("Xiaomi", "Redmi", "MIUI", "7.1", 25)
    check(!tooOld.minimumSdkSupported)
    check(tooOld.guidance.any { it.contains("低于最低支持版本") })

    val aliasHyper = AndroidRomProfile.classify("Xiaomi", "Redmi", "OS2.0.5", null)
    check(aliasHyper.family == RomFamily.XIAOMI_HYPEROS)
    val hyperThree = DeviceCompatibility.detect("Xiaomi", "POCO", "HyperOS 3.0.1.0", "16", 36)
    check(hyperThree.isHyperOs && hyperThree.romLabel.contains("3.0.1.0"))
    val aliasMiui = AndroidRomProfile.classify("Xiaomi", "Poco", null, "MIUI 14")
    check(aliasMiui.family == RomFamily.XIAOMI_MIUI)
    val unknownXiaomi = AndroidRomProfile.classify("Xiaomi", "POCO", null, null)
    check(unknownXiaomi.family == RomFamily.XIAOMI_UNKNOWN)
    val other = AndroidRomProfile.classify("Samsung", "Samsung", null, null)
    check(other.family == RomFamily.OTHER)

    println("DEVICE COMPATIBILITY SMOKE TEST PASS")
    println("HyperOS-OS1-OS2-OS3=PASS MIUI=PASS XiaomiUnknownROM=PASS otherAndroid=PASS minSdkGuard=PASS")
}
