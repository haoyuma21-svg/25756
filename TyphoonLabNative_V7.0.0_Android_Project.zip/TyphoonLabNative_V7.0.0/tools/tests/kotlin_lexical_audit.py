#!/usr/bin/env python3
"""Fast Kotlin source lexical audit. It checks strings/comments and delimiter balance only."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
PAIRS = {')': '(', ']': '[', '}': '{'}


def scan(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    stack: list[tuple[str, int]] = []
    i = 0
    line = 1
    state = 'code'
    block_depth = 0
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ''
        third = text[i + 2] if i + 2 < len(text) else ''
        if ch == '\n':
            line += 1
        if state == 'code':
            if ch == '/' and nxt == '/':
                state = 'line_comment'; i += 2; continue
            if ch == '/' and nxt == '*':
                state = 'block_comment'; block_depth = 1; i += 2; continue
            if ch == '"' and nxt == '"' and third == '"':
                state = 'raw_string'; i += 3; continue
            if ch == '"':
                state = 'string'; i += 1; continue
            if ch == "'":
                state = 'char'; i += 1; continue
            if ch in '([{':
                stack.append((ch, line))
            elif ch in ')]}':
                if not stack or stack[-1][0] != PAIRS[ch]:
                    raise ValueError(f'{path}: line {line}: unmatched {ch}')
                stack.pop()
            i += 1; continue
        if state == 'line_comment':
            if ch == '\n': state = 'code'
            i += 1; continue
        if state == 'block_comment':
            if ch == '/' and nxt == '*':
                block_depth += 1; i += 2; continue
            if ch == '*' and nxt == '/':
                block_depth -= 1; i += 2
                if block_depth == 0: state = 'code'
                continue
            i += 1; continue
        if state == 'raw_string':
            if ch == '"' and nxt == '"' and third == '"':
                state = 'code'; i += 3; continue
            i += 1; continue
        if state in ('string', 'char'):
            terminator = '"' if state == 'string' else "'"
            if ch == '\\':
                i += 2; continue
            if ch == terminator:
                state = 'code'
            elif ch == '\n' and state == 'string':
                raise ValueError(f'{path}: line {line}: newline inside ordinary string literal')
            i += 1; continue
    if state in ('block_comment', 'raw_string', 'string', 'char'):
        raise ValueError(f'{path}: unterminated lexical state {state}')
    if stack:
        token, opened = stack[-1]
        raise ValueError(f'{path}: unclosed {token} opened at line {opened}')


def main() -> int:
    files = sorted((ROOT / 'app/src/main/java').rglob('*.kt'))
    if not files:
        print('FAIL: no Kotlin sources', file=sys.stderr); return 2
    for file in files:
        scan(file)
    print(f'KOTLIN LEXICAL AUDIT PASS: {len(files)} files; comments, strings and delimiters balanced.')
    print('NOTE: lexical audit is not a Kotlin type-check or Android Gradle build.')
    return 0

if __name__ == '__main__':
    try: raise SystemExit(main())
    except Exception as exc:
        print(f'FAIL: {exc}', file=sys.stderr); raise SystemExit(1)
