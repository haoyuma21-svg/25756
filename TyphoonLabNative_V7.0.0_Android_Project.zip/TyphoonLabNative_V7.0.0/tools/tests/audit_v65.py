#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
main = (ROOT / "app/src/main/java/com/typhoonlab/mobile/MainActivity.kt").read_text(encoding="utf-8")
client = (ROOT / "app/src/main/java/com/typhoonlab/mobile/WeatherModelClient.kt").read_text(encoding="utf-8")
map_mgr = (ROOT / "app/src/main/java/com/typhoonlab/mobile/MapPackManager.kt").read_text(encoding="utf-8")
compat = (ROOT / "app/src/main/java/com/typhoonlab/mobile/DeviceCompatibility.kt").read_text(encoding="utf-8")
rom = (ROOT / "app/src/main/java/com/typhoonlab/mobile/AndroidRomProfile.kt").read_text(encoding="utf-8")
adaptive = (ROOT / "app/src/main/java/com/typhoonlab/mobile/AdaptiveFrameBudget.kt").read_text(encoding="utf-8")

assert 'versionCode = 65' in gradle
assert 'versionName = "6.5.0-android16-xiaomi"' in gradle
assert 'compileSdk = 36' in gradle and 'targetSdk = 36' in gradle
assert 'minSdk = 26' in gradle
assert 'sourceCompatibility = JavaVersion.VERSION_17' in gradle
assert 'org.maplibre.gl:android-sdk-opengl:13.7.1' in gradle

android_ns = "{http://schemas.android.com/apk/res/android}"
app = manifest.find("application")
assert app is not None
assert app.get(android_ns + "usesCleartextTraffic") == "false"
assert app.get(android_ns + "enableOnBackInvokedCallback") == "true"
assert app.get(android_ns + "fullBackupContent") == "@xml/backup_rules"
assert app.get(android_ns + "dataExtractionRules") == "@xml/data_extraction_rules"
perms = {node.get(android_ns + "name") for node in manifest.findall("uses-permission")}
assert perms == {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"}, perms
assert not app.findall("receiver")
activity = app.find("activity")
assert activity is not None and activity.get(android_ns + "resizeableActivity") == "true"
assert all(x in activity.get(android_ns + "configChanges", "") for x in ["orientation", "screenSize", "smallestScreenSize", "screenLayout"])
strings = ET.parse(ROOT / "app/src/main/res/values/strings.xml").getroot()
assert any(node.get("name") == "app_name" and "V6.5" in (node.text or "") for node in strings.findall("string"))

# Android 15/16 view-based edge-to-edge / predictive back.
assert "WindowCompat.setDecorFitsSystemWindows(window, false)" in main
assert "WindowInsetsCompat.Type.systemBars()" in main
assert "WindowInsetsCompat.Type.ime()" in main
assert "applySimulationWindowInsets()" in main
assert "OnBackPressedCallback" in main
assert "DeviceCompatibility.detect(" in main
assert "showAndroidCompatibilityCenter()" in main
assert "ACTION_APPLICATION_DETAILS_SETTINGS" in main
assert "ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS" in main

# Public ROM identification only. No MIUI private API, autostart or popup permission.
assert "Build.MANUFACTURER" in main and "Build.BRAND" in main and "Build.DISPLAY" in main
assert "HYPEROS" in compat and "MIUI" in compat and "OS[123]" in compat
assert "XIAOMI_HYPEROS" in rom and "XIAOMI_MIUI" in rom
assert "不会注册开机自启动接收器" in compat or "不会注册开机自启接收器" in compat
assert "隐藏的厂商权限" in compat
assert "BOOT_COMPLETED" not in " ".join(perms)

# Adaptive rendering responds to power saver/thermal/load; fixed-step engine unaffected.
assert "AdaptiveFrameBudget.calculate" in main
assert "powerManager.isPowerSaveMode" in main
assert "currentThermalStatus" in main
assert "thermalStatus == 3" in adaptive and "thermalStatus >= 4" in adaptive
assert "fixed-step" in adaptive

# Weather API remains optional, explicit, bounded, and separate from sim state.
assert 'https://api.open-meteo.com/v1/forecast' in client
assert 'https://marine-api.open-meteo.com/v1/marine' in client
assert 'http://' not in client
assert 'CONNECT_TIMEOUT_MS' in client and 'READ_TIMEOUT_MS' in client
assert 'MAX_RESPONSE_BYTES' in client and '1_500_000L' in client
assert 'latitude.isFinite()' in client and 'longitude.isFinite()' in client
assert 'Thread.currentThread().isInterrupted' in client
assert 'weather_code' in client and 'sea_surface_temperature' in client
assert 'weather_probe_v61' in main and 'showWeatherProbeHistory' in main
assert 'take(24)' in main and 'weather_probe_history_' in main

# Offline map storage uses streaming imports and a hard 60 GB quota.
assert '60_000_000_000L' in map_mgr
assert 'parsedUri.scheme.equals("https", true)' in map_mgr
assert 'Content-Range' in map_mgr
assert 'TyphoonLab-Android/6.5.0' in map_mgr
assert 'PMTiles v3' in map_mgr
backup = ET.parse(ROOT / "app/src/main/res/xml/backup_rules.xml").getroot()
assert any(node.get("domain") == "file" and node.get("path") == "MapPacks/" for node in backup.findall("exclude"))
extract = ET.parse(ROOT / "app/src/main/res/xml/data_extraction_rules.xml").getroot()
assert extract.find("cloud-backup") is not None and extract.find("device-transfer") is not None

# Preserve scenario controls and map seam behavior.
scenario = (ROOT / "app/src/main/java/com/typhoonlab/mobile/EnvironmentPresets.kt").read_text(encoding="utf-8")
engine = (ROOT / "app/src/main/java/com/typhoonlab/mobile/StormEngine.kt").read_text(encoding="utf-8")
track = (ROOT / "app/src/main/java/com/typhoonlab/mobile/TrackGeometry.kt").read_text(encoding="utf-8")
assert all(key in scenario for key in ["wpac_favorable", "high_shear", "coastal_landfall", "cool_dry", "monsoon_trough"])
assert "applyEnvironmentPreset" in engine and "environmentalSupportIndex" in engine
assert "steeringHeadingDeg" in engine and "splitAtAntimeridian" in main and "splitAtAntimeridian" in track

# Windows-only host helpers build/install only the Android APK; no alternate application platforms.
for path in ["tools/build_debug_apk.ps1", "tools/install_one_click.ps1", "tools/install_one_click.bat", "tools/build_and_install_one_click.bat"]:
    assert (ROOT / path).is_file(), path
for path in [".github", "tools/build_debug_apk.sh", "tools/install_debug_apk.sh", "tools/build_raster_pmtiles.sh"]:
    assert not (ROOT / path).exists(), f"non-Android pipeline still present: {path}"
build = (ROOT / "tools/build_debug_apk.ps1").read_text(encoding="utf-8")
installer = (ROOT / "tools/install_one_click.ps1").read_text(encoding="utf-8")
assert "versionCode='65'" in build and r"6\.5\.0-android16-xiaomi" in build
assert "targetSdkVersion:'36'" in build and "sdkVersion:'26'" in build
assert "check_elf_16kb.py" in build and "apksigner" in build and "zipalign" in build
assert "adb install -r" in installer and "uninstall" not in installer.lower()
assert "ro.mi.os.version.name" in installer and "ro.miui.ui.version.name" in installer
assert "versionCode='65'" in installer and r"6\.5\.0-android16-xiaomi" in installer

for xml in (ROOT / "app/src/main").rglob("*.xml"):
    ET.parse(xml)

print("V6.5 ANDROID SOURCE AUDIT PASS")
print("version=6.5.0 code=65 targetSdk=36 minSdk=26")
print("android15=PASS android16=PASS edge-to-edge=PASS predictive-back=PASS adaptive-windows=PASS")
print("hyperos=PASS miui=PASS public-build-identification=PASS no-private-permissions=PASS")
print("thermal-adaptation=PASS fixed-physics=PASS weather-client=PASS PMTiles-v3=PASS quota-60GB=PASS")
print("backup-map-exclusion=PASS Windows-APK-build=PASS one-click-ADB-install=PASS XML=PASS")
