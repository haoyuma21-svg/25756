package com.typhoonlab.mobile

fun main() {
    val full = WeatherProbeSnapshot(
        requestedLatitude = 18.25,
        requestedLongitude = 134.75,
        modelLatitude = 18.2,
        modelLongitude = 134.8,
        marineModelLatitude = 18.16,
        marineModelLongitude = 134.72,
        weatherTime = "2026-10-31T14:00",
        timezone = "Asia/Manila",
        fetchedAtEpochMs = 1_798_432_000_000L,
        airTemperatureC = 28.5,
        relativeHumidityPercent = 83.0,
        apparentTemperatureC = 34.2,
        precipitationMm = 1.4,
        weatherCode = 61,
        cloudCoverPercent = 91.0,
        seaLevelPressureHpa = 998.2,
        windSpeedMs = 17.4,
        windDirectionDeg = 285.0,
        windGustMs = 25.1,
        seaSurfaceTemperatureC = 29.7,
        waveHeightM = 3.2,
        seaLevelHeightM = 0.18,
        oceanCurrentSpeedKmh = 1.8,
        oceanCurrentDirectionDeg = 47.0,
        marineTime = "2026-10-31T14:00"
    )
    val encoded = full.toJson()
    check(encoded.startsWith("{"))
    check(WeatherProbeSnapshot.fromJson(encoded) == full) { "Full snapshot JSON round-trip failed" }

    val sparse = full.copy(
        marineModelLatitude = null,
        marineModelLongitude = null,
        seaSurfaceTemperatureC = null,
        waveHeightM = null,
        seaLevelHeightM = null,
        oceanCurrentSpeedKmh = null,
        oceanCurrentDirectionDeg = null,
        marineTime = null
    )
    check(WeatherProbeSnapshot.fromJson(sparse.toJson()) == sparse) { "Sparse/null marine snapshot round-trip failed" }

    val wrongSchema = encoded.replace("typhoonlab-weather-probe-v1", "future-schema")
    check(runCatching { WeatherProbeSnapshot.fromJson(wrongSchema) }.isFailure) { "Unknown schema must be rejected" }
    val badLatitude = encoded.replace("\"requestedLatitude\":18.25", "\"requestedLatitude\":181.0")
    check(runCatching { WeatherProbeSnapshot.fromJson(badLatitude) }.isFailure) { "Out-of-range latitude must be rejected" }
    val badMarineLatitude = encoded.replace("\"marineModelLatitude\":18.16", "\"marineModelLatitude\":92.0")
    check(runCatching { WeatherProbeSnapshot.fromJson(badMarineLatitude) }.isFailure) { "Out-of-range marine grid latitude must be rejected" }
    check(runCatching { WeatherProbeSnapshot.fromJson(" ".repeat(8193)) }.isFailure) { "Oversized cache must be rejected" }
    println("WEATHER PROBE ROUND-TRIP TEST PASSED full=sparse=null-fields=schema-guard=coordinate-guard=PASS")
}
