#!/usr/bin/env python3
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
main = (ROOT / "app/src/main/java/com/typhoonlab/mobile/MainActivity.kt").read_text(encoding="utf-8")
engine = (ROOT / "app/src/main/java/com/typhoonlab/mobile/StormEngine.kt").read_text(encoding="utf-8")
challenge = (ROOT / "app/src/main/java/com/typhoonlab/mobile/ScenarioChallengeCenter.kt").read_text(encoding="utf-8")
ensemble = (ROOT / "app/src/main/java/com/typhoonlab/mobile/EnsembleDiagnostics.kt").read_text(encoding="utf-8")

assert "versionCode = 70" in gradle
assert 'versionName = "7.0.0-android16-xiaomi"' in gradle
assert "compileSdk = 36" in gradle and "targetSdk = 36" in gradle
assert "minSdk = 26" in gradle
assert "sourceCompatibility = JavaVersion.VERSION_17" in gradle
assert "org.maplibre.gl:android-sdk-opengl:13.7.1" in gradle

android_ns = "{http://schemas.android.com/apk/res/android}"
app = manifest.find("application")
assert app is not None
assert app.get(android_ns + "usesCleartextTraffic") == "false"
assert app.get(android_ns + "enableOnBackInvokedCallback") == "true"
perms = {node.get(android_ns + "name") for node in manifest.findall("uses-permission")}
assert perms == {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"}, perms
activity = app.find("activity")
assert activity is not None and activity.get(android_ns + "resizeableActivity") == "true"

# Android 15/16 compatibility baseline retained.
assert "WindowCompat.setDecorFitsSystemWindows(window, false)" in main
assert "WindowInsetsCompat.Type.systemBars()" in main
assert "WindowInsetsCompat.Type.ime()" in main
assert "OnBackPressedCallback" in main
assert "DeviceCompatibility.detect(" in main
assert "AdaptiveFrameBudget.calculate" in main
assert "currentThermalStatus" in main

# Major V7 release: five challenges, explicit reset/start, scoring and persistent progress.
assert len(re.findall(r'ScenarioChallenge\(\s*id\s*=', challenge)) == 5
for key in ["rapid_intensification", "shear_survival", "coastal_landfall", "fujiwhara_pair", "three_storm_watch"]:
    assert key in challenge
assert "resetForScenario" in challenge and "fun evaluate" in challenge and "FUJIWHARA_TARGET_STEPS" in challenge
assert "showScenarioChallengeCenter" in main and "showCurrentChallengeProgress" in main
assert "v70_active_challenge" in main and "v70_challenge_start_hours" in main
assert "fujiwharaInteractionSteps" in engine
assert "fujiwharaInteractionSteps" in engine[engine.index("fun exportState"):]
assert "fujiwharaInteractionSteps" in engine[engine.index("fun restoreState"):engine.index("fun exportState")]
assert "fun resetForScenario" in engine and "fun spawnSubAt" in engine

# Ensemble statistics are date-line-safe and explicitly not a probability forecast.
assert "object EnsembleDiagnostics" in ensemble
assert "StormEngine.wrapLon" in ensemble
assert "showEnsembleSummary" in main

# Adaptive map detail uses display/load as a rendering-only budget.
assert "measuredFps in 1..29" in main and "geometryStormCount >= 9" in main
assert "30 Hz" in (ROOT / "CHANGELOG_V7.0_CN.md").read_text(encoding="utf-8")

# Safe Android permission and storage baseline.
assert "usesCleartextTraffic" in app.attrib or app.get(android_ns + "usesCleartextTraffic") == "false"
for xml in (ROOT / "app/src/main").rglob("*.xml"):
    ET.parse(xml)

# Local build/install helpers now target V7 and never uninstall automatically.
build = (ROOT / "tools/build_debug_apk.ps1").read_text(encoding="utf-8")
installer = (ROOT / "tools/install_one_click.ps1").read_text(encoding="utf-8")
assert "versionCode='70'" in build and r"7\.0\.0-android16-xiaomi" in build
assert "TyphoonLab-V7.0.0-debug.apk" in build
assert "versionCode='70'" in installer and r"7\.0\.0-android16-xiaomi" in installer
assert "TyphoonLab-V7.0.0-debug.apk" in installer
assert "adb install -r" in installer and "uninstall" not in installer.lower()
assert "check_elf_16kb.py" in build and "apksigner" in build and "zipalign" in build

# New mobile-first cloud build route does not need the Android Studio IDE.
workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
phone_guide = (ROOT / "PHONE_INSTALL_NO_ANDROID_STUDIO_V7_CN.md").read_text(encoding="utf-8")
assert "workflow_dispatch" in workflow and "actions/checkout@v7" in workflow
assert "actions/setup-java@v6" in workflow and "android-actions/setup-android@v4" in workflow
assert "assembleDebug" in workflow and "apksigner" in workflow and "zipalign" in workflow
assert "llvm-readelf" in workflow and "actions/upload-artifact@v7" in workflow
assert "Android Studio" in phone_guide and "手机浏览器" in phone_guide and "Termux" in phone_guide

for required in ["tools/build_debug_apk.ps1", "tools/install_one_click.ps1", "tools/check_elf_16kb.py"]:
    assert (ROOT / required).is_file(), required
for obsolete in ["tools/build_debug_apk.sh", "tools/install_debug_apk.sh", "tools/build_raster_pmtiles.sh"]:
    assert not (ROOT / obsolete).exists(), obsolete

print("V7.0 STATIC RELEASE AUDIT PASS")
print("versionCode=70 versionName=7.0.0-android16-xiaomi targetSdk=36 minSdk=26")
print("Android15/16 baseline=PASS permissions=PASS XML=PASS")
print("challengeCatalog=5/5 reset/scoring/progress=PASS FujiwharaPersistence=PASS")
print("ensembleDateLineDiagnostics=PASS adaptiveMapDetail=PASS")
print("WindowsAPKchecks=PASS no-auto-uninstall=PASS cloudBuildWorkflow=PASS mobileInstallGuide=PASS")
