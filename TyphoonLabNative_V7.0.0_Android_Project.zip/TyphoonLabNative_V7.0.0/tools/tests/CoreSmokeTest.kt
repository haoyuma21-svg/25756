import com.typhoonlab.mobile.StormEngine
import com.typhoonlab.mobile.GlobalCommandCenter
import com.typhoonlab.mobile.TrackGeometry
import com.typhoonlab.mobile.AdaptiveFrameBudget
import com.typhoonlab.mobile.ScenarioChallengeCenter
import com.typhoonlab.mobile.EnsembleDiagnostics
import kotlin.math.abs

fun runFor(rate: Int, seconds: Int): StormEngine {
    val engine = StormEngine(20261031)
    engine.simulationSpeed = 8.0
    engine.motionMultiplier = 1.0
    engine.spawnMain(17.0, 132.0)
    repeat(rate * seconds) { engine.advance(1.0 / rate) }
    return engine
}

fun main() {
    val rates = listOf(30, 60, 90, 120).map { it to runFor(it, 10) }
    val ref = rates.first().second
    for ((rate, engine) in rates) {
        check(abs(engine.simulatedHours - ref.simulatedHours) < 1e-6) { "time drift at $rate Hz: ${engine.simulatedHours} vs ${ref.simulatedHours}" }
        val a = engine.selectedStorm()!!
        val b = ref.selectedStorm()!!
        check(abs(a.latitude - b.latitude) < 1e-5 && abs(a.longitude - b.longitude) < 1e-5) { "track drift at $rate Hz" }
    }
    check(ref.physicsSteps == 300L) { "expected 300 physics steps, got ${ref.physicsSteps}" }
    check(abs(ref.simulatedHours - (10.0 / 60.0 * 8.0)) < 1e-6) { "unexpected sim time: ${ref.simulatedHours}" }

    val ensembleA = StormEngine(12345)
    val ensembleB = StormEngine(12345)
    ensembleA.spawnMain(18.0, 140.0)
    ensembleB.spawnMain(18.0, 140.0)
    ensembleA.generateEnsemble(members = 32)
    repeat(300) { ensembleA.advance(1.0 / 30.0); ensembleB.advance(1.0 / 30.0) }
    val sa = ensembleA.selectedStorm()!!
    val sb = ensembleB.selectedStorm()!!
    check(abs(sa.latitude - sb.latitude) < 1e-10 && abs(sa.longitude - sb.longitude) < 1e-10) { "ensemble altered physics RNG" }
    check(abs(sa.windMs - sb.windMs) < 1e-10) { "ensemble changed intensity RNG" }

    val capped = StormEngine(7)
    capped.spawnMain()
    repeat(StormEngine.MAX_ACTIVE_STORMS - 1) { capped.spawnSub() }
    check(capped.activeStorms().size == StormEngine.MAX_ACTIVE_STORMS)
    val rejected = runCatching { capped.spawnSub() }.isFailure
    check(rejected) { "active storm cap not enforced" }
    val snapshot = GlobalCommandCenter.build(capped)
    check(snapshot.activeStormCount == StormEngine.MAX_ACTIVE_STORMS)
    check(snapshot.regions.size == 7)
    check(snapshot.regions.sumOf { it.stormCount } <= snapshot.activeStormCount)


    val datelineWpac = StormEngine(11)
    datelineWpac.spawnMain(18.0, -179.0)
    check(GlobalCommandCenter.build(datelineWpac).regions.first { it.region.id == "wpac" }.stormCount == 1) {
        "date-line storm was not assigned to western Pacific"
    }
    val datelineAus = StormEngine(12)
    datelineAus.spawnMain(-18.0, -179.0)
    check(GlobalCommandCenter.build(datelineAus).regions.first { it.region.id == "auspac" }.stormCount == 1) {
        "southern date-line storm was not assigned to Australia/South Pacific"
    }


    val loadTest = StormEngine(20261030)
    loadTest.simulationSpeed = 32.0
    loadTest.motionMultiplier = 4.0
    loadTest.spawnMain(15.0, 135.0)
    repeat(StormEngine.MAX_ACTIVE_STORMS - 1) { loadTest.spawnSub() }
    repeat(30 * 20) { loadTest.advance(1.0 / 30.0) }
    check(loadTest.activeStorms().size <= StormEngine.MAX_ACTIVE_STORMS)
    check(loadTest.storms.all { it.latitude.isFinite() && it.longitude.isFinite() && it.windMs.isFinite() && it.pressureHpa.isFinite() }) {
        "high-load simulation generated non-finite storm state"
    }
    check(loadTest.replayTimeline.size <= StormEngine.MAX_REPLAY_FRAMES)
    check(loadTest.eventLog.size <= StormEngine.MAX_EVENT_LOG)


    // V6.2 environment presets do not remove/reset storms and the favorable preset
    // must score higher than the strong-shear hostile environment.
    val presetEngine = StormEngine(88)
    val presetStorm = presetEngine.spawnMain(17.0, 132.0)
    val stormIdBeforePreset = presetStorm.id
    val countBeforePreset = presetEngine.storms.size
    val favorable = presetEngine.applyEnvironmentPreset("wpac_favorable")
    val favorableScore = presetEngine.environmentalSupportIndex()
    check(presetEngine.storms.size == countBeforePreset && presetEngine.selectedStorm()?.id == stormIdBeforePreset) {
        "applying environment preset unexpectedly changed storm state"
    }
    check(favorable.seaSurfaceTempC > 29.0 && presetEngine.manualControl.not()) { "favorable preset not applied" }
    presetEngine.applyEnvironmentPreset("high_shear")
    val hostileScore = presetEngine.environmentalSupportIndex()
    check(favorableScore > hostileScore) { "high shear should reduce environmental support score" }
    check(runCatching { presetEngine.applyEnvironmentPreset("not-a-preset") }.isFailure) { "unknown preset must be rejected" }

    // Steering heading is persisted and changes auto track convergence without non-finite values.
    val steeringEngine = StormEngine(99)
    val steeringStorm = steeringEngine.spawnMain(15.0, 132.0)
    steeringStorm.headingDeg = 180.0
    steeringEngine.manualControl = false
    steeringEngine.steeringHeadingDeg = 90.0
    repeat(300) { steeringEngine.advance(1.0 / 30.0) }
    check(steeringStorm.headingDeg in 90.0..180.0) { "steering heading did not guide auto track" }
    val savedSteering = steeringEngine.exportState()
    val restoredSteering = StormEngine(1)
    restoredSteering.restoreState(savedSteering)
    check(abs(restoredSteering.steeringHeadingDeg - 90.0) < 1e-9) { "steering heading not persisted" }
    val legacyWithoutSteering = savedSteering.replace(Regex("\"steeringHeadingDeg\":[^,]+,"), "")
    val legacyRestored = StormEngine(2)
    legacyRestored.restoreState(legacyWithoutSteering)
    check(abs(legacyRestored.steeringHeadingDeg - 290.0) < 1e-9) { "V6.1.1 state did not use the steering fallback" }

    // Map tracks split at ±180° and do not connect unrelated segments through invalid points.
    val seamSegments = TrackGeometry.splitAtAntimeridian(listOf(
        17.0 to 178.5, 17.2 to 179.6, 17.3 to -179.7, 17.5 to -178.8
    ))
    check(seamSegments.size == 2 && seamSegments.all { it.size == 2 }) { "antimeridian path not split correctly: $seamSegments" }
    val cleanSegments = TrackGeometry.splitAtAntimeridian(listOf(
        10.0 to 100.0, 10.5 to 101.0, Double.NaN to 102.0, 11.0 to 103.0, 11.5 to 104.0
    ))
    check(cleanSegments.size == 2 && cleanSegments.all { it.size == 2 }) { "invalid map point bridged a gap" }

    val dropped = StormEngine(5)
    dropped.spawnMain()
    dropped.advance(2.0)
    check(dropped.droppedWallSeconds >= 1.7) { "lag clamp not recorded" }

    val highRefreshBudget = AdaptiveFrameBudget.calculate(2, false, 0, 1)
    val powerSaveBudget = AdaptiveFrameBudget.calculate(2, true, 0, 1)
    val moderateDeviceBudget = AdaptiveFrameBudget.calculate(2, false, 2, 1)
    val severeDeviceBudget = AdaptiveFrameBudget.calculate(2, false, 3, 1)
    val criticalDeviceBudget = AdaptiveFrameBudget.calculate(2, false, 4, 1)
    val crowdedBudget = AdaptiveFrameBudget.calculate(2, false, 0, 12)
    check(powerSaveBudget.markerIntervalNanos >= highRefreshBudget.markerIntervalNanos)
    check(powerSaveBudget.mapIntervalNanos >= highRefreshBudget.mapIntervalNanos)
    check(moderateDeviceBudget.mapIntervalNanos > highRefreshBudget.mapIntervalNanos)
    check(severeDeviceBudget.mapIntervalNanos > moderateDeviceBudget.mapIntervalNanos)
    check(criticalDeviceBudget.mapIntervalNanos > severeDeviceBudget.mapIntervalNanos)
    check(crowdedBudget.mapIntervalNanos > highRefreshBudget.mapIntervalNanos)
    check(highRefreshBudget.markerIntervalNanos == 16_000_000L)

    // V7 challenge framework: mission starts are reproducible and create their defined storm rosters.
    check(ScenarioChallengeCenter.all.size == 5) { "V7 challenge catalog must contain five missions" }
    val missionEngine = StormEngine(10)
    missionEngine.spawnMain(2.0, 2.0)
    missionEngine.advance(1.0)
    val riMission = ScenarioChallengeCenter.start(missionEngine, "rapid_intensification")
    check(missionEngine.simulatedHours == 0.0 && missionEngine.activeStorms().size == 1) { "challenge reset did not clear prior simulation" }
    check(missionEngine.selectedStorm()?.latitude == riMission.startLatitude) { "challenge start position mismatch" }
    check(missionEngine.manualControl) { "challenge should enable joystick control by default" }
    missionEngine.setSelectedWindSpeed(42.0)
    val completedRi = ScenarioChallengeCenter.evaluate(missionEngine, riMission, 0.0)
    check(completedRi.completed && completedRi.score in 75..100) { "rapid-intensification challenge evaluation failed" }

    // Fujiwhara steps are counted and carried through save/restore for mission evaluation.
    val pairMission = ScenarioChallengeCenter.start(missionEngine, "fujiwhara_pair")
    check(missionEngine.activeStorms().size == 2) { "Fujiwhara challenge should start two storms" }
    repeat(300) { missionEngine.advance(1.0 / 30.0) }
    check(missionEngine.fujiwharaInteractionSteps > 0L) { "close storm pair did not register Fujiwhara interactions" }
    val savedInteractionSteps = missionEngine.fujiwharaInteractionSteps
    val pairProgress = ScenarioChallengeCenter.evaluate(missionEngine, pairMission, 0.0)
    check(pairProgress.fraction > 0.0) { "Fujiwhara challenge progress did not advance" }
    val restoredPair = StormEngine(1)
    restoredPair.restoreState(missionEngine.exportState())
    check(restoredPair.fujiwharaInteractionSteps == savedInteractionSteps) { "Fujiwhara interaction count was not persisted" }

    // Multi-storm mission preloads the expected roster and the engine still respects the hard cap.
    val multiMission = ScenarioChallengeCenter.start(missionEngine, "three_storm_watch")
    check(missionEngine.activeStorms().size == 3) { "multi-storm challenge did not initialize three storms" }
    check(multiMission.deadlineHours > multiMission.targetHours)

    // Ensemble diagnostic correctly handles endpoints straddling the international date line.
    val ensembleSummary = EnsembleDiagnostics.summarize(listOf(
        listOf(10.0 to 179.5), listOf(10.2 to -179.5), listOf(9.8 to 179.8), listOf(10.1 to -179.8)
    )) ?: error("ensemble diagnostic returned null for valid tracks")
    check(ensembleSummary.memberCount == 4)
    check(abs(abs(ensembleSummary.meanLongitude) - 180.0) < 1.0) { "circular longitude mean crossed the date line incorrectly: ${ensembleSummary.meanLongitude}" }
    check(ensembleSummary.meanSpreadKm > 0.0 && ensembleSummary.percentile90SpreadKm >= ensembleSummary.meanSpreadKm)

    println("V7 CORE SMOKE TEST PASSED")
    println("rates=${rates.map { it.first }}Hz, simulatedHours=${ref.simulatedHours}, physicsSteps=${ref.physicsSteps}")
    println("ensembleIsolation=PASS, stormCap=PASS, highLoad32x=PASS, globalBasins=${snapshot.regions.size}, datelineSeam=PASS, lagClamp=PASS")
    println("environmentPresets=PASS, steeringPersistence=PASS, trackGeometry=PASS")
    println("adaptiveFrameBudget=PASS (power-save, thermal, storm-load); fixed 30 Hz physics remains unchanged")
    println("V7 challenges=PASS (5 missions, reset, scoring, multi-storm, Fujiwhara persistence); ensembleDiagnostics=PASS")
}
