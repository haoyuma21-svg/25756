@echo off
setlocal
set VERSION=8.14.6
set SHA256=7988ed071b2a07900e2ec715fca15c6ab72bce6db433af301fa7fa7e9407bd24
set BASE=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin\typhoonlab
set GRADLE=%BASE%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo First build requires downloading Gradle %VERSION% (SHA-256 will be verified).
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $archive='%BASE%\gradle-%VERSION%-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile $archive; $actual=(Get-FileHash $archive -Algorithm SHA256).Hash.ToLower(); if ($actual -ne '%SHA256%') { Remove-Item $archive -Force; throw 'Gradle SHA-256 verification failed.' }; Expand-Archive -Force $archive '%BASE%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE%" %*
endlocal
