package com.typhoonlab.mobile

import kotlin.math.*

/** Compact deterministic summary of the final positions from an ensemble of sandbox tracks. */
data class EnsembleSummary(
    val memberCount: Int,
    val meanLatitude: Double,
    val meanLongitude: Double,
    val meanSpreadKm: Double,
    val percentile90SpreadKm: Double
)

object EnsembleDiagnostics {
    fun summarize(tracks: List<List<Pair<Double, Double>>>): EnsembleSummary? {
        val endpoints = tracks.mapNotNull { it.lastOrNull() }
            .filter { it.first.isFinite() && it.second.isFinite() && it.first in -90.0..90.0 }
        if (endpoints.isEmpty()) return null
        val meanLat = endpoints.map { it.first }.average()
        val sinLon = endpoints.sumOf { sin(Math.toRadians(it.second)) }
        val cosLon = endpoints.sumOf { cos(Math.toRadians(it.second)) }
        val meanLon = StormEngine.wrapLon(Math.toDegrees(atan2(sinLon, cosLon)))
        val distances = endpoints.map { (lat, lon) -> greatCircleKm(meanLat, meanLon, lat, lon) }.sorted()
        val meanSpread = distances.average()
        val p90Index = ceil(distances.size * 0.90).toInt().minus(1).coerceIn(distances.indices)
        return EnsembleSummary(endpoints.size, meanLat, meanLon, meanSpread, distances[p90Index])
    }

    private fun greatCircleKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(StormEngine.wrapLon(lon2 - lon1))
        val a = (sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)).coerceIn(0.0, 1.0)
        return 6371.0 * 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
    }
}
