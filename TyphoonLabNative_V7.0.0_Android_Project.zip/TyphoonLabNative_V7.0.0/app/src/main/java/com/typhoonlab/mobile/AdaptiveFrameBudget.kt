package com.typhoonlab.mobile

/** Pure adaptive update budget; simulation physics fixed-step timing is intentionally untouched. */
data class FrameBudget(
    val markerIntervalNanos: Long,
    val mapIntervalNanos: Long,
    val dashboardIntervalNanos: Long
)

object AdaptiveFrameBudget {
    fun calculate(
        performanceMode: Int,
        powerSaveMode: Boolean,
        thermalStatus: Int,
        activeStormCount: Int
    ): FrameBudget {
        val base = when (performanceMode.coerceIn(0, 2)) {
            0 -> FrameBudget(160_000_000L, 330_000_000L, 500_000_000L)
            1 -> FrameBudget(33_000_000L, 125_000_000L, 300_000_000L)
            else -> FrameBudget(16_000_000L, 83_000_000L, 250_000_000L)
        }
        val loadFactor = when {
            activeStormCount >= 10 -> 2.5
            activeStormCount >= 7 -> 1.8
            activeStormCount >= 4 -> 1.3
            else -> 1.0
        }
        // Android PowerManager constants: LIGHT=1, MODERATE=2, SEVERE=3,
        // CRITICAL=4, EMERGENCY=5, SHUTDOWN=6. Slow decorative map updates
        // before severe throttling, while leaving fixed-step physics unchanged.
        val thermalFactor = when {
            thermalStatus >= 4 -> 2.5 // CRITICAL or worse
            thermalStatus == 3 -> 2.0 // SEVERE
            thermalStatus == 2 -> 1.35 // MODERATE
            thermalStatus == 1 -> 1.1 // LIGHT
            else -> 1.0
        }
        val powerFactor = if (powerSaveMode) 2.0 else 1.0
        val factor = maxOf(loadFactor, thermalFactor, powerFactor)
        fun scale(value: Long, minimum: Long): Long = (value.toDouble() * factor).toLong().coerceAtLeast(minimum)
        return FrameBudget(
            markerIntervalNanos = scale(base.markerIntervalNanos, 16_000_000L),
            mapIntervalNanos = scale(base.mapIntervalNanos, 50_000_000L),
            dashboardIntervalNanos = scale(base.dashboardIntervalNanos, 150_000_000L)
        )
    }
}
