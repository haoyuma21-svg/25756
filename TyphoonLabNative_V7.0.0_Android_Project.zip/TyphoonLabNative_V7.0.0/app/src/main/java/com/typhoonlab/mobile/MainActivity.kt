package com.typhoonlab.mobile

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.res.Configuration
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.StatFs
import android.app.ActivityManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.provider.Settings
import android.util.AtomicFile
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import kotlin.math.*
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private enum class AppMode { TYPHOON, DEFENSE }
    private data class MenuSecond(val title: String, val actions: List<String>)
    private data class MenuFirst(val title: String, val seconds: List<MenuSecond>)

    private val engine = StormEngine()
    private var mode = AppMode.TYPHOON
    private var mapView: MapView? = null
    private var mapViewStarted = false
    private var mapViewResumed = false
    private var activityStarted = false
    private var activityResumed = false
    private var map: MapLibreMap? = null
    private var currentStyle: Style? = null
    private var stormSource: GeoJsonSource? = null
    private var stormLabelSource: GeoJsonSource? = null
    private var trackSource: GeoJsonSource? = null
    private var ensembleSource: GeoJsonSource? = null
    private var citySource: GeoJsonSource? = null
    private var windSource: GeoJsonSource? = null
    private var windCoreSource: GeoJsonSource? = null
    private var rainBandSource: GeoJsonSource? = null
    private var eyeSource: GeoJsonSource? = null
    private val satelliteLayerIds = mutableListOf<String>()
    private val satelliteSourceIds = mutableListOf<String>()

    private lateinit var root: FrameLayout
    private lateinit var menuPanel: LinearLayout
    private lateinit var menuContent: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var dashboardText: TextView
    private lateinit var pauseButton: Button
    private lateinit var speedButton: Button
    private lateinit var modeText: TextView
    private lateinit var joystick: JoystickPadView
    private var topOverlay: View? = null
    private var bottomOverlay: View? = null
    private var joystickOverlay: View? = null
    private var statusOverlay: View? = null
    private var mapZoomOverlay: View? = null
    private var menuOverlay: View? = null

    private val worker = Executors.newSingleThreadExecutor()
    private val MAX_STATE_FILE_BYTES = 16L * 1024L * 1024L
    private var loopStarted = false
    private var paused = false
    private var lastFrameNanos = 0L
    private var lastMarkerFrameNanos = 0L
    private var lastMapFrameNanos = 0L
    private var lastDashboardNanos = 0L
    private var fpsWindowStartNanos = 0L
    private var fpsFrameCount = 0
    private var measuredFps = 0
    private var adaptiveFrameBudget = FrameBudget(16_000_000L, 83_000_000L, 250_000_000L)
    private var lastAdaptiveBudgetNanos = 0L
    private var performanceMode = 2 // 0 power saver, 1 balanced, 2 high refresh
    private var showWindField = true
    private var showRainBands = true
    private var showEye = true
    private var showTrack = true
    private var showDashboard = true
    private var menuSearchQuery = ""
    private var activeSatellitePath: String? = null
    private var geometryStormCount = 0
    private var lastLayoutScreenWidthDp = -1
    private var lastLayoutOrientation = Configuration.ORIENTATION_UNDEFINED
    private var selectedFirst = 0
    private var selectedSecond = 0
    private var showEnsemble = false
    private var ensembleTracks: List<List<Pair<Double, Double>>> = emptyList()
    private var clickToSpawn = false
    private var evacuationPercent = 0
    private var rescueUnits = 0
    private var shelterCapacity = 12000
    private var warningIssued = "尚未发布"
    private var activeChallengeId: String? = null
    private var activeChallengeStartedHours = 0.0
    @Volatile private var mapDownloadRunning = false
    private val weatherProbeRunning = AtomicBoolean(false)
    private var weatherLoadingDialog: AlertDialog? = null
    private val V60_CHANGELOG_SUMMARY = """
        V6.0 全球气象指挥中心：新增全球七大热带气旋海盆态势汇总、活动风暴列表、最高风险/风速/最低气压统计与海盆快速定位。数据明确标注为本地模拟态势，不冒充官方实时观测。

        引擎优化 1：物理模拟改为固定 30 Hz 步长，渲染帧率与物理结果解耦，减少不同刷新率设备导致的模拟漂移，并限制异常卡顿后的追赶步数。
        引擎优化 2：集合预报使用独立随机数流，打开预报不会扰动主模拟随机序列；同时限制活动风暴数量、回放帧、历史轨迹与事件日志的容量。

        Android 16：targetSdk 36、edge-to-edge 系统栏安全区、大屏/折叠屏窗口适配、预测性返回回调与进程重建状态恢复。

        稳定性：统一 MapView 生命周期转发；硬化存档输入边界；配置变化保留场景；控制 GeoJSON 更新频率；增加全球态势与存档边界回归测试。
    """.trimIndent()

    private val V62_CHANGELOG_SUMMARY = """
        V6.2：新增五种环境场景预设（西北太平洋有利增强、强风切变、近岸登陆、冷海温干燥、季风槽扰动），只调整环境参数，不删除或重置当前风暴。
        新增环境支持诊断指数与可调引导气流方向；引导气流改为真实参与自动路径转向，旧存档缺少该字段时默认使用 290°。
        地图路径跨越国际日期变更线时自动拆段，避免轨迹横跨整张世界地图；原有 PMTiles、存档与离线包格式保持兼容。
        构建：新增 Windows PowerShell APK 构建与 ADB 安装助手；最终 APK 必须通过签名及 16 KB 原生库检查。
    """.trimIndent()

    private val V61_CHANGELOG_SUMMARY = """
        V6.1 全球气象环境探针：用户主动查询所选风暴中心/地图中心附近的天气与海洋模式网格数据。显示请求坐标、模型网格坐标、模式时间和数据时间；支持本机缓存、失败回退与复制简报。
        V6.1.1 气象探针历史档案：最多保留最近 24 次有效查询，可逐条回看并复制导出 JSON；历史缓存采用版本化 schema 和每条大小限制。
        天气模型不冒充台风中心实测，也不会自动覆盖模拟环境。

        数据源：Open-Meteo Forecast API 与 Marine API。查询需要网络；离线地图、台风沙盒与存档不依赖该功能。

        其他改进：更新版本标识、补充数据来源说明、增加 APK Debug 构建脚本与 16 KB 原生库发布检查入口。
    """.trimIndent()

    private val V70_CHANGELOG_SUMMARY = """
        V7.0.0 大更新：新增情景挑战中心，提供暖海快速增强、强风切变生存、近岸登陆、藤原效应双风暴和多风暴协同监测五项挑战；每项具有独立随机种子、环境预设、起始风暴与可追踪目标。
        中等更新 1：挑战状态和起始模拟时间写入本地设置，配合自动存档可在应用重启后继续任务。
        中等更新 2：新增藤原效应相互作用步数统计，并写入模拟存档；不再只凭画面判断是否发生相互作用。
        中等更新 3：新增集合预报终点平均位置、平均离散距离和 90 百分位离散距离摘要。
        中等更新 4：地图风圈几何细节按性能模式、活动风暴数量和帧回调情况自适应分级；物理模拟固定 30 Hz 不变。
        中等更新 5：重新整理挑战入口与状态查看路径，菜单搜索可直接检索挑战中心。
        小更新 1：版本标识升级到 7.0.0 / versionCode 70，包名保持不变。
        小更新 2：启动页和版本说明同步更新，明确这是教育/娱乐沙盒而非业务预报。
        小更新 3：Windows APK 检查脚本改为校验 V7.0.0 版本信息。
        小更新 4：新增无需 Android Studio 的云端 Debug APK 构建工作流，构建产物可在手机浏览器中领取并安装。
        Android 适配基础沿用 V6.5：compile/target SDK 36、minSdk 26、Android 15/16 与 HyperOS/MIUI 公开 API 适配策略。
    """.trimIndent()

    private val typhoonMenuTree: List<MenuFirst> = listOf(
        MenuFirst("V7 情景挑战", listOf(
            MenuSecond("挑战中心", listOf("打开V7情景挑战中心", "查看当前挑战进度"))
        )),
        MenuFirst("全球气象中心", listOf(
            MenuSecond("全球态势", listOf("打开全球气象指挥中心", "全球视图", "当前风暴总览", "查询当前风暴气象环境", "查看上次气象环境", "查看气象探针历史档案", "气象数据来源说明"))
        )),
        MenuFirst("风暴控制", listOf(
            MenuSecond("生成与选择", listOf("生成主台风", "生成副台风", "切换主控台风", "清除已消散风暴", "地图点选生成")),
            MenuSecond("移动与路径", listOf("摇杆控制开关", "移动速度", "路径推进倍率", "模拟时间倍率", "定位当前主台风", "显示/隐藏历史路径")),
            MenuSecond("强度与结构", listOf("最大风速", "中心气压", "快速增强实验", "快速增强机制开关", "眼墙置换实验", "显示风场与风圈", "显示螺旋雨带", "显示台风眼")),
            MenuSecond("生命史与回放", listOf("查看生命史事件", "风暴时间轴回放", "导出回放时间轴", "导出风暴生命史", "AI防灾建议"))
        )),
        MenuFirst("环境实验", listOf(
            MenuSecond("海洋环境", listOf("海表温度", "海洋热含量")),
            MenuSecond("大气环境", listOf("环境湿度", "垂直风切变", "引导气流方向", "快速增强机制开关")),
            MenuSecond("场景预设与诊断", listOf("环境场景预设", "环境支持诊断")),
            MenuSecond("地形参数", listOf("陆地摩擦", "显示地形影响说明"))
        )),
        MenuFirst("预报研究", listOf(
            MenuSecond("集合预报", listOf("生成16成员", "生成32成员", "隐藏集合路径")),
            MenuSecond("路径分析", listOf("显示历史路径", "预报不确定性说明")),
            MenuSecond("实验设置", listOf("随机种子", "模拟时间倍率", "高帧率模式"))
        )),
        MenuFirst("地图与数据", listOf(
            MenuSecond("离线地图中心", listOf("打开离线地图下载中心", "从手机导入影像包", "管理已导入影像", "切换卫星底图", "移除卫星底图", "存储空间管理", "地图包容量说明")),
            MenuSecond("存档与复盘", listOf("保存模拟进度", "读取模拟进度", "恢复上次自动存档", "导出模拟数据")),
            MenuSecond("地图视图", listOf("地图放大", "地图缩小", "全球视图", "显示/隐藏数据面板"))
        )),
        MenuFirst("系统设置", listOf(
            MenuSecond("性能与显示", listOf("性能模式", "高帧率模式", "显示/隐藏数据面板")),
            MenuSecond("Android 设备适配", listOf("Android 设备适配中心", "打开应用系统设置", "电池优化设置", "版本更新说明", "模拟模型免责声明"))
        ))
    )

    private val defenseMenuTree: List<MenuFirst> = listOf(
        MenuFirst("V7 情景挑战", listOf(
            MenuSecond("挑战中心", listOf("打开V7情景挑战中心", "查看当前挑战进度"))
        )),
        MenuFirst("全球气象中心", listOf(
            MenuSecond("全球态势", listOf("打开全球气象指挥中心", "全球视图", "当前风暴总览", "查询当前风暴气象环境", "查看上次气象环境", "查看气象探针历史档案", "气象数据来源说明"))
        )),
        MenuFirst("防灾指挥", listOf(
            MenuSecond("风险研判", listOf("风险等级评估", "AI防灾建议", "影响范围估算", "风暴时间轴回放")),
            MenuSecond("预警发布", listOf("发布蓝色预警", "发布黄色预警", "发布橙色预警", "发布红色预警")),
            MenuSecond("应急行动", listOf("疏散25%", "疏散50%", "疏散75%", "调度救援力量", "扩充避难所")),
            MenuSecond("指挥视图", listOf("定位当前主台风", "地图放大", "地图缩小", "全球视图", "显示/隐藏数据面板"))
        )),
        MenuFirst("风暴监测", listOf(
            MenuSecond("风暴列表", listOf("生成主台风", "生成副台风", "切换主控台风", "查看生命史事件")),
            MenuSecond("结构监测", listOf("显示风场与风圈", "显示螺旋雨带", "显示台风眼", "显示/隐藏历史路径")),
            MenuSecond("环境监测", listOf("海表温度", "环境湿度", "垂直风切变", "海洋热含量", "环境场景预设", "环境支持诊断", "引导气流方向"))
        )),
        MenuFirst("预报中心", listOf(
            MenuSecond("集合预报", listOf("生成16成员", "生成32成员", "隐藏集合路径", "预报不确定性说明")),
            MenuSecond("模拟回放", listOf("风暴时间轴回放", "导出回放时间轴", "导出风暴生命史"))
        )),
        MenuFirst("离线地图", listOf(
            MenuSecond("地图下载", listOf("打开离线地图下载中心", "从手机导入影像包", "继续未完成下载")),
            MenuSecond("地图管理", listOf("管理已导入影像", "切换卫星底图", "移除卫星底图", "存储空间管理", "地图包容量说明"))
        )),
        MenuFirst("演练存档", listOf(
            MenuSecond("情景管理", listOf("保存模拟进度", "读取模拟进度", "恢复上次自动存档", "导出模拟数据")),
            MenuSecond("系统设置", listOf("模拟时间倍率", "性能模式", "版本更新说明", "模拟模型免责声明"))
        ))
    )

    private val menuTree: List<MenuFirst>
        get() = if (mode == AppMode.DEFENSE) defenseMenuTree else typhoonMenuTree


    private val importResult = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) onMapPackSelected(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        MapLibre.getInstance(applicationContext)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::menuPanel.isInitialized && menuPanel.visibility == View.VISIBLE) {
                    menuPanel.visibility = View.GONE
                } else if (mapView != null) {
                    showHome()
                } else {
                    finish()
                }
            }
        })

        val challengePrefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
        activeChallengeId = challengePrefs.getString("v70_active_challenge", null)
        activeChallengeStartedHours = challengePrefs.getFloat("v70_challenge_start_hours", 0f).toDouble()
        if (ScenarioChallengeCenter.find(activeChallengeId) == null) {
            activeChallengeId = null
            activeChallengeStartedHours = 0.0
        }
        val restoreSimulation = savedInstanceState?.getBoolean("tl_simulation_open", false) == true
        if (restoreSimulation) {
            mode = if (savedInstanceState.getInt("tl_mode", 0) == 1) AppMode.DEFENSE else AppMode.TYPHOON
            // Large storm histories are persisted outside the Binder state Bundle.
            // Only compact UI state is carried by onSaveInstanceState.
            val restorePrefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
            val autoJson = runCatching { readStateFile("auto_state.json", "auto_state") }.getOrNull()
            val restored = if (autoJson.isNullOrBlank()) false else runCatching { engine.restoreState(autoJson) }.isSuccess
            evacuationPercent = restorePrefs.getInt("auto_evacuation", savedInstanceState.getInt("tl_evacuation", 0))
            rescueUnits = restorePrefs.getInt("auto_rescue", savedInstanceState.getInt("tl_rescue", 0))
            shelterCapacity = restorePrefs.getInt("auto_shelter", savedInstanceState.getInt("tl_shelter", 12000))
            warningIssued = restorePrefs.getString("auto_warning", savedInstanceState.getString("tl_warning", "尚未发布")) ?: "尚未发布"
            if (!restored) {
                toast("自动存档不可用，已创建新的演练风暴")
                engine.spawnMain(if (mode == AppMode.DEFENSE) 18.0 else 15.0, if (mode == AppMode.DEFENSE) 127.0 else 140.0)
                activeChallengeId = null
                activeChallengeStartedHours = 0.0
                challengePrefs.edit().remove("v70_active_challenge").remove("v70_challenge_start_hours").apply()
            }
            paused = savedInstanceState.getBoolean("tl_paused", false)
            buildGameScreen(savedInstanceState)
            initializeMap(restoreCamera = true)
            // onResume() starts the render loop after the MapView lifecycle is resumed.
        } else {
            showHome()
        }
    }

    private fun showHome() {
        if (mapView != null) persistAutoState()
        stopLoop()
        disposeMapView()
        map = null
        currentStyle = null
        val home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 19, 33), Color.rgb(9, 48, 69), Color.rgb(5, 20, 35)))
        }
        val logo = TextView(this).apply {
            text = "🌀  台风实验室"
            textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8))
        }
        val subtitle = TextView(this).apply {
            text = "TYPHOON LAB  ·  Android 原生离线气象沙盒"
            textSize = 12f; setTextColor(Color.rgb(129, 191, 211)); gravity = Gravity.CENTER
        }
        val note = TextView(this).apply {
            text = "本地地图引擎 · 超大离线影像包 · 台风模拟 · 防灾推演\n无需浏览器，也不依赖在线地图瓦片。"
            textSize = 13f; setTextColor(Color.rgb(187, 211, 225)); gravity = Gravity.CENTER
            setPadding(dp(8), dp(22), dp(8), dp(26))
        }
        val storm = homeButton("🌀  进入台风模式", true) {
            mode = AppMode.TYPHOON; enterSimulation()
        }
        val defense = homeButton("🛡️  进入防范台风模式", false) {
            mode = AppMode.DEFENSE; enterSimulation()
        }
        val data = TextView(this).apply {
            text = "版本 7.0.0 · Android 15 / 16 · 澎湃 OS / MIUI 适配\n原生台风沙盒 · 情景挑战中心 · 设备诊断与云端 APK 构建。"
            textSize = 10f; setTextColor(Color.rgb(115, 150, 169)); gravity = Gravity.CENTER
            setPadding(dp(16), dp(28), dp(16), 0)
        }
        home.addView(logo, matchWrap())
        home.addView(subtitle, matchWrap())
        home.addView(note, matchWrap())
        home.addView(storm, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)).apply { bottomMargin = dp(12) })
        home.addView(defense, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        home.addView(homeButton("⚙  Android 设备适配中心", false) { showAndroidCompatibilityCenter() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(12) })
        home.addView(data, matchWrap())
        setContentView(home)
        ViewCompat.setOnApplyWindowInsetsListener(home) { view, windowInsets ->
            val safe = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(dp(24) + safe.left, dp(24) + safe.top, dp(24) + safe.right, dp(24) + safe.bottom)
            windowInsets
        }
        ViewCompat.requestApplyInsets(home)
    }

    private fun homeButton(label: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 16f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(if (primary) Color.rgb(0, 133, 157) else Color.rgb(20, 58, 78), 18)
        setOnClickListener { action() }
    }

    private fun enterSimulation() {
        selectedFirst = 0
        selectedSecond = 0
        menuSearchQuery = ""
        if (engine.activeStorms().isEmpty()) {
            var challengeRestored = false
            if (activeChallengeId != null) {
                val autoJson = runCatching { readStateFile("auto_state.json", "auto_state") }.getOrNull()
                if (!autoJson.isNullOrBlank()) {
                    challengeRestored = runCatching { engine.restoreState(autoJson) }.isSuccess
                }
                if (!challengeRestored) {
                    activeChallengeId = null
                    activeChallengeStartedHours = 0.0
                    getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit()
                        .remove("v70_active_challenge").remove("v70_challenge_start_hours").apply()
                }
            }
            if (engine.activeStorms().isEmpty()) {
                if (mode == AppMode.DEFENSE) engine.spawnMain(18.0, 127.0) else engine.spawnMain(15.0, 140.0)
            }
        }
        buildGameScreen()
        initializeMap()
        paused = false
        startLoop()
    }

    private fun buildGameScreen(mapSavedState: Bundle? = null) {
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5, 18, 30)) }
        val map = MapView(this)
        mapView = map
        map.onCreate(mapSavedState)
        if (activityStarted) { map.onStart(); mapViewStarted = true }
        if (activityResumed) { map.onResume(); mapViewResumed = true }
        root.addView(map, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(Color.argb(225, 5, 19, 31), 12)
        }
        val menuButton = smallButton("☰ 菜单") { toggleMenu() }
        modeText = TextView(this).apply {
            text = if (mode == AppMode.TYPHOON) "台风模式" else "防灾指挥模式"
            textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(9), 0, dp(4), 0)
        }
        val homeButton = smallButton("主菜单") { showHome() }
        val commandTopButton = smallButton("🌐") { showGlobalCommandCenter() }
        top.addView(menuButton); top.addView(modeText, LinearLayout.LayoutParams(0, -1, 1f)); top.addView(commandTopButton); top.addView(homeButton)
        topOverlay = top
        root.addView(top, FrameLayout.LayoutParams(-1, dp(48), Gravity.TOP).apply { setMargins(dp(8), dp(8), dp(8), 0) })

        dashboardText = TextView(this).apply {
            text = "等待风暴数据"; textSize = 11f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(9), dp(10), dp(9)); background = rounded(Color.argb(220, 7, 28, 44), 12)
        }
        root.addView(dashboardText, FrameLayout.LayoutParams(minOf(dp(208), (resources.displayMetrics.widthPixels * 0.54f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(62), dp(8), 0)
        })
        dashboardText.visibility = if (showDashboard) View.VISIBLE else View.GONE

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5)); background = rounded(Color.argb(225, 5, 19, 31), 14)
        }
        pauseButton = smallButton("Ⅱ 暂停") { togglePause() }
        speedButton = smallButton("×8") { cycleSpeed() }
        val spawn = smallButton("＋ 台风") {
            val storm = engine.spawnMain(); toast("已生成 ${storm.name}"); updateDashboard(); updateMapLayers()
        }
        val ai = smallButton("AI 建议") { showInfo("AI 防灾建议", engine.aiAdvice()) }
        val global = smallButton("🌐 全球") { showGlobalCommandCenter() }
        listOf(pauseButton, speedButton, spawn, global, ai).forEach { bottom.addView(it, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), 0, dp(2), 0) }) }
        bottomOverlay = bottom
        root.addView(bottom, FrameLayout.LayoutParams(-1, dp(54), Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(8), dp(7)) })

        joystick = JoystickPadView(this) { x, y -> engine.joystickX = x; engine.joystickY = y }
        joystickOverlay = joystick
        root.addView(joystick, FrameLayout.LayoutParams(dp(108), dp(108), Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(12), 0, 0, dp(78))
        })
        statusText = TextView(this).apply {
            text = "摇杆控制方向 · 长按地图拖动 · 双指缩放"
            textSize = 10f; setTextColor(Color.rgb(185, 214, 228)); setPadding(dp(8), dp(5), dp(8), dp(5))
            background = rounded(Color.argb(175, 5, 20, 32), 8)
        }
        statusOverlay = statusText
        root.addView(statusText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(10), dp(67))
        })

        menuPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(16))
            background = rounded(Color.rgb(7, 26, 42), 16); elevation = dp(18).toFloat(); visibility = View.GONE
        }
        val adaptiveMenuWidth = minOf((resources.displayMetrics.widthPixels * 0.88f).toInt(), dp(390))
        menuPanel.layoutParams = FrameLayout.LayoutParams(adaptiveMenuWidth, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START).apply {
            setMargins(dp(7), dp(61), dp(7), dp(68))
        }
        val head = TextView(this).apply {
            text = "功能中心  /  一级 → 二级 → 三级"
            textSize = 13f; setTextColor(Color.rgb(77, 218, 235)); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), dp(4), dp(6), dp(10))
        }
        menuContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply { isFillViewport = true; addView(menuContent) }
        menuPanel.addView(head); menuPanel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val close = smallButton("关闭菜单") { menuPanel.visibility = View.GONE }
        menuPanel.addView(close, LinearLayout.LayoutParams(-1, dp(40)))
        menuOverlay = menuPanel
        root.addView(menuPanel)

        val mapZoom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4)); background = rounded(Color.argb(205, 5, 19, 31), 12)
        }
        mapZoom.addView(smallButton("＋") { zoomMap(1.0) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        mapZoom.addView(smallButton("－") { zoomMap(-1.0) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        mapZoom.addView(smallButton("◎") { showGlobalMap() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        mapZoomOverlay = mapZoom
        root.addView(mapZoom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            setMargins(0, dp(72), dp(8), dp(60))
        })

        setContentView(root)
        applySimulationWindowInsets()
        lastLayoutScreenWidthDp = resources.configuration.screenWidthDp
        lastLayoutOrientation = resources.configuration.orientation
        renderMenu()
    }

    private fun initializeMap(restoreCamera: Boolean = false) {
        mapView?.getMapAsync { mapLibreMap ->
            this.map = mapLibreMap
            mapLibreMap.uiSettings.isCompassEnabled = true
            mapLibreMap.uiSettings.isRotateGesturesEnabled = true
            mapLibreMap.uiSettings.isTiltGesturesEnabled = false
            mapLibreMap.setStyle(Style.Builder().fromJson(baseStyleJson())) { style ->
                currentStyle = style
                addBaseLayers(style)
                val packs = MapPackManager.listPacks(this)
                val savedPath = getSharedPreferences("typhoon_lab", MODE_PRIVATE).getString("active_map_pack", null)
                val activePack = packs.firstOrNull { it.file.absolutePath == savedPath } ?: packs.firstOrNull()
                activePack?.let { addSatelliteLayer(it.file) }
                if (!restoreCamera) {
                    mapLibreMap.cameraPosition = CameraPosition.Builder()
                        .target(LatLng(20.0, 135.0)).zoom(2.4).build()
                }
                mapLibreMap.addOnMapClickListener { point ->
                    if (clickToSpawn) {
                        engine.spawnMain(point.latitude, point.longitude)
                        clickToSpawn = false
                        toast("已在地图位置生成主台风")
                        updateMapLayers()
                        renderMenu()
                    }
                    true
                }
                updateMapLayers()
            }
        }
    }

    private fun applySimulationWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, windowInsets ->
            val safe = windowInsets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            (topOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(dp(8) + safe.left, dp(8) + safe.top, dp(8) + safe.right, 0)
                topOverlay?.layoutParams = params
            }
            (dashboardText.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(0, dp(62) + safe.top, dp(8) + safe.right, 0)
                params.width = if (resources.configuration.screenWidthDp >= 600) dp(300) else minOf(dp(220), (resources.displayMetrics.widthPixels * 0.54f).toInt())
                dashboardText.layoutParams = params
            }
            (bottomOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(dp(8) + safe.left, 0, dp(8) + safe.right, dp(7) + safe.bottom)
                params.width = if (resources.configuration.screenWidthDp >= 760) minOf(dp(760), resources.displayMetrics.widthPixels - safe.left - safe.right) else ViewGroup.LayoutParams.MATCH_PARENT
                params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomOverlay?.layoutParams = params
            }
            (joystickOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(dp(12) + safe.left, 0, 0, dp(78) + safe.bottom)
                joystickOverlay?.layoutParams = params
            }
            (statusOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(0, 0, dp(10) + safe.right, dp(67) + safe.bottom)
                statusOverlay?.layoutParams = params
            }
            (menuOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(dp(7) + safe.left, dp(61) + safe.top, dp(7) + safe.right, dp(68) + safe.bottom)
                params.width = if (resources.configuration.screenWidthDp >= 600) dp(430) else minOf((resources.displayMetrics.widthPixels * 0.88f).toInt(), dp(390))
                menuOverlay?.layoutParams = params
            }
            (mapZoomOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.setMargins(0, dp(72) + safe.top, dp(8) + safe.right, dp(60) + safe.bottom)
                mapZoomOverlay?.layoutParams = params
            }
            windowInsets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun baseStyleJson(): String = """
        {"version":8,"name":"Typhoon Lab Offline","sources":{},"layers":[
          {"id":"background","type":"background","paint":{"background-color":"#09253a"}}
        ]}
    """.trimIndent()

    private fun addBaseLayers(style: Style) {
        val landFeatures = worldPolygons().map { coordinates ->
            val points = coordinates.map { Point.fromLngLat(it.first, it.second) }.toMutableList()
            if (points.isNotEmpty()) points.add(points.first())
            Feature.fromGeometry(Polygon.fromLngLats(listOf(points)))
        }.toTypedArray()
        style.addSource(GeoJsonSource("land-source", FeatureCollection.fromFeatures(landFeatures)))
        style.addLayer(FillLayer("land-fill", "land-source").withProperties(
            PropertyFactory.fillColor("#173d4d"), PropertyFactory.fillOpacity(0.96f)
        ))
        style.addLayer(LineLayer("land-outline", "land-source").withProperties(
            PropertyFactory.lineColor("#3d7b86"), PropertyFactory.lineWidth(0.65f), PropertyFactory.lineOpacity(0.8f)
        ))

        val cities = listOf(
            "北京" to (116.40 to 39.90), "上海" to (121.47 to 31.23), "福州" to (119.30 to 26.08),
            "厦门" to (118.08 to 24.48), "台北" to (121.56 to 25.04), "香港" to (114.17 to 22.32),
            "广州" to (113.26 to 23.13), "东京" to (139.69 to 35.68), "大阪" to (135.50 to 34.69),
            "马尼拉" to (120.98 to 14.60), "河内" to (105.85 to 21.03), "马德里" to (-3.70 to 40.42),
            "纽约" to (-74.01 to 40.71), "迈阿密" to (-80.19 to 25.76), "悉尼" to (151.21 to -33.87),
            "新加坡" to (103.82 to 1.35)
        )
        val cityFeatures = cities.map { (name, xy) ->
            Feature.fromGeometry(Point.fromLngLat(xy.first, xy.second)).also { it.addStringProperty("name", name) }
        }.toTypedArray()
        citySource = GeoJsonSource("city-source", FeatureCollection.fromFeatures(cityFeatures))
        style.addSource(citySource!!)
        style.addLayer(SymbolLayer("city-labels", "city-source").withProperties(
            PropertyFactory.textField("{name}"), PropertyFactory.textSize(10f),
            PropertyFactory.textColor("#d9eff5"), PropertyFactory.textHaloColor("#082033"),
            PropertyFactory.textHaloWidth(1.3f), PropertyFactory.textAllowOverlap(false)
        ))

        stormSource = GeoJsonSource("storm-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(stormSource!!)
        style.addLayer(CircleLayer("storm-points", "storm-source").withProperties(
            PropertyFactory.circleRadius(8f), PropertyFactory.circleColor("#ff6077"),
            PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(1.8f),
            PropertyFactory.circleOpacity(0.98f)
        ))
        trackSource = GeoJsonSource("track-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(trackSource!!)
        style.addLayer(LineLayer("storm-track", "track-source").withProperties(
            PropertyFactory.lineColor("#ff9a78"), PropertyFactory.lineWidth(2.4f), PropertyFactory.lineOpacity(0.9f)
        ))
        ensembleSource = GeoJsonSource("ensemble-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(ensembleSource!!)
        style.addLayer(LineLayer("ensemble-lines", "ensemble-source").withProperties(
            PropertyFactory.lineColor("#f0d58c"), PropertyFactory.lineWidth(1.0f), PropertyFactory.lineOpacity(0.55f)
        ))
        windSource = GeoJsonSource("wind-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(windSource!!)
        style.addLayerBelow(FillLayer("wind-field", "wind-source").withProperties(
            PropertyFactory.fillColor("#39c7df"), PropertyFactory.fillOpacity(0.12f),
            PropertyFactory.fillOutlineColor("#4ad9eb")
        ), "storm-points")
        windCoreSource = GeoJsonSource("wind-core-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(windCoreSource!!)
        style.addLayerBelow(LineLayer("wind-core-rings", "wind-core-source").withProperties(
            PropertyFactory.lineColor("#a6eff2"), PropertyFactory.lineWidth(1.15f), PropertyFactory.lineOpacity(0.82f)
        ), "storm-points")
        rainBandSource = GeoJsonSource("rain-band-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(rainBandSource!!)
        style.addLayerBelow(FillLayer("rain-band-fill", "rain-band-source").withProperties(
            PropertyFactory.fillColor("#86a7e8"), PropertyFactory.fillOpacity(0.18f),
            PropertyFactory.fillOutlineColor("#a9c4f2")
        ), "storm-points")
        eyeSource = GeoJsonSource("eye-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(eyeSource!!)
        style.addLayer(CircleLayer("storm-eye", "eye-source").withProperties(
            PropertyFactory.circleRadius(3.8f), PropertyFactory.circleColor("#f5fbff"),
            PropertyFactory.circleStrokeColor("#26c7dc"), PropertyFactory.circleStrokeWidth(1.6f)
        ))
        stormLabelSource = GeoJsonSource("storm-label-source", FeatureCollection.fromFeatures(emptyArray<Feature>()))
        style.addSource(stormLabelSource!!)
        style.addLayer(SymbolLayer("storm-labels", "storm-label-source").withProperties(
            PropertyFactory.textField("{name}"), PropertyFactory.textSize(10f),
            PropertyFactory.textColor("#fff0c6"), PropertyFactory.textHaloColor("#071c2b"),
            PropertyFactory.textHaloWidth(1.2f), PropertyFactory.textOffset(arrayOf(0f, 1.3f)),
            PropertyFactory.textAllowOverlap(false)
        ))
    }

    private fun addSatelliteLayer(file: File) {
        val style = currentStyle ?: return
        if (!file.exists()) return
        val suffix = Integer.toHexString(file.absolutePath.hashCode()).replace('-', '0')
        val sourceId = "satellite-source-$suffix"
        val layerId = "satellite-layer-$suffix"
        runCatching {
            removeAllSatelliteLayers()
            val sourceUri = "pmtiles://${Uri.fromFile(file)}"
            style.addSource(RasterSource(sourceId, sourceUri, 512))
            val raster = RasterLayer(layerId, sourceId)
            if (style.getLayer("land-outline") != null) style.addLayerBelow(raster, "land-outline") else style.addLayer(raster)
            if (style.getLayer("land-fill") != null) style.removeLayer("land-fill")
            if (!satelliteSourceIds.contains(sourceId)) satelliteSourceIds.add(sourceId)
            if (!satelliteLayerIds.contains(layerId)) satelliteLayerIds.add(layerId)
            activeSatellitePath = file.absolutePath
            getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit().putString("active_map_pack", activeSatellitePath).apply()
            toast("已加载离线卫星影像：${file.name}")
        }.onFailure {
            toast("影像包加载失败：${it.message ?: "格式或版本不支持"}")
        }
    }

    private fun removeAllSatelliteLayers() {
        val style = currentStyle ?: return
        satelliteLayerIds.toList().forEach { id -> runCatching { style.removeLayer(id) } }
        satelliteSourceIds.toList().forEach { id -> runCatching { style.removeSource(id) } }
        satelliteLayerIds.clear(); satelliteSourceIds.clear()
        activeSatellitePath = null
        getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit().remove("active_map_pack").apply()
        if (style.getLayer("land-fill") == null && style.getSource("land-source") != null) {
            style.addLayerBelow(FillLayer("land-fill", "land-source").withProperties(
                PropertyFactory.fillColor("#173d4d"), PropertyFactory.fillOpacity(0.96f)
            ), "land-outline")
        }
    }

    private fun updateStormPositionLayer() {
        val storms = engine.activeStorms()
        stormSource?.setGeoJson(FeatureCollection.fromFeatures(storms.map { storm ->
            Feature.fromGeometry(Point.fromLngLat(storm.longitude, storm.latitude))
        }.toTypedArray()))
    }

    /** Map detail is an expendable render budget; the fixed 30 Hz physics loop is untouched. */
    private fun geometrySegments(): Int = when {
        performanceMode == 0 || geometryStormCount >= 9 || (measuredFps in 1..29) -> 16
        performanceMode == 1 || geometryStormCount >= 5 || (measuredFps in 30..44) -> 24
        measuredFps >= 90 && geometryStormCount <= 2 -> 48
        else -> 36
    }

    private fun simplifiedTrack(storm: Storm): List<Pair<Double, Double>> {
        val points = storm.history
        val target = when {
            performanceMode == 0 -> 96
            performanceMode == 1 -> 180
            else -> 360
        }
        if (points.size <= target) return points
        val stride = kotlin.math.ceil(points.size.toDouble() / target).toInt().coerceAtLeast(1)
        return buildList(target + 1) {
            points.forEachIndexed { index, point ->
                if (index % stride == 0 || index == points.lastIndex) add(point)
            }
        }
    }

    private fun makeStormRing(storm: Storm, radiusKm: Double, wobble: Double = 0.0): List<Point> {
        val segments = geometrySegments()
        val points = (0 until segments).map { index ->
            val angle = index * Math.PI * 2.0 / segments
            val radius = radiusKm * (1.0 + wobble * sin(angle * 3.0 + storm.ageHours * 0.04))
            val dLat = radius * cos(angle) / 111.0
            val dLon = radius * sin(angle) / (111.0 * cos(Math.toRadians(storm.latitude)).coerceAtLeast(0.18))
            Point.fromLngLat(StormEngine.wrapLon(storm.longitude + dLon), (storm.latitude + dLat).coerceIn(-85.0, 85.0))
        }.toMutableList()
        points.add(points.first())
        return points
    }

    private fun makeSpiralBand(storm: Storm, arm: Int): List<Point> {
        val left = mutableListOf<Point>()
        val right = mutableListOf<Point>()
        val baseAngle = arm * (Math.PI * 2.0 / 3.0) + storm.ageHours * 0.018
        val steps = when {
            performanceMode == 0 || geometryStormCount >= 9 -> 28
            performanceMode == 1 || geometryStormCount >= 5 -> 44
            else -> 60
        }
        for (i in 0..steps) {
            val t = i.toDouble() / steps
            val angle = baseAngle + t * Math.PI * 2.35
            val radius = storm.radius34Km * (0.16 + 1.18 * t)
            val halfWidth = 8.0 + 15.0 * t
            val latScale = (111.0 * cos(Math.toRadians(storm.latitude)).coerceAtLeast(0.18))
            val centerNorth = radius * cos(angle)
            val centerEast = radius * sin(angle)
            val sideNorth = halfWidth * cos(angle + Math.PI / 2.0)
            val sideEast = halfWidth * sin(angle + Math.PI / 2.0)
            val leftLat = storm.latitude + (centerNorth + sideNorth) / 111.0
            val leftLon = StormEngine.wrapLon(storm.longitude + (centerEast + sideEast) / latScale)
            val rightLat = storm.latitude + (centerNorth - sideNorth) / 111.0
            val rightLon = StormEngine.wrapLon(storm.longitude + (centerEast - sideEast) / latScale)
            left.add(Point.fromLngLat(leftLon, leftLat.coerceIn(-85.0, 85.0)))
            right.add(Point.fromLngLat(rightLon, rightLat.coerceIn(-85.0, 85.0)))
        }
        return (left + right.asReversed()).also { it.add(it.first()) }
    }

    private fun updateMapLayers(updatePositions: Boolean = true) {
        val style = currentStyle ?: return
        runCatching {
            val storms = engine.activeStorms()
            geometryStormCount = storms.size
            if (updatePositions) updateStormPositionLayer()
            // Split paths at ±180° so a storm crossing the date line is not drawn as
            // a long horizontal line across the entire world map.
            val tracks = if (showTrack) storms.flatMap { storm ->
                TrackGeometry.splitAtAntimeridian(simplifiedTrack(storm)).map { segment ->
                    Feature.fromGeometry(LineString.fromLngLats(segment.map { Point.fromLngLat(it.second, it.first) }))
                }
            }.toTypedArray() else emptyArray<Feature>()
            trackSource?.setGeoJson(FeatureCollection.fromFeatures(tracks))

            val ensembleLines = if (showEnsemble) ensembleTracks.map { points ->
                Feature.fromGeometry(LineString.fromLngLats(points.map { Point.fromLngLat(it.second, it.first) }))
            }.toTypedArray() else emptyArray()
            ensembleSource?.setGeoJson(FeatureCollection.fromFeatures(ensembleLines))

            val labelFeatures = storms.map { storm ->
                Feature.fromGeometry(Point.fromLngLat(storm.longitude, storm.latitude)).also {
                    it.addStringProperty("name", "${storm.name} · ${storm.category()}")
                }
            }.toTypedArray()
            stormLabelSource?.setGeoJson(FeatureCollection.fromFeatures(labelFeatures))

            val windFeatures = if (showWindField) storms.map { storm ->
                Feature.fromGeometry(Polygon.fromLngLats(listOf(makeStormRing(storm, storm.radius34Km))))
            }.toTypedArray() else emptyArray<Feature>()
            windSource?.setGeoJson(FeatureCollection.fromFeatures(windFeatures))
            val coreRings = if (showWindField) storms.flatMap { storm ->
                listOf(storm.radius50Km, storm.radius64Km).map { radius ->
                    Feature.fromGeometry(LineString.fromLngLats(makeStormRing(storm, radius)))
                }
            }.toTypedArray() else emptyArray<Feature>()
            windCoreSource?.setGeoJson(FeatureCollection.fromFeatures(coreRings))

            val rainFeatures = if (showRainBands) storms.flatMap { storm ->
                (0..2).map { arm -> Feature.fromGeometry(Polygon.fromLngLats(listOf(makeSpiralBand(storm, arm)))) }
            }.toTypedArray() else emptyArray<Feature>()
            rainBandSource?.setGeoJson(FeatureCollection.fromFeatures(rainFeatures))

            val eyeFeatures = if (showEye) storms.map { storm ->
                Feature.fromGeometry(Point.fromLngLat(storm.longitude, storm.latitude))
            }.toTypedArray() else emptyArray<Feature>()
            eyeSource?.setGeoJson(FeatureCollection.fromFeatures(eyeFeatures))
        }
    }

    private fun worldPolygons(): List<List<Pair<Double, Double>>> = listOf(
        listOf(-168.0 to 70.0, -145.0 to 72.0, -125.0 to 55.0, -124.0 to 42.0, -115.0 to 32.0, -105.0 to 23.0, -96.0 to 18.0, -88.0 to 16.0, -82.0 to 23.0, -79.0 to 31.0, -70.0 to 44.0, -60.0 to 52.0, -66.0 to 60.0, -88.0 to 67.0, -115.0 to 73.0),
        listOf(-81.0 to 12.0, -72.0 to 9.0, -62.0 to 8.0, -52.0 to 2.0, -47.0 to -7.0, -43.0 to -18.0, -49.0 to -31.0, -58.0 to -42.0, -68.0 to -55.0, -75.0 to -40.0, -78.0 to -20.0),
        listOf(-12.0 to 36.0, -7.0 to 50.0, 8.0 to 56.0, 20.0 to 65.0, 34.0 to 70.0, 52.0 to 67.0, 73.0 to 72.0, 96.0 to 75.0, 120.0 to 72.0, 145.0 to 62.0, 165.0 to 58.0, 178.0 to 52.0, 160.0 to 48.0, 142.0 to 48.0, 130.0 to 42.0, 122.0 to 34.0, 114.0 to 22.0, 103.0 to 8.0, 93.0 to 18.0, 80.0 to 24.0, 68.0 to 24.0, 58.0 to 28.0, 45.0 to 35.0, 33.0 to 34.0, 24.0 to 38.0, 14.0 to 45.0, 3.0 to 43.0, -5.0 to 38.0),
        listOf(-17.0 to 35.0, 2.0 to 37.0, 22.0 to 32.0, 34.0 to 29.0, 44.0 to 12.0, 50.0 to 4.0, 39.0 to -14.0, 30.0 to -30.0, 19.0 to -35.0, 9.0 to -28.0, 0.0 to -15.0, -8.0 to 3.0, -15.0 to 18.0),
        listOf(113.0 to -11.0, 126.0 to -12.0, 139.0 to -12.0, 153.0 to -24.0, 149.0 to -36.0, 135.0 to -39.0, 120.0 to -33.0, 114.0 to -22.0),
        listOf(129.0 to 32.0, 136.0 to 35.0, 142.0 to 42.0, 145.0 to 44.0, 142.0 to 37.0, 135.0 to 33.0),
        listOf(119.0 to 19.0, 125.0 to 18.0, 126.0 to 12.0, 122.0 to 6.0, 118.0 to 10.0),
        listOf(95.0 to 5.0, 106.0 to 4.0, 115.0 to -6.0, 110.0 to -9.0, 101.0 to -4.0)
    )

    private fun renderMenu() {
        if (!::menuContent.isInitialized) return
        menuContent.removeAllViews()
        val search = EditText(this).apply {
            setSingleLine(true)
            hint = "搜索功能 / 输入关键词"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(125, 158, 176))
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), 0, dp(12), 0)
            background = rounded(Color.rgb(13, 43, 60), 12)
            setText(menuSearchQuery)
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        menuContent.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        menuContent.addView(body, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        populateMenuBody(body, menuSearchQuery)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                menuSearchQuery = s?.toString().orEmpty()
                populateMenuBody(body, menuSearchQuery)
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun populateMenuBody(body: LinearLayout, rawQuery: String) {
        body.removeAllViews()
        val query = rawQuery.trim().lowercase()
        if (query.isNotBlank()) {
            val matches = menuTree.flatMap { first ->
                first.seconds.flatMap { second ->
                    second.actions.filter { action ->
                        listOf(first.title, second.title, action).any { it.lowercase().contains(query) }
                    }.map { action -> Triple(first.title, second.title, action) }
                }
            }
            body.addView(TextView(this).apply {
                text = "搜索结果 · ${matches.size} 项"
                textSize = 12f; setTextColor(Color.rgb(78, 215, 231)); setPadding(0, dp(4), 0, dp(6))
            })
            if (matches.isEmpty()) {
                body.addView(TextView(this).apply {
                    text = "没有找到匹配功能。可尝试搜索：台风、风速、预警、下载、回放。"
                    textSize = 12f; setTextColor(Color.LTGRAY); setPadding(dp(4), dp(10), dp(4), dp(10))
                })
            } else {
                matches.take(80).forEach { (first, second, action) ->
                    val button = smallButton("$first › $second › $action") { executeMenuAction(action) }
                    button.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    body.addView(button, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(5) })
                }
            }
        } else {
            val firstScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            menuTree.forEachIndexed { index, item ->
                firstRow.addView(smallButton(if (index == selectedFirst) "● ${item.title}" else item.title) {
                    selectedFirst = index; selectedSecond = 0; renderMenu()
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { setMargins(0, 0, dp(5), dp(7)) })
            }
            firstScroll.addView(firstRow)
            body.addView(TextView(this).apply {
                text = "一级菜单 · ${if (mode == AppMode.TYPHOON) "台风模式" else "防范台风模式"}"
                textSize = 10f; setTextColor(Color.LTGRAY)
            })
            body.addView(firstScroll)
            val safeFirst = selectedFirst.coerceIn(menuTree.indices)
            selectedFirst = safeFirst
            selectedSecond = selectedSecond.coerceIn(menuTree[safeFirst].seconds.indices)
            body.addView(TextView(this).apply {
                text = "二级菜单 · ${menuTree[safeFirst].title}"
                textSize = 11f; setTextColor(Color.rgb(78, 215, 231)); setPadding(0, dp(5), 0, dp(4))
            })
            menuTree[safeFirst].seconds.forEachIndexed { index, second ->
                val btn = smallButton((if (index == selectedSecond) "▾ " else "› ") + second.title) {
                    selectedSecond = index; renderMenu()
                }
                body.addView(btn, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(4) })
            }
            val third = menuTree[safeFirst].seconds[selectedSecond].actions
            body.addView(TextView(this).apply {
                text = "三级菜单 · ${menuTree[safeFirst].seconds[selectedSecond].title}"
                textSize = 11f; setTextColor(Color.rgb(255, 192, 119)); setPadding(0, dp(8), 0, dp(6))
            })
            third.forEach { action ->
                val b = smallButton("•  $action") { executeMenuAction(action) }
                b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                body.addView(b, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(4) })
            }
        }
        body.addView(TextView(this).apply {
            text = """离线影像：${MapLibrePackSummary()}
                地图资源：${MapPackManager.formatBytes(MapPackManager.usedBytes(this@MainActivity))} / 60 GB
                模拟时间：${engine.simulationSpeed}× · 路径倍率：${engine.motionMultiplier}×
                活动风暴：${engine.activeStorms().size} · 帧回调：${measuredFps} Hz
                性能模式：${arrayOf("省电", "均衡", "高性能")[performanceMode]}""".trimIndent()
            textSize = 10f; setTextColor(Color.rgb(135, 169, 187)); setPadding(0, dp(12), 0, dp(12))
        })
    }

    private fun MapLibrePackSummary(): String = MapPackManager.listPacks(this)
        .firstOrNull { it.file.absolutePath == activeSatellitePath }?.let { "当前 ${it.name}（${MapPackManager.formatBytes(it.bytes)}）" }
        ?: "已导入 ${MapPackManager.listPacks(this).size} 包，未启用卫星图层"

    private fun executeMenuAction(action: String) {
        when (action) {
            "生成主台风" -> { val s = engine.spawnMain(); toast("已生成主台风：${s.name}"); updateMapLayers() }
            "生成副台风" -> {
                runCatching { engine.spawnSub() }
                    .onSuccess { toast("副台风已生成：${it.name}"); updateMapLayers() }
                    .onFailure { showInfo("无法生成副台风", it.message ?: "活动风暴数量已达到上限") }
            }
            "切换主控台风" -> { engine.cycleMainStorm()?.let { toast("当前主控：${it.name}"); centerOnSelectedStorm() } ?: toast("当前没有活动台风"); updateMapLayers() }
            "清除已消散风暴" -> { engine.storms.removeAll { !it.alive }; toast("已清除消散风暴") }
            "摇杆控制开关" -> { engine.manualControl = !engine.manualControl; toast("摇杆控制：${if (engine.manualControl) "开启" else "关闭"}") }
            "移动速度" -> showSeekDialog("台风移动速度（模拟地理速度）", "km/h", engine.selectedStorm()?.speedKmh ?: 42.0, 10, 120) { engine.selectedStorm()?.speedKmh = it }
            "路径推进倍率" -> showSeekDialog("路径推进倍率", "倍", engine.motionMultiplier, 0.25, 4.0, 0.25) { engine.motionMultiplier = it.coerceAtLeast(0.25) }
            "定位当前主台风" -> centerOnSelectedStorm()
            "地图点选生成" -> { clickToSpawn = true; toast("请在地图上点击一个位置生成台风") }
            "最大风速" -> showSeekDialog("最大持续风速", "m/s", engine.selectedStorm()?.windMs ?: 25.0, 10, 80) { engine.setSelectedWindSpeed(it) }
            "中心气压" -> showSeekDialog("中心气压", "hPa", engine.selectedStorm()?.pressureHpa ?: 990.0, 880, 1015) { engine.setSelectedPressure(it) }
            "强度随机扰动" -> { toast("已启用环境随机扰动（持续模拟）") }
            "快速增强实验" -> { engine.triggerRapidIntensification(); updateDashboard(); updateMapLayers(); toast("已触发快速增强实验") }
            "快速增强机制开关" -> { engine.rapidIntensificationEnabled = !engine.rapidIntensificationEnabled; toast("快速增强机制：${if (engine.rapidIntensificationEnabled) "开启" else "关闭"}") }
            "显示风场与风圈" -> { showWindField = !showWindField; updateMapLayers(); toast("风场与风圈：${if (showWindField) "显示" else "隐藏"}") }
            "显示螺旋雨带" -> { showRainBands = !showRainBands; updateMapLayers(); toast("螺旋雨带：${if (showRainBands) "显示" else "隐藏"}") }
            "显示台风眼" -> { showEye = !showEye; updateMapLayers(); toast("台风眼：${if (showEye) "显示" else "隐藏"}") }
            "眼墙置换实验" -> { engine.triggerEyewallReplacement(); updateDashboard(); updateMapLayers(); toast("眼墙置换实验已触发") }
            "查看生命史事件" -> showInfo("台风生命史事件", engine.eventLog.takeLast(45).joinToString("\n").ifBlank { "暂无事件记录" })
            "导出风暴生命史" -> {
                val data = engine.exportLifeHistory()
                getSystemService(android.content.ClipboardManager::class.java).setPrimaryClip(android.content.ClipData.newPlainText("Typhoon life history", data))
                toast("风暴生命史 JSON 已复制（含轨迹点、时间轴与事件记录）")
            }
            "风暴时间轴回放" -> showReplayDialog()
            "导出回放时间轴" -> {
                val data = engine.exportReplayTimeline()
                getSystemService(android.content.ClipboardManager::class.java).setPrimaryClip(android.content.ClipData.newPlainText("Typhoon replay", data))
                toast("回放时间轴 JSON 已复制")
            }
            "环境场景预设" -> showEnvironmentPresetDialog()
            "环境支持诊断" -> showEnvironmentSupportDialog()
            "引导气流方向" -> showSeekDialog("环境引导气流方向", "°", engine.steeringHeadingDeg, 0, 359, 1.0) { engine.steeringHeadingDeg = it }
            "海表温度" -> showSeekDialog("海表温度", "°C", engine.seaSurfaceTemp, 18, 33) { engine.seaSurfaceTemp = it }
            "海洋热含量" -> showSeekDialog("海洋热含量指数", "单位指数", engine.oceanHeatContent, 0, 120) { engine.oceanHeatContent = it }
            "环境湿度" -> showSeekDialog("环境相对湿度", "%", engine.humidity, 30, 100) { engine.humidity = it }
            "垂直风切变" -> showSeekDialog("垂直风切变", "m/s", engine.windShear, 0, 40) { engine.windShear = it }
            "陆地摩擦" -> showSeekDialog("陆地摩擦系数", "倍", engine.landFriction, 0.2, 2.0, 0.1) { engine.landFriction = it }
            "显示地形影响说明" -> showInfo("地形影响", "当前版本采用简化陆地掩膜和摩擦衰减。它用于游戏机制演示，不是精确地形数值天气模式。")
            "生成16成员" -> { showEnsemble = true; ensembleTracks = engine.selectedStorm()?.let { engine.generateEnsemble(it, 16, 18) } ?: emptyList(); updateMapLayers(); showEnsembleSummary(16) }
            "生成32成员" -> { showEnsemble = true; ensembleTracks = engine.selectedStorm()?.let { engine.generateEnsemble(it, 32, 18) } ?: emptyList(); updateMapLayers(); showEnsembleSummary(32) }
            "隐藏集合路径" -> { showEnsemble = false; ensembleTracks = emptyList(); updateMapLayers() }
            "显示历史路径" -> { showTrack = true; updateMapLayers(); toast("历史路径已显示") }
            "显示/隐藏历史路径" -> { showTrack = !showTrack; updateMapLayers(); toast("历史路径：${if (showTrack) "显示" else "隐藏"}") }
            "显示风圈" -> { updateMapLayers(); showInfo("风圈图层", "青色半透明区域为简化风圈示意，半径并非真实 34/50/64 kt 风圈实测值。") }
            "预报不确定性说明" -> showInfo("预报不确定性", "集合路径通过改变初始方向、移动速度和随机扰动生成。成员越分散，代表模拟不确定性越大；不等同于官方业务预报概率锥。")
            "随机种子" -> showSeedDialog()
            "模拟时间倍率" -> showSpeedDialog()
            "高帧率模式" -> showPerformanceDialog()
            "风险等级评估" -> showInfo("风险评估", "当前：${engine.warningLevel(engine.estimateRisk())}\n风险指数：${engine.estimateRisk()}/100\n评估仅用于演练。")
            "AI防灾建议" -> showInfo("AI 防灾助手（规则版）", engine.aiAdvice())
            "影响范围估算" -> showInfo("影响范围", "模拟中心位置：${engine.selectedStorm()?.latitude?.format1() ?: "—"}°, ${engine.selectedStorm()?.longitude?.format1() ?: "—"}°\n估算风险：${engine.estimateRisk()}/100。")
            "发布蓝色预警" -> publishWarning("蓝色预警")
            "发布黄色预警" -> publishWarning("黄色预警")
            "发布橙色预警" -> publishWarning("橙色预警")
            "发布红色预警" -> publishWarning("红色预警")
            "疏散25%" -> setEvacuation(25)
            "疏散50%" -> setEvacuation(50)
            "疏散75%" -> setEvacuation(75)
            "调度救援力量" -> { rescueUnits += 5; toast("已调度救援队伍：${rescueUnits} 支") }
            "扩充避难所" -> { shelterCapacity += 5000; toast("避难容量增加至 ${shelterCapacity} 人") }
            "导入PMTiles影像包" -> importResult.launch(arrayOf("application/octet-stream", "application/x-pmtiles", "*/*"))
            "从手机导入影像包" -> importResult.launch(arrayOf("application/octet-stream", "application/x-pmtiles", "*/*"))
            "打开离线地图下载中心" -> showDownloadCenter()
            "继续未完成下载" -> showPartialDownloadsDialog()
            "管理已导入影像" -> showPackManager()
            "切换卫星底图" -> { val pack = MapPackManager.listPacks(this).firstOrNull(); if (pack == null) toast("请先导入 .pmtiles 卫星影像包") else addSatelliteLayer(pack.file) }
            "移除卫星底图" -> { removeAllSatelliteLayers(); toast("已切回离线简化全球底图") }
            "保存模拟进度" -> saveState()
            "读取模拟进度" -> loadState()
            "恢复上次自动存档" -> restoreAutoSave()
            "导出模拟数据" -> exportState()
            "地图放大" -> zoomMap(1.0)
            "地图缩小" -> zoomMap(-1.0)
            "全球视图" -> showGlobalMap()
            "打开全球气象指挥中心" -> showGlobalCommandCenter()
            "当前风暴总览" -> showGlobalCommandCenter()
            "查询当前风暴气象环境" -> queryWeatherProbe()
            "查看上次气象环境" -> showLastWeatherProbe()
            "查看气象探针历史档案" -> showWeatherProbeHistory()
            "气象数据来源说明" -> showWeatherDataSources()
            "显示/隐藏数据面板" -> toggleDashboard()
            "存储空间管理" -> showStorageManager()
            "地图包容量说明" -> showInfo("离线容量设计", "游戏离线地图包总配额为 60 GB（十进制）。当前已使用 ${MapPackManager.formatBytes(MapPackManager.usedBytes(this))}。实际可导入容量还受手机剩余空间、存储卷和系统策略约束；导入采用流式复制，不会一次性载入内存。建议额外预留 1–2 GB 运行空间。")
            "性能模式" -> showPerformanceDialog()
            "Android 设备适配中心" -> showAndroidCompatibilityCenter()
            "打开应用系统设置" -> openApplicationSettings()
            "电池优化设置" -> openBatteryOptimizationSettings()
            "打开V7情景挑战中心" -> showScenarioChallengeCenter()
            "查看当前挑战进度" -> showCurrentChallengeProgress()
            "版本更新说明" -> showInfo("Typhoon Lab 7.0.0", V70_CHANGELOG_SUMMARY)
            "模拟模型免责声明" -> showInfo("模型说明", "本软件是教学和娱乐用的台风沙盒。路径、强度、风圈、降雨、风暴潮和风险评估均为简化模型，不是官方天气预报或真实防灾决策系统。")
            else -> toast("该项目暂未开放")
        }
        updateDashboard(); renderMenu()
    }

    private fun showScenarioChallengeCenter() {
        val items = ScenarioChallengeCenter.all.map { "${it.title}\n${it.description}\n目标：${it.objective}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("V7 情景挑战中心")
            .setItems(items) { _, index ->
                val challenge = ScenarioChallengeCenter.all[index]
                AlertDialog.Builder(this)
                    .setTitle("开始：${challenge.title}")
                    .setMessage("${challenge.description}\n\n挑战目标：${challenge.objective}\n时限：${challenge.deadlineHours.toInt()} 模拟小时\n\n开始挑战会重置当前模拟风暴和时间轴；已有手动存档不会被删除。建议先保存当前进度。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("开始挑战") { _, _ ->
                        runCatching { ScenarioChallengeCenter.start(engine, challenge.id) }
                            .onSuccess {
                                activeChallengeId = it.id
                                activeChallengeStartedHours = engine.simulatedHours
                                getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit()
                                    .putString("v70_active_challenge", it.id)
                                    .putFloat("v70_challenge_start_hours", activeChallengeStartedHours.toFloat())
                                    .apply()
                                showEnsemble = false
                                ensembleTracks = emptyList()
                                paused = false
                                updateMapLayers()
                                centerOnSelectedStorm()
                                persistAutoState()
                                updateDashboard()
                                toast("挑战已开始：${it.title}")
                            }
                            .onFailure { showInfo("无法开始挑战", it.message ?: "请稍后重试") }
                    }.show()
            }.setNegativeButton("关闭", null).show()
    }

    private fun showCurrentChallengeProgress() {
        val challenge = ScenarioChallengeCenter.find(activeChallengeId)
        if (challenge == null) {
            showInfo("当前挑战", "尚未开始 V7 挑战。可在菜单“V7 情景挑战 → 挑战中心”选择一项任务。")
            return
        }
        val progress = ScenarioChallengeCenter.evaluate(engine, challenge, activeChallengeStartedHours)
        val state = when {
            progress.completed -> "已完成 · ${progress.score} 分"
            progress.failed -> "挑战失败 · 可重新开始"
            else -> "进行中 · ${(progress.fraction * 100).roundToInt()}%"
        }
        val text = "${challenge.title}\n状态：$state\n目标：${challenge.objective}\n${progress.detail}\n\n说明：挑战结果只衡量当前沙盒任务，不代表现实天气预报。"
        AlertDialog.Builder(this).setTitle("挑战进度").setMessage(text)
            .setPositiveButton("重新开始") { _, _ ->
                AlertDialog.Builder(this).setTitle("重新开始挑战？")
                    .setMessage("当前挑战模拟会被重置。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("重新开始") { _, _ ->
                        ScenarioChallengeCenter.start(engine, challenge.id)
                        activeChallengeStartedHours = engine.simulatedHours
                        getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit()
                            .putFloat("v70_challenge_start_hours", activeChallengeStartedHours.toFloat()).apply()
                        updateMapLayers(); centerOnSelectedStorm(); updateDashboard()
                    }.show()
            }.setNegativeButton("关闭", null).show()
    }

    private fun showEnsembleSummary(expectedMembers: Int) {
        val summary = EnsembleDiagnostics.summarize(ensembleTracks)
        if (summary == null) {
            toast("集合预报生成失败：没有有效终点")
            return
        }
        showInfo("集合预报离散度 · ${summary.memberCount} 成员",
            "终点平均位置：${summary.meanLatitude.format1()}°, ${summary.meanLongitude.format1()}°\n" +
                "平均离散距离：${summary.meanSpreadKm.format1()} km\n" +
                "90 百分位离散距离：${summary.percentile90SpreadKm.format1()} km\n\n" +
                "成员请求数：$expectedMembers。距离以平均终点为参照计算；这是沙盒集合路径的几何统计，不是官方概率预报。")
    }

    /** Device-only compatibility diagnostics; no hidden Xiaomi/MIUI/HyperOS API calls. */
    private fun showAndroidCompatibilityCenter() {
        val profile = DeviceCompatibility.detect(
            manufacturer = Build.MANUFACTURER,
            brand = Build.BRAND,
            display = "${Build.DISPLAY} ${Build.VERSION.INCREMENTAL}",
            androidRelease = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT
        )
        val stat = StatFs(filesDir.absolutePath)
        val availableBytes = runCatching { stat.availableBytes }.getOrDefault(0L)
        val activityManager = getSystemService(ActivityManager::class.java)
        val displayManager = getSystemService(DisplayManager::class.java)
        val refreshRate = runCatching {
            displayManager?.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate
                ?: windowManager.defaultDisplay.refreshRate
        }.getOrDefault(0f)
        val appVersion = runCatching {
            val info = packageManager.getPackageInfo(packageName, 0)
            @Suppress("DEPRECATION")
            val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
            "${info.versionName ?: "未知"} (code $code)"
        }.getOrDefault("未知")
        val memoryInfo = ActivityManager.MemoryInfo().also { activityManager?.getMemoryInfo(it) }
        val pageSizeBytes = runCatching { android.system.Os.sysconf(android.system.OsConstants._SC_PAGESIZE) }.getOrDefault(-1L)
        val powerManager = getSystemService(POWER_SERVICE) as android.os.PowerManager
        val report = buildString {
            appendLine("设备：${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("系统：Android ${profile.androidRelease} / API ${profile.apiLevel}")
            appendLine("ROM：${profile.romLabel}")
            appendLine("构建标识：${Build.DISPLAY.take(100)}")
            appendLine("应用：$appVersion")
            appendLine("屏幕刷新率：${"%.0f".format(Locale.US, refreshRate)} Hz（设备报告值）")
            appendLine("内存档位：${activityManager?.memoryClass ?: -1} MB；低内存设备：${activityManager?.isLowRamDevice ?: false}")
            appendLine("系统可用 RAM：${MapPackManager.formatBytes(memoryInfo.availMem)} / ${MapPackManager.formatBytes(memoryInfo.totalMem)}")
            appendLine("系统内存页大小：${if (pageSizeBytes > 0) "$pageSizeBytes 字节" else "无法读取"}")
            appendLine("省电模式：${if (powerManager.isPowerSaveMode) "开启" else "关闭"}")
            appendLine("应用目录可用空间：${MapPackManager.formatBytes(availableBytes)}")
            appendLine("最低系统支持：Android 8.0 / API 26；当前系统：${if (profile.minimumSdkSupported) "满足" else "低于要求"}")
            appendLine("目标 SDK：36（Android 16）；最低 SDK：26（Android 8.0）")
            appendLine()
            appendLine("适配检查与建议：")
            profile.guidance.forEachIndexed { index, item -> appendLine("${index + 1}. $item") }
            appendLine()
            appendLine("重要：此报告基于公开 Android Build 属性与设备资源信息，不会读取隐藏 MIUI/澎湃 OS 私有接口。不同地区 ROM 菜单名称可能不同。")
        }
        AlertDialog.Builder(this)
            .setTitle("Android 设备适配中心")
            .setMessage(report)
            .setPositiveButton("打开应用信息") { _, _ -> openApplicationSettings() }
            .setNeutralButton("电池优化设置") { _, _ -> openBatteryOptimizationSettings() }
            .setNegativeButton("完成", null)
            .show()
    }

    private fun openApplicationSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        runCatching { startActivity(intent) }
            .onFailure { toast("无法打开系统应用信息：${it.message ?: "未知原因"}") }
    }

    /** Opens Android's public battery-optimization settings page; it does not whitelist the app. */
    private fun openBatteryOptimizationSettings() {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        val launchable = runCatching { intent.resolveActivity(packageManager) != null }.getOrDefault(false)
        if (launchable) {
            runCatching { startActivity(intent) }
                .onFailure { openApplicationSettings() }
        } else {
            showInfo("电池设置", "当前系统未提供标准电池优化列表入口。请在系统设置中搜索‘电池优化’或‘应用省电策略’，找到‘台风实验室’后按实际需要调整。")
        }
    }

    private fun showEnvironmentPresetDialog() {
        val presets = EnvironmentPresets.all
        val labels = presets.map { "${it.title}\n${it.description}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("环境场景预设")
            .setItems(labels) { _, which ->
                val selected = presets.getOrNull(which) ?: return@setItems
                runCatching { engine.applyEnvironmentPreset(selected.id) }
                    .onSuccess {
                        updateDashboard()
                        updateMapLayers(updatePositions = false)
                        renderMenu()
                        toast("已应用：${selected.title}（未重置当前风暴）")
                    }
                    .onFailure { showInfo("预设应用失败", it.message ?: "未知错误") }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showEnvironmentSupportDialog() {
        val storm = engine.selectedStorm()
        val index = engine.environmentalSupportIndex(storm)
        val text = buildString {
            append("环境支持指数：$index / 100（${engine.environmentalSupportLabel(index)}）\n\n")
            append("海表温度：${engine.seaSurfaceTemp.format1()} °C\n")
            append("相对湿度：${engine.humidity.format1()} %\n")
            append("垂直风切变：${engine.windShear.format1()} m/s\n")
            append("海洋热含量指数：${engine.oceanHeatContent.format1()}\n")
            append("引导气流方向：${engine.steeringHeadingDeg.format1()}°\n")
            append("引导流强度：${engine.steeringFlow.format1()}\n")
            append("当前风暴：${storm?.name ?: "无"}\n\n")
            append("该指数只汇总本地沙盒设置的环境支持程度，不是强度预测、快速增强概率或官方气象诊断。")
        }
        showInfo("环境支持诊断", text)
    }

    private fun showGlobalCommandCenter() {
        val situation = GlobalCommandCenter.build(engine)
        val scroll = android.widget.ScrollView(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(14))
        }
        fun heading(text: String) {
            panel.addView(TextView(this).apply {
                this.text = text; textSize = 13f; setTextColor(Color.rgb(77, 218, 235))
                typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(10), 0, dp(6))
            })
        }
        fun metric(label: String, value: String) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9)); background = rounded(Color.rgb(12, 42, 58), 10)
            }
            row.addView(TextView(this).apply {
                text = label; textSize = 12f; setTextColor(Color.rgb(173, 205, 219))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply {
                text = value; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            })
            panel.addView(row, matchWrap())
        }

        panel.addView(TextView(this).apply {
            text = "全球气象指挥中心"; textSize = 21f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(3))
        })
        panel.addView(TextView(this).apply {
            text = "GLOBAL WEATHER COMMAND · 本地模拟态势 · T+${situation.simulatedHours.format1()} h"
            textSize = 10f; setTextColor(Color.rgb(128, 187, 204)); setPadding(0, 0, 0, dp(10))
        })
        val warning = TextView(this).apply {
            text = "演练数据，不是实时观测或官方预警。全球海盆分区仅用于模拟情景归类。"
            textSize = 11f; setTextColor(Color.rgb(255, 207, 135));
            setPadding(dp(10), dp(9), dp(10), dp(9)); background = rounded(Color.rgb(62, 45, 28), 10)
        }
        panel.addView(warning, matchWrap())
        panel.addView(smallButton("🌦 查询主控风暴附近天气与海洋模型") { queryWeatherProbe() },
            LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })
        panel.addView(smallButton("查看上次查询结果") { showLastWeatherProbe() },
            LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(5) })
        panel.addView(smallButton("气象探针历史档案（最近 24 次）") { showWeatherProbeHistory() },
            LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(5) })

        heading("全球态势总览")
        metric("活动风暴", "${situation.activeStormCount} / ${StormEngine.MAX_ACTIVE_STORMS}")
        metric("最强持续风速", if (situation.activeStormCount == 0) "—" else "${(situation.strongestWindMs * 1.94384).roundToInt()} kt  / ${situation.strongestWindMs.format1()} m/s")
        metric("最低中心气压", situation.lowestPressureHpa?.let { "${it.format1()} hPa" } ?: "—")
        metric("最高模拟风险", "${situation.highestRisk} / 100 · ${engine.warningLevel(situation.highestRisk)}")

        heading("七大热带气旋海盆")
        situation.regions.forEach { basin ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(11), dp(9), dp(11), dp(9))
                background = rounded(Color.rgb(10, 36, 52), 11)
            }
            val title = TextView(this).apply {
                text = "${basin.region.name}     ${basin.stateLabel}"
                textSize = 13f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (basin.maximumRisk >= 65) Color.rgb(255, 167, 127) else Color.WHITE)
            }
            val detail = TextView(this).apply {
                text = "${basin.region.description}\n风暴 ${basin.stormCount} 个 · 最大风险 ${basin.maximumRisk}/100\n" +
                    (if (basin.stormCount > 0) "最强：${basin.strongestStormName} · ${basin.strongestWindMs.format1()} m/s · 最低气压 ${basin.lowestPressureHpa?.format1() ?: "—"} hPa" else "暂无归类到该海盆的模拟风暴")
                textSize = 10.5f; setTextColor(Color.rgb(169, 197, 211)); setPadding(0, dp(5), 0, dp(7))
            }
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(smallButton("定位海盆") {
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(basin.region.centerLatitude, basin.region.centerLongitude), 2.6), 500)
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(5) })
            actions.addView(smallButton("在此海盆生成") {
                val storm = engine.spawnMain(basin.region.centerLatitude, basin.region.centerLongitude)
                updateMapLayers(); updateDashboard();
                toast("已生成海盆演练风暴：${storm.name}")
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
            card.addView(title); card.addView(detail); card.addView(actions)
            panel.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(7) })
        }

        heading("活动风暴列表")
        val active = engine.activeStorms().sortedByDescending { it.windMs }
        if (active.isEmpty()) {
            panel.addView(TextView(this).apply {
                text = "当前没有活动风暴。可在海盆卡片中生成一场演练风暴。"
                textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, dp(4), 0, dp(8))
            })
        } else active.forEach { storm ->
            val item = smallButton("${storm.name} · ${storm.category()} · ${storm.windMs.format1()} m/s · ${engine.estimateRisk(storm)}/100") {
                engine.storms.filter { it.isMain }.forEach { it.isMain = false }
                storm.isMain = true
                centerOnSelectedStorm(); updateDashboard(); updateMapLayers()
            }
            item.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            panel.addView(item, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(5) })
        }
        scroll.addView(panel)
        val dialog = AlertDialog.Builder(this).setView(scroll)
            .setPositiveButton("返回地图", null)
            .setNeutralButton("刷新态势", null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setLayout(
                minOf(resources.displayMetrics.widthPixels - dp(28), dp(720)),
                minOf(resources.displayMetrics.heightPixels - dp(100), dp(760))
            )
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss(); showGlobalCommandCenter()
            }
        }
        dialog.show()
    }

    private fun queryWeatherProbe() {
        if (!weatherProbeRunning.compareAndSet(false, true)) { toast("气象环境探针正在查询，请稍候"); return }
        val selected = engine.selectedStorm()
        val target = map?.cameraPosition?.target
        val lat = selected?.latitude ?: target?.latitude ?: 20.0
        val lon = selected?.longitude ?: target?.longitude ?: 135.0
        val label = selected?.name ?: "当前地图中心"
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            addView(ProgressBar(this@MainActivity), LinearLayout.LayoutParams(dp(32), dp(32)))
            addView(TextView(this@MainActivity).apply {
                text = "正在获取天气与海洋数值模式数据…\n位置：$label\n${lat.formatCoord()}°, ${lon.formatCoord()}°"
                setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val loading = AlertDialog.Builder(this).setTitle("气象环境探针").setView(content)
            .setNegativeButton("后台继续", null).create().apply { setCancelable(false); show() }
        weatherLoadingDialog = loading
        worker.execute {
            try {
                val snapshot = WeatherModelClient.fetch(lat, lon)
                persistWeatherProbe(snapshot)
                postUiIfAlive {
                    if (loading.isShowing) loading.dismiss()
                    if (weatherLoadingDialog === loading) weatherLoadingDialog = null
                    showWeatherProbePanel(snapshot, false, null)
                }
            } catch (error: Exception) {
                val cached = runCatching {
                    getSharedPreferences("typhoon_lab", MODE_PRIVATE).getString("weather_probe_v61", null)
                        ?.let { WeatherProbeSnapshot.fromJson(it) }
                }.getOrNull()
                postUiIfAlive {
                    if (loading.isShowing) loading.dismiss()
                    if (weatherLoadingDialog === loading) weatherLoadingDialog = null
                    if (cached != null) showWeatherProbePanel(cached, true,
                        "本次更新失败：${error.message ?: "网络不可用"}；当前显示本机缓存。")
                    else showInfo("气象数据获取失败", "${error.message ?: "网络请求失败"}\n\n请检查网络后重试；离线地图和模拟仍可使用。")
                }
            } finally { weatherProbeRunning.set(false) }
        }
    }

    private fun persistWeatherProbe(snapshot: WeatherProbeSnapshot) {
        val prefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
        val json = snapshot.toJson()
        require(json.toByteArray(Charsets.UTF_8).size <= 8192) { "气象探针缓存超过 8 KiB 安全大小限制" }
        // Discard corrupt/obsolete entries before deduplication so invalid preferences cannot
        // consume the bounded history quota indefinitely.
        val previous = (0 until 24).mapNotNull { index ->
            prefs.getString("weather_probe_history_$index", null)?.let { raw ->
                runCatching { WeatherProbeSnapshot.fromJson(raw) }.getOrNull()?.let { raw to it }
            }
        }
        val sameAsLatest = previous.firstOrNull()?.second?.let {
            it.weatherTime == snapshot.weatherTime &&
                kotlin.math.abs(it.requestedLatitude - snapshot.requestedLatitude) < 0.005 &&
                kotlin.math.abs(it.requestedLongitude - snapshot.requestedLongitude) < 0.005
        } ?: false
        val retained = if (sameAsLatest) previous.drop(1) else previous
        val updated = (listOf(json) + retained.map { it.first }).take(24)
        val editor = prefs.edit().putString("weather_probe_v61", json)
        for (index in 0 until 24) {
            val value = updated.getOrNull(index)
            if (value == null) editor.remove("weather_probe_history_$index")
            else editor.putString("weather_probe_history_$index", value)
        }
        editor.putInt("weather_probe_history_count", updated.size).apply()
    }

    private fun showWeatherProbeHistory() {
        val prefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
        val snapshots = (0 until 24).mapNotNull { index ->
            prefs.getString("weather_probe_history_$index", null)?.let { raw ->
                runCatching { WeatherProbeSnapshot.fromJson(raw) }.getOrNull()
            }
        }
        if (snapshots.isEmpty()) { toast("气象探针历史为空，请先查询一次"); return }
        val dateFormat = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        val labels = snapshots.map { snapshot ->
            val time = dateFormat.format(Date(snapshot.fetchedAtEpochMs))
            val wind = snapshot.windSpeedMs?.let { String.format(Locale.getDefault(), "%.1f m/s", it) } ?: "风速无数据"
            "$time · ${snapshot.requestedLatitude.formatCoord()}, ${snapshot.requestedLongitude.formatCoord()} · $wind"
        }.toTypedArray()
        val dialog = AlertDialog.Builder(this).setTitle("气象探针历史档案 · ${snapshots.size}/24")
            .setItems(labels) { _, which -> showWeatherProbePanel(snapshots[which], true, null) }
            .setNeutralButton("复制全部 JSON", null).setNegativeButton("关闭", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val array = org.json.JSONArray()
                snapshots.forEach { snapshot -> array.put(org.json.JSONObject(snapshot.toJson())) }
                getSystemService(android.content.ClipboardManager::class.java)
                    .setPrimaryClip(android.content.ClipData.newPlainText("Typhoon Lab Weather Probe History", array.toString()))
                toast("已复制 ${snapshots.size} 条气象探针历史记录")
            }
        }
        dialog.show()
    }

    private fun showLastWeatherProbe() {
        val snapshot = runCatching {
            getSharedPreferences("typhoon_lab", MODE_PRIVATE).getString("weather_probe_v61", null)
                ?.let { WeatherProbeSnapshot.fromJson(it) }
        }.getOrNull()
        if (snapshot == null) { toast("还没有气象探针缓存，请先执行查询"); return }
        showWeatherProbePanel(snapshot, true, null)
    }

    private fun showWeatherProbePanel(snapshot: WeatherProbeSnapshot, fromCache: Boolean, errorMessage: String?) {
        val fetched = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(snapshot.fetchedAtEpochMs))
        fun value(v: Double?, unit: String, integer: Boolean = false): String {
            if (v == null || !v.isFinite()) return "无数据"
            return String.format(Locale.getDefault(), if (integer) "%.0f %s" else "%.1f %s", v, unit)
        }
        val message = buildString {
            append("数据状态：${if (fromCache) "本机缓存" else "刚刚获取"}\n")
            append("请求坐标：${snapshot.requestedLatitude.formatCoord()}°, ${snapshot.requestedLongitude.formatCoord()}°\n")
            append("天气模型网格：${snapshot.modelLatitude.formatCoord()}°, ${snapshot.modelLongitude.formatCoord()}°\n")
            append("天气模式时间：${snapshot.weatherTime}（${snapshot.timezone}）\n获取时间：$fetched\n\n")
            append("【大气环境 · 模式网格估算】\n")
            append("气温：${value(snapshot.airTemperatureC, "°C")}\n体感温度：${value(snapshot.apparentTemperatureC, "°C")}\n")
            append("相对湿度：${value(snapshot.relativeHumidityPercent, "%", true)}\n海平面气压：${value(snapshot.seaLevelPressureHpa, "hPa")}\n")
            append("10 米风速：${value(snapshot.windSpeedMs, "m/s")}\n阵风：${value(snapshot.windGustMs, "m/s")}\n")
            append("风向：${snapshot.windDirectionDeg?.let { "${it.toInt()}° ${windDirectionText(it)}" } ?: "无数据"}\n")
            append("云量：${value(snapshot.cloudCoverPercent, "%", true)}\n降水：${value(snapshot.precipitationMm, "mm")}\n天气：${weatherCodeText(snapshot.weatherCode)}\n\n")
            append("【海洋环境 · 海洋模式网格】\n海表温度：${value(snapshot.seaSurfaceTemperatureC, "°C")}\n")
            append("有效波高：${value(snapshot.waveHeightM, "m")}\n海平面高度：${value(snapshot.seaLevelHeightM, "m")}\n")
            append("海洋模型网格：${snapshot.marineModelLatitude?.formatCoord() ?: "无数据"}°, ${snapshot.marineModelLongitude?.formatCoord() ?: "无数据"}°\n")
            append("海洋模式时间：${snapshot.marineTime ?: "无数据"}\n")
            append("海流速度：${value(snapshot.oceanCurrentSpeedKmh, "km/h")}\n海流方向（流向）：${snapshot.oceanCurrentDirectionDeg?.let { "${it.toInt()}°" } ?: "无数据"}\n\n")
            append("来源：Open-Meteo Forecast API + Marine API\nhttps://open-meteo.com/\n海洋模式数据来源依所选区域/模型，包含 Copernicus Marine、ECMWF、NOAA/NCEP、DWD 等提供方。\n\n")
            append("重要限制：数据是附近数值天气/海洋模型网格的估算或预报，不是台风中心现场观测、官方最佳路径或官方预警。天气与海洋网格坐标可能不同。缺失海洋字段显示‘无数据’，不会用 0 代替。海平面高度在近岸和内陆精度有限，不可用于航海导航。不会自动覆盖模拟环境参数。")
            if (!errorMessage.isNullOrBlank()) append("\n\n$errorMessage")
        }
        val dialog = AlertDialog.Builder(this).setTitle("气象环境探针").setMessage(message)
            .setPositiveButton("刷新查询", null).setNeutralButton("复制简报", null)
            .setNegativeButton("关闭", null).create()
        dialog.setOnShowListener {
            dialog.window?.setLayout(minOf(resources.displayMetrics.widthPixels - dp(28), dp(620)),
                minOf(resources.displayMetrics.heightPixels - dp(100), dp(780)))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { dialog.dismiss(); queryWeatherProbe() }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                getSystemService(android.content.ClipboardManager::class.java)
                    .setPrimaryClip(android.content.ClipData.newPlainText("Typhoon Lab 气象探针", message))
                toast("气象探针简报已复制")
            }
        }
        dialog.show()
    }

    private fun showWeatherDataSources() {
        showInfo("气象数据来源与限制", "天气：Open-Meteo Forecast API（Best Match 多模型整合预报）。\n海洋：Open-Meteo Marine API（海温、波浪、海平面及海流）。\n\nhttps://open-meteo.com/en/docs\nhttps://open-meteo.com/en/docs/marine-weather-api\n\n海洋模式底层提供方会因区域/变量而异，包含 Copernicus Marine Service、ECMWF、NOAA/NCEP 和 DWD；具体来源以 API 模型说明为准。请遵守 Open-Meteo 当前服务条款与数据署名要求；商业用途应核对相应套餐。查询只在用户主动操作时进行。天气模型不是现场观测或官方台风警报；结果只作环境参考，不会自动修改模拟参数。")
    }

    private fun Double.formatCoord(): String = String.format(Locale.US, "%.3f", this)

    private fun windDirectionText(degrees: Double): String {
        val names = listOf("北", "东北偏北", "东北", "东东北", "东", "东东南", "东南", "南东南", "南", "南西南", "西南", "西西南", "西", "西西北", "西北", "北西北")
        val normalized = ((degrees % 360.0) + 360.0) % 360.0
        return names[((normalized + 11.25) / 22.5).toInt().mod(16)]
    }

    private fun weatherCodeText(code: Int?): String = when (code) {
        0 -> "晴朗"; 1 -> "大致晴朗"; 2 -> "局部多云"; 3 -> "阴天"
        45, 48 -> "雾 / 雾凇"; 51, 53, 55 -> "毛毛雨"; 56, 57 -> "冻毛毛雨"
        61, 63, 65 -> "降雨"; 66, 67 -> "冻雨"; 71, 73, 75, 77 -> "降雪 / 雪粒"
        80, 81, 82 -> "阵雨"; 85, 86 -> "阵雪"; 95 -> "雷暴"; 96, 99 -> "雷暴伴冰雹"
        null -> "无数据"; else -> "天气代码 $code"
    }

    private fun centerOnSelectedStorm() {
        val storm = engine.selectedStorm()
        if (storm == null) {
            toast("当前没有活动台风")
            return
        }
        map?.animateCamera(
            CameraUpdateFactory.newLatLngZoom(LatLng(storm.latitude, storm.longitude), 4.8),
            700
        )
        toast("镜头已定位到 ${storm.name}")
    }

    private fun publishWarning(level: String) {
        warningIssued = level
        showInfo("预警发布成功（游戏演练）", "已发布：$level\n对象：模拟风暴影响区域\n提示：此为游戏内演练消息，不会发送到真实公众预警系统。")
    }

    private fun setEvacuation(value: Int) {
        evacuationPercent = value
        toast("模拟疏散完成度设为 ${value}%")
        updateDashboard()
    }

    private fun showSeekDialog(title: String, unit: String, current: Double, min: Double, max: Double, step: Double = 1.0, callback: (Double) -> Unit) {
        val minimum = min
        val maximum = max
        val safeStep = step.coerceAtLeast(0.0001)
        val seekMax = ((maximum - minimum) / safeStep).roundToInt().coerceAtLeast(1)
        val initial = ((current - minimum) / safeStep).roundToInt().coerceIn(0, seekMax)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(12), dp(22), dp(8)) }
        val valueText = TextView(this).apply { text = "${current.format1()} $unit"; setTextColor(Color.WHITE); textSize = 16f }
        val seek = SeekBar(this).apply { this.max = seekMax; progress = initial }
        box.addView(valueText); box.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                valueText.text = "${(minimum + progress * safeStep).format1()} $unit"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("取消", null)
            .setPositiveButton("应用") { _, _ -> callback(minimum + seek.progress * safeStep); updateDashboard(); updateMapLayers() }.show()
    }

    private fun showSpeedDialog() {
        val options = arrayOf("0.5×", "1×", "2×", "4×", "8×", "16×", "32×")
        val values = doubleArrayOf(0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0)
        val current = values.indexOf(engine.simulationSpeed).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("模拟时间倍率")
            .setMessage("1× = 每现实 1 分钟推进 1 个模拟小时。时间倍率影响环境演化，路径推进倍率单独控制地图移动快慢。")
            .setSingleChoiceItems(options, current) { dialog, which ->
                engine.simulationSpeed = values[which]
                speedButton.text = "×${values[which].format1()}"
                dialog.dismiss(); updateDashboard(); renderMenu()
            }.setNegativeButton("取消", null).show()
    }

    private fun cycleSpeed() {
        val values = listOf(0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0)
        val index = values.indexOf(engine.simulationSpeed).coerceAtLeast(0)
        engine.simulationSpeed = values[(index + 1) % values.size]
        speedButton.text = "×${engine.simulationSpeed.format1()}"
        toast("模拟时间倍率：${engine.simulationSpeed}×")
        updateDashboard()
    }

    private fun showPerformanceDialog() {
        val options = arrayOf("省电（降低地图细节更新，物理固定 30 Hz）", "均衡（地图细节约 8 次/秒更新，物理固定 30 Hz）", "高性能（位置跟随显示刷新率，细节约 12 次/秒更新，物理固定 30 Hz）")
        AlertDialog.Builder(this).setTitle("性能与帧率模式")
            .setSingleChoiceItems(options, performanceMode) { dialog, which ->
                performanceMode = which
                dialog.dismiss()
                toast("性能模式已切换：${arrayOf("省电", "均衡", "高性能")[which]}")
                updateDashboard()
            }.setNegativeButton("取消", null).show()
    }

    private fun showSeedDialog() {
        val input = android.widget.EditText(this).apply { setText(engine.rngSeed.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED }
        AlertDialog.Builder(this).setTitle("随机种子").setMessage("设置后重新生成风暴即可形成新的场景。")
            .setView(input).setNegativeButton("取消", null).setPositiveButton("应用") { _, _ ->
                val seed = input.text.toString().toIntOrNull() ?: 20261031
                engine.setSeed(seed); toast("随机种子已设置为 $seed")
            }.show()
    }

    private fun showReplayDialog() {
        val frames = engine.replayTimeline.toList()
        if (frames.isEmpty()) {
            toast("还没有可回放的风暴数据；开始模拟后会自动记录时间轴。")
            return
        }
        var selectedIndex = frames.lastIndex
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(14), dp(22), dp(8))
        }
        val detail = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 0, 0, dp(8))
        }
        val seek = SeekBar(this).apply { max = (frames.size - 1).coerceAtLeast(1); progress = selectedIndex }
        fun updateDetail(index: Int) {
            val frame = frames[index.coerceIn(frames.indices)]
            detail.text = "${frame.stormName}\n模拟时间：T+${frame.simulatedHours.format1()} 小时\n位置：${frame.latitude.format1()}°, ${frame.longitude.format1()}°\n最大持续风速：${frame.windMs.format1()} m/s\n中心气压：${frame.pressureHpa.format1()} hPa\n降雨率：${frame.rainRateMmH.format1()} mm/h\n阶段：${frame.phase}\n\n时间轴记录：${index + 1} / ${frames.size}"
        }
        updateDetail(selectedIndex)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedIndex = progress.coerceIn(frames.indices)
                updateDetail(selectedIndex)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) = Unit
            override fun onStopTrackingTouch(bar: SeekBar?) = Unit
        })
        box.addView(detail)
        box.addView(seek)
        AlertDialog.Builder(this).setTitle("风暴时间轴回放")
            .setMessage("拖动时间轴查看历史模拟状态。回放只读取历史记录，不会倒退或修改当前模拟。")
            .setView(box)
            .setPositiveButton("地图定位到此帧") { _, _ ->
                val frame = frames[selectedIndex]
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(frame.latitude, frame.longitude), 5.0), 500)
            }
            .setNeutralButton("导出时间轴") { _, _ ->
                val data = engine.exportReplayTimeline()
                getSystemService(android.content.ClipboardManager::class.java)
                    .setPrimaryClip(android.content.ClipData.newPlainText("Typhoon replay", data))
                toast("回放时间轴 JSON 已复制")
            }
            .setNegativeButton("关闭", null).show()
    }

    private fun showDownloadCenter() {
        if (mapDownloadRunning) {
            showInfo("下载中心", "当前有一个地图包正在下载。你可以等待完成，或在下载进度窗口中暂停并保留断点。")
            return
        }
        val partialCount = MapPackManager.partialDownloads(this).size
        val packCount = MapPackManager.listPacks(this).size
        val options = arrayOf(
            "输入 HTTPS 地址下载地图包",
            "继续未完成下载（${partialCount}）",
            "管理已安装影像包（${packCount}）",
            "从手机文件导入影像包",
            "下载中心使用说明"
        )
        AlertDialog.Builder(this).setTitle("离线地图下载中心")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showDownloadUrlDialog()
                    1 -> showPartialDownloadsDialog()
                    2 -> showPackManager()
                    3 -> importResult.launch(arrayOf("application/octet-stream", "application/x-pmtiles", "*/*"))
                    else -> showInfo("下载中心说明", "输入直接指向 PMTiles v3 文件的 HTTPS 地址。下载使用原生网络流，不经过浏览器；支持服务器 Range 时可断点续传。下载完成会校验文件头，再加入离线地图仓库。请只下载你有权使用的数据，并核对数据许可、日期、来源和文件大小。下载链接必须是 HTTPS，不能使用登录账号密码嵌入 URL。")
                }
            }.setNegativeButton("关闭", null).show()
    }

    private fun showDownloadUrlDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val urlLabel = TextView(this).apply { text = "PMTiles v3 直链（HTTPS）"; setTextColor(Color.WHITE); textSize = 12f }
        val urlInput = EditText(this).apply {
            hint = "https://example.org/region.pmtiles"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        val nameLabel = TextView(this).apply { text = "地图包名称（可选）"; setTextColor(Color.WHITE); textSize = 12f; setPadding(0, dp(12), 0, 0) }
        val nameInput = EditText(this).apply {
            hint = "例如：西北太平洋高清影像"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 13f; setSingleLine(true)
        }
        box.addView(urlLabel); box.addView(urlInput)
        box.addView(nameLabel); box.addView(nameInput)
        AlertDialog.Builder(this).setTitle("下载离线地图包")
            .setMessage("需要可直接下载的 HTTPS PMTiles v3 文件链接。大文件采用流式写入，可在支持 Range 的服务器上续传。")
            .setView(box)
            .setPositiveButton("选择保存位置") { _, _ ->
                val url = urlInput.text.toString().trim()
                val parsed = runCatching { java.net.URI(url) }.getOrNull()
                if (parsed == null || !parsed.scheme.equals("https", true) || parsed.host.isNullOrBlank() || parsed.userInfo != null) {
                    showInfo("下载地址无效", "请输入有效的 HTTPS 下载地址，不要把用户名或密码写在 URL 中。")
                } else {
                    val requestedName = nameInput.text.toString().trim().ifBlank { parsed.path.substringAfterLast('/').ifBlank { "satellite.pmtiles" } }
                    chooseDownloadVolume(url, requestedName)
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun chooseDownloadVolume(url: String, name: String) {
        val volumes = MapPackManager.volumes(this)
        if (volumes.isEmpty()) { showInfo("没有可用存储", "当前没有可写入的手机存储卷。请检查设备空间。不要把地图包上限误认为手机必然拥有 60 GB 空间。" ); return }
        val labels = volumes.map { "${it.label} · 可用 ${MapPackManager.formatBytes(it.availableBytes)}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("选择地图包保存位置")
            .setItems(labels) { _, which -> startMapPackDownload(url, name, volumes[which]) }
            .setNegativeButton("取消", null).show()
    }

    private fun postUiIfAlive(action: () -> Unit) {
        if (isFinishing || isDestroyed) return
        runOnUiThread {
            if (!isFinishing && !isDestroyed) action()
        }
    }

    private fun startMapPackDownload(url: String, name: String, volume: MapPackManager.Volume) {
        if (mapDownloadRunning) { toast("已有一个地图包下载任务正在运行"); return }
        mapDownloadRunning = true
        val cancel = AtomicBoolean(false)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(6))
        }
        val status = TextView(this).apply {
            text = "正在连接 HTTPS 下载源…\n${name}"
            textSize = 12f; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(10))
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; isIndeterminate = true
        }
        box.addView(status); box.addView(progress, LinearLayout.LayoutParams(-1, dp(10)))
        val dialog = AlertDialog.Builder(this).setTitle("原生地图包下载")
            .setView(box)
            .setNegativeButton("暂停并保留进度", null)
            .create()
        dialog.setCancelable(false)
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                cancel.set(true)
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).isEnabled = false
                status.text = "正在安全暂停…\n已下载部分会保留，可稍后继续。"
            }
        }
        dialog.show()
        worker.execute {
            try {
                val file = MapPackManager.downloadPack(this, url, name, volume, { cancel.get() }) { downloaded, total ->
                    postUiIfAlive {
                        if (dialog.isShowing) {
                            if (total > 0L) {
                                progress.isIndeterminate = false
                                progress.progress = ((downloaded.toDouble() / total) * 1000.0).toInt().coerceIn(0, 1000)
                                status.text = "${MapPackManager.formatBytes(downloaded)} / ${MapPackManager.formatBytes(total)}\n${name}"
                            } else {
                                progress.isIndeterminate = true
                                status.text = "已下载 ${MapPackManager.formatBytes(downloaded)}\n服务器未提供文件总大小。"
                            }
                        }
                    }
                }
                postUiIfAlive {
                    if (dialog.isShowing) dialog.dismiss()
                    addSatelliteLayer(file)
                    updateDashboard(); renderMenu()
                    showInfo("地图包下载完成", "${file.name}\n${MapPackManager.formatBytes(file.length())}\n已通过 PMTiles v3 文件头校验并加入离线地图仓库。")
                }
            } catch (e: Exception) {
                postUiIfAlive {
                    if (dialog.isShowing) dialog.dismiss()
                    val message = if (e is InterruptedException || cancel.get()) {
                        "下载已暂停，部分文件已保留。打开下载中心 → 继续未完成下载即可尝试续传。"
                    } else e.message ?: "网络下载失败"
                    showInfo("地图包下载未完成", message)
                    renderMenu()
                }
            } finally {
                mapDownloadRunning = false
            }
        }
    }

    private fun showPartialDownloadsDialog() {
        if (mapDownloadRunning) { toast("请先等待当前下载暂停或完成"); return }
        val partials = MapPackManager.partialDownloads(this)
        if (partials.isEmpty()) { toast("没有未完成的下载任务"); return }
        val labels = partials.map { "${it.name} · ${MapPackManager.formatBytes(it.bytes)} · ${it.volume.label}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("未完成下载 · ${partials.size} 项")
            .setItems(labels) { _, which ->
                val item = partials[which]
                AlertDialog.Builder(this).setTitle(item.name)
                    .setMessage("已下载：${MapPackManager.formatBytes(item.bytes)}\n保存位置：${item.volume.label}\n支持 Range 的服务器可从断点继续；否则会自动重新开始。")
                    .setPositiveButton("继续下载") { _, _ -> startMapPackDownload(item.url, item.name, item.volume) }
                    .setNeutralButton("删除残留文件") { _, _ ->
                        if (MapPackManager.deletePartial(item)) toast("未完成下载已删除") else toast("删除失败")
                        renderMenu()
                    }
                    .setNegativeButton("返回", null).show()
            }.setNegativeButton("关闭", null).show()
    }

    private fun zoomMap(delta: Double) {
        val current = map?.cameraPosition ?: run { toast("地图尚未准备好"); return }
        val zoom = (current.zoom + delta).coerceIn(1.2, 14.0)
        map?.animateCamera(CameraUpdateFactory.zoomTo(zoom), 220)
    }

    private fun showGlobalMap() {
        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(15.0, 0.0), 1.5), 550)
    }

    private fun toggleDashboard() {
        showDashboard = !showDashboard
        if (::dashboardText.isInitialized) dashboardText.visibility = if (showDashboard) View.VISIBLE else View.GONE
        toast("数据面板：${if (showDashboard) "显示" else "隐藏"}")
    }

    /** Store potentially large simulation snapshots as atomic files, not in SharedPreferences XML. */
    private fun writeStateFile(fileName: String, json: String) {
        val atomic = AtomicFile(File(filesDir, fileName))
        val stream = atomic.startWrite()
        try {
            stream.write(json.toByteArray(Charsets.UTF_8))
            stream.fd.sync()
            atomic.finishWrite(stream)
        } catch (error: Throwable) {
            atomic.failWrite(stream)
            throw error
        }
    }

    /** Migrates V5.x/V6.0 preference snapshots to a crash-safe file on first read. */
    private fun readStateFile(fileName: String, legacyPreferenceKey: String): String? {
        val target = File(filesDir, fileName)
        // openRead also recovers AtomicFile's backup after an interrupted commit.
        val committed = runCatching {
            require(!target.exists() || target.length() <= MAX_STATE_FILE_BYTES) { "存档文件超过 V6.0 允许的安全读取大小。" }
            AtomicFile(target).openRead().bufferedReader(Charsets.UTF_8).use { it.readText() }
        }.getOrNull()
        if (!committed.isNullOrBlank()) return committed
        val prefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
        val legacy = prefs.getString(legacyPreferenceKey, null)
        if (!legacy.isNullOrBlank()) {
            require(legacy.length <= StormEngine.MAX_SCENARIO_JSON_CHARS) { "旧存档超过安全读取大小，已拒绝迁移。" }
            writeStateFile(fileName, legacy)
            prefs.edit().remove(legacyPreferenceKey).apply()
        }
        return legacy
    }

    private fun persistAutoState() {
        runCatching {
            writeStateFile("auto_state.json", engine.exportState())
            getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit()
                .putInt("auto_evacuation", evacuationPercent)
                .putInt("auto_rescue", rescueUnits)
                .putInt("auto_shelter", shelterCapacity)
                .putString("auto_warning", warningIssued)
                .apply()
        }.onFailure { android.util.Log.e("TyphoonLab", "自动存档写入失败", it) }
    }

    private fun restoreAutoSave() {
        val json = runCatching { readStateFile("auto_state.json", "auto_state") }.getOrNull()
        if (json.isNullOrBlank()) { toast("还没有自动存档"); return }
        runCatching {
            engine.restoreState(json)
            val prefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
            evacuationPercent = prefs.getInt("auto_evacuation", evacuationPercent)
            rescueUnits = prefs.getInt("auto_rescue", rescueUnits)
            shelterCapacity = prefs.getInt("auto_shelter", shelterCapacity)
            warningIssued = prefs.getString("auto_warning", warningIssued) ?: warningIssued
            updateMapLayers(); updateDashboard(); renderMenu()
            toast("已恢复上次自动存档")
        }.onFailure { showInfo("自动存档恢复失败", it.message ?: "存档格式错误") }
    }

    private fun showInfo(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("知道了", null).show()
    }

    private fun showStorageManager() {
        val packs = MapPackManager.listPacks(this)
        val volumes = MapPackManager.volumes(this)
        val msg = buildString {
            append("设备可用存储：\n")
            volumes.forEachIndexed { index, v ->
                append("${index + 1}. ${v.label}\n可用 ${MapPackManager.formatBytes(v.availableBytes)} / 总量 ${MapPackManager.formatBytes(v.totalBytes)}\n")
            }
            append("\n已安装影像包：\n")
            if (packs.isEmpty()) append("暂无 PMTiles 包") else packs.forEach { append("• ${it.name}  ${MapPackManager.formatBytes(it.bytes)}\n") }
            val partials = MapPackManager.partialDownloads(this@MainActivity)
            append("\n未完成下载：\n")
            if (partials.isEmpty()) append("暂无残留下载\n") else partials.forEach { append("• ${it.name}  ${MapPackManager.formatBytes(it.bytes)}\n") }
            append("\n游戏地图资源配额：60 GB；当前已使用（已安装 + 未完成）${MapPackManager.formatBytes(MapPackManager.usedBytes(this@MainActivity))}。设备剩余空间不足时不能强行写入。")
        }
        AlertDialog.Builder(this).setTitle("离线数据仓库").setMessage(msg)
            .setPositiveButton("下载中心") { _, _ -> showDownloadCenter() }
            .setNeutralButton("本地导入") { _, _ -> importResult.launch(arrayOf("application/octet-stream", "application/x-pmtiles", "*/*")) }
            .setNegativeButton("关闭", null).show()
    }

    private fun showPackManager() {
        val packs = MapPackManager.listPacks(this)
        if (packs.isEmpty()) { toast("还没有导入离线卫星影像包"); return }
        val labels = packs.map { "${it.name} · ${MapPackManager.formatBytes(it.bytes)}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("离线影像包 · ${packs.size} 个")
            .setItems(labels) { _, which ->
                val pack = packs[which]
                AlertDialog.Builder(this).setTitle(pack.name)
                    .setMessage("大小：${MapPackManager.formatBytes(pack.bytes)}\n路径：${pack.file.absolutePath}\n\n选择操作。")
                    .setPositiveButton("设为当前卫星图层") { _, _ -> addSatelliteLayer(pack.file) }
                    .setNeutralButton("删除此影像包") { _, _ ->
                        val wasActive = activeSatellitePath == pack.file.absolutePath
                        if (wasActive) removeAllSatelliteLayers()
                        if (pack.file.delete()) {
                            toast("已删除 ${pack.name}")
                            if (wasActive) MapPackManager.listPacks(this).firstOrNull()?.let { addSatelliteLayer(it.file) }
                            renderMenu()
                        } else toast("删除失败：文件可能正在使用或存储卷不可写")
                    }
                    .setNegativeButton("返回", null).show()
            }.setNegativeButton("关闭", null).show()
    }

    private fun onMapPackSelected(uri: Uri) {
        runCatching { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        if (!MapPackManager.validateHeader(this, uri)) {
            toast("文件头不正确：请选择有效的 PMTiles 文件（.pmtiles）")
            return
        }
        val volumes = MapPackManager.volumes(this)
        if (volumes.isEmpty()) { toast("没有可用存储空间"); return }
        val labels = volumes.map { "${it.label} · 可用 ${MapPackManager.formatBytes(it.availableBytes)}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("选择地图包保存位置（大文件）").setItems(labels) { _, which ->
            importToVolume(uri, volumes[which])
        }.setNegativeButton("取消", null).show()
    }

    private fun importToVolume(uri: Uri, volume: MapPackManager.Volume) {
        val declared = MapPackManager.declaredSize(this, uri)
        val progress = ProgressDialog(this).apply {
            setTitle("正在导入离线卫星影像")
            setMessage("正在复制大文件，请保持应用在前台。")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            isIndeterminate = declared <= 0
            max = 1000
            setCancelable(false)
            show()
        }
        worker.execute {
            try {
                val file = MapPackManager.importPack(this, uri, volume) { copied, total ->
                    postUiIfAlive {
                        if (total > 0) {
                            progress.isIndeterminate = false
                            progress.progress = ((copied.toDouble() / total) * 1000).toInt().coerceIn(0, 1000)
                            progress.setMessage("${MapPackManager.formatBytes(copied)} / ${MapPackManager.formatBytes(total)}")
                        }
                    }
                }
                postUiIfAlive {
                    progress.dismiss(); toast("影像包导入完成：${file.name}")
                    addSatelliteLayer(file); updateDashboard(); renderMenu()
                }
            } catch (e: Exception) {
                postUiIfAlive { progress.dismiss(); showInfo("导入失败", e.message ?: "未知错误") }
            }
        }
    }

    private fun saveState() {
        runCatching {
            writeStateFile("manual_state.json", engine.exportState())
            getSharedPreferences("typhoon_lab", MODE_PRIVATE).edit()
                .putInt("evacuation", evacuationPercent)
                .putInt("rescue", rescueUnits)
                .putInt("shelter", shelterCapacity)
                .putString("warning", warningIssued)
                .apply()
            toast("模拟进度已安全保存到本机")
        }.onFailure { showInfo("保存失败", it.message ?: "无法写入存档") }
    }

    private fun loadState() {
        val prefs = getSharedPreferences("typhoon_lab", MODE_PRIVATE)
        val json = runCatching { readStateFile("manual_state.json", "state") }.getOrNull()
        if (json.isNullOrBlank()) { toast("没有找到本地存档"); return }
        runCatching {
            engine.restoreState(json)
            speedButton.text = "×${engine.simulationSpeed.format1()}"
            evacuationPercent = prefs.getInt("evacuation", 0)
            rescueUnits = prefs.getInt("rescue", 0)
            shelterCapacity = prefs.getInt("shelter", 12000)
            warningIssued = prefs.getString("warning", "尚未发布") ?: "尚未发布"
            updateMapLayers(); updateDashboard(); renderMenu()
            toast("模拟存档已读取")
        }.onFailure { showInfo("读取失败", it.message ?: "存档格式错误") }
    }

    private fun exportState() {
        val text = engine.exportState()
        val clipboard = getSystemService(android.content.ClipboardManager::class.java)
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("TyphoonLab Scenario", text))
        toast("模拟 JSON 已复制到剪贴板")
    }

    private fun updateDashboard() {
        if (!::dashboardText.isInitialized) return
        val s = engine.selectedStorm()
        dashboardText.text = if (s == null) "暂无活动风暴\n帧回调 ${measuredFps} Hz" else buildString {
            append("${s.name}\n${s.category()} · ${s.windMs.format1()} m/s\n")
            append("阵风 ${s.maxGustMs.format1()} m/s · ${s.pressureHpa.format1()} hPa\n")
            append("${s.latitude.format1()}°, ${s.longitude.format1()}° · ${s.phase}\n")
            append("降雨 ${s.rainRateMmH.format1()} mm/h · 风暴潮 ${engine.estimateSurgeMeters(s).format1()} m\n")
            append("冷尾流 ${s.coldWakeC.format1()}°C · R34 ${s.radius34Km.toInt()} km\n")
            append("R50 ${s.radius50Km.toInt()} km · R64 ${s.radius64Km.toInt()} km\n")
            append("风险 ${engine.estimateRisk(s)}/100 · T+${engine.simulatedHours.toInt()}h\n")
            append("帧回调 ${measuredFps} Hz · 物理 ${engine.physicsSteps} 步 · 时间倍率 ${engine.simulationSpeed.format1()}×")
            ScenarioChallengeCenter.find(activeChallengeId)?.let { challenge ->
                val progress = ScenarioChallengeCenter.evaluate(engine, challenge, activeChallengeStartedHours)
                val state = when { progress.completed -> "完成"; progress.failed -> "失败"; else -> "${(progress.fraction * 100).roundToInt()}%" }
                append("\n挑战：${challenge.title} · $state")
            }
        }
        if (::statusText.isInitialized) statusText.text = "${engine.activeStorms().size} 个活动风暴 · ${warningIssued} · 疏散 ${evacuationPercent}%"
    }

    private fun toggleMenu() { menuPanel.visibility = if (menuPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    private fun togglePause() {
        paused = !paused
        pauseButton.text = if (paused) "▶ 继续" else "Ⅱ 暂停"
    }

    private fun startLoop() {
        if (loopStarted) return
        loopStarted = true
        val now = System.nanoTime()
        lastFrameNanos = now
        lastMarkerFrameNanos = now
        lastMapFrameNanos = now
        lastDashboardNanos = now
        fpsWindowStartNanos = now
        fpsFrameCount = 0
        updateAdaptiveFrameBudget(now, force = true)
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    private fun stopLoop() {
        loopStarted = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    private fun updateAdaptiveFrameBudget(nowNanos: Long, force: Boolean = false) {
        if (!force && nowNanos - lastAdaptiveBudgetNanos < 2_000_000_000L) return
        lastAdaptiveBudgetNanos = nowNanos
        val powerManager = getSystemService(POWER_SERVICE) as android.os.PowerManager
        val thermalStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { powerManager.currentThermalStatus }.getOrDefault(0)
        } else 0
        adaptiveFrameBudget = AdaptiveFrameBudget.calculate(
            performanceMode = performanceMode,
            powerSaveMode = powerManager.isPowerSaveMode,
            thermalStatus = thermalStatus,
            activeStormCount = engine.activeStorms().size
        )
    }

    private val frameCallback = Choreographer.FrameCallback { frameTimeNanos ->
        if (!loopStarted || isFinishing || mapView == null) return@FrameCallback
        val dtSeconds = (frameTimeNanos - lastFrameNanos).coerceAtLeast(0L).toDouble() / 1_000_000_000.0
        lastFrameNanos = frameTimeNanos
        fpsFrameCount++
        if (!paused) engine.advance(dtSeconds)
        // Rendering cadence adapts to power-save, thermal and storm load. The engine's
        // fixed 30 Hz physics step is deliberately untouched, so simulation results stay deterministic.
        if (frameTimeNanos - lastAdaptiveBudgetNanos >= 2_000_000_000L) {
            updateAdaptiveFrameBudget(frameTimeNanos)
        }
        if (!paused && frameTimeNanos - lastMarkerFrameNanos >= adaptiveFrameBudget.markerIntervalNanos) {
            lastMarkerFrameNanos = frameTimeNanos
            updateStormPositionLayer()
        }
        if (frameTimeNanos - fpsWindowStartNanos >= 1_000_000_000L) {
            measuredFps = fpsFrameCount
            fpsFrameCount = 0
            fpsWindowStartNanos = frameTimeNanos
        }
        if (!paused && frameTimeNanos - lastMapFrameNanos >= adaptiveFrameBudget.mapIntervalNanos) {
            lastMapFrameNanos = frameTimeNanos
            updateMapLayers(updatePositions = false)
        }
        if (frameTimeNanos - lastDashboardNanos >= adaptiveFrameBudget.dashboardIntervalNanos) {
            lastDashboardNanos = frameTimeNanos
            updateDashboard()
        }
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    private fun smallButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 11.5f; isAllCaps = false; setTextColor(Color.WHITE)
        minHeight = dp(42); minimumHeight = dp(42); setPadding(dp(8), dp(4), dp(8), dp(4))
        background = rounded(Color.rgb(16, 52, 71), 10)
        setOnClickListener { action() }
    }

    private fun smallButton(text: String, action: () -> Unit, params: LinearLayout.LayoutParams): Button = smallButton(text, action).also { it.layoutParams = params }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.argb(55, 137, 206, 222))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun Double.format1(): String = String.format("%.1f", this)

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val layoutChanged = newConfig.screenWidthDp != lastLayoutScreenWidthDp ||
            newConfig.orientation != lastLayoutOrientation
        if (!layoutChanged) return
        lastLayoutScreenWidthDp = newConfig.screenWidthDp
        lastLayoutOrientation = newConfig.orientation
        if (::menuPanel.isInitialized) {
            (menuPanel.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.width = if (newConfig.screenWidthDp >= 600) dp(430) else minOf((resources.displayMetrics.widthPixels * 0.88f).toInt(), dp(390))
                menuPanel.layoutParams = params
            }
        }
        if (::dashboardText.isInitialized) {
            (dashboardText.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.width = if (newConfig.screenWidthDp >= 600) dp(300) else minOf(dp(220), (resources.displayMetrics.widthPixels * 0.54f).toInt())
                dashboardText.layoutParams = params
            }
        }
        (bottomOverlay?.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
            params.width = if (newConfig.screenWidthDp >= 760) minOf(dp(760), resources.displayMetrics.widthPixels) else ViewGroup.LayoutParams.MATCH_PARENT
            bottomOverlay?.layoutParams = params
        }
        ViewCompat.requestApplyInsets(root)
        if (::menuContent.isInitialized) renderMenu()
    }

    private fun disposeMapView() {
        val view = mapView ?: return
        stopLoop()
        if (mapViewResumed) { runCatching { view.onPause() }; mapViewResumed = false }
        if (mapViewStarted) { runCatching { view.onStop() }; mapViewStarted = false }
        (view.parent as? ViewGroup)?.removeView(view)
        runCatching { view.onDestroy() }
        mapView = null
    }

    override fun onStart() {
        super.onStart()
        activityStarted = true
        mapView?.let { if (!mapViewStarted) { it.onStart(); mapViewStarted = true } }
    }

    override fun onResume() {
        super.onResume()
        activityResumed = true
        mapView?.let { if (!mapViewResumed) { it.onResume(); mapViewResumed = true } }
        if (mapView != null) startLoop()
    }

    override fun onPause() {
        activityResumed = false
        if (mapView != null) persistAutoState()
        stopLoop()
        mapView?.let { if (mapViewResumed) { it.onPause(); mapViewResumed = false } }
        super.onPause()
    }

    override fun onStop() {
        mapView?.let { if (mapViewStarted) { it.onStop(); mapViewStarted = false } }
        activityStarted = false
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView?.onLowMemory()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        // Keep the system Bundle small; full simulation was persisted during onPause.
        mapView?.onSaveInstanceState(outState)
        outState.putBoolean("tl_simulation_open", mapView != null)
        outState.putInt("tl_mode", mode.ordinal)
        outState.putInt("tl_evacuation", evacuationPercent)
        outState.putInt("tl_rescue", rescueUnits)
        outState.putInt("tl_shelter", shelterCapacity)
        outState.putString("tl_warning", warningIssued)
        outState.putBoolean("tl_paused", paused)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        weatherLoadingDialog?.let { runCatching { if (it.isShowing) it.dismiss() } }
        weatherLoadingDialog = null
        stopLoop()
        disposeMapView()
        worker.shutdownNow()
        super.onDestroy()
    }

    private inner class JoystickPadView(context: android.content.Context, val changed: (Double, Double) -> Unit) : View(context) {
        private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 30, 144, 167); style = Paint.Style.FILL }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(75, 210, 229); style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat() }
        private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(32, 180, 207); style = Paint.Style.FILL }
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(100, 160, 235, 245); strokeWidth = dp(1).toFloat() }
        private var xValue = 0f
        private var yValue = 0f
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val radius = min(width, height) * 0.46f
            canvas.drawCircle(cx, cy, radius, basePaint); canvas.drawCircle(cx, cy, radius, ringPaint)
            canvas.drawLine(cx - radius * .7f, cy, cx + radius * .7f, cy, gridPaint)
            canvas.drawLine(cx, cy - radius * .7f, cx, cy + radius * .7f, gridPaint)
            canvas.drawCircle(cx + xValue * radius * .65f, cy + yValue * radius * .65f, radius * .30f, knobPaint)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val radius = min(width, height) * .42f
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    if (event.action == MotionEvent.ACTION_DOWN) performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                    val rawX = ((event.x - width / 2f) / radius).coerceIn(-1f, 1f)
                    val rawY = ((event.y - height / 2f) / radius).coerceIn(-1f, 1f)
                    val magnitude = hypot(rawX, rawY)
                    if (magnitude < 0.12f) {
                        xValue = 0f; yValue = 0f
                    } else {
                        val scale = (magnitude.coerceAtMost(1f) - 0.12f) / 0.88f / magnitude
                        xValue = (rawX * scale).coerceIn(-1f, 1f)
                        yValue = (rawY * scale).coerceIn(-1f, 1f)
                    }
                    changed(xValue.toDouble(), yValue.toDouble()); invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    xValue = 0f; yValue = 0f; changed(0.0, 0.0); invalidate(); performClick(); return true
                }
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}
