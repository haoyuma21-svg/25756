package com.typhoonlab.mobile

import kotlin.math.roundToInt

/** A playable, deterministic sandbox challenge. Objectives are game goals, not forecasts. */
data class ScenarioChallenge(
    val id: String,
    val title: String,
    val description: String,
    val objective: String,
    val environmentPresetId: String,
    val seed: Int,
    val startLatitude: Double,
    val startLongitude: Double,
    val additionalStorms: List<Pair<Double, Double>> = emptyList(),
    val targetHours: Double,
    val deadlineHours: Double
)

data class ChallengeProgress(
    val challenge: ScenarioChallenge,
    val completed: Boolean,
    val failed: Boolean,
    val fraction: Double,
    val elapsedHours: Double,
    val detail: String,
    val score: Int
)

object ScenarioChallengeCenter {
    val all: List<ScenarioChallenge> = listOf(
        ScenarioChallenge(
            id = "rapid_intensification",
            title = "暖海快速增强",
            description = "在暖海温、高海洋热含量和弱风切变环境中研究强度增强。",
            objective = "主台风达到台风级（持续风速 ≥ 41.5 m/s）",
            environmentPresetId = "wpac_favorable",
            seed = 7001,
            startLatitude = 16.0,
            startLongitude = 137.0,
            targetHours = 24.0,
            deadlineHours = 36.0
        ),
        ScenarioChallenge(
            id = "shear_survival",
            title = "强风切变生存",
            description = "在强垂直风切变条件下维持风暴结构，观察不利环境的影响。",
            objective = "模拟时间达到 12 小时时，主风暴仍活动且不低于热带风暴级",
            environmentPresetId = "high_shear",
            seed = 7002,
            startLatitude = 18.0,
            startLongitude = 132.0,
            targetHours = 12.0,
            deadlineHours = 36.0
        ),
        ScenarioChallenge(
            id = "coastal_landfall",
            title = "近岸登陆挑战",
            description = "把台风从近海引导至陆地，观察登陆后的摩擦与强度变化。",
            objective = "主台风在陆地上累计停留至少 0.25 小时",
            environmentPresetId = "coastal_landfall",
            seed = 7003,
            startLatitude = 20.0,
            startLongitude = 124.0,
            targetHours = 0.25,
            deadlineHours = 48.0
        ),
        ScenarioChallenge(
            id = "fujiwhara_pair",
            title = "藤原效应双风暴",
            description = "同时管理两枚相距较近的风暴，观察简化藤原相互作用。",
            objective = "累计记录 1,500 个双风暴相互作用物理步",
            environmentPresetId = "monsoon_trough",
            seed = 7004,
            startLatitude = 17.0,
            startLongitude = 135.0,
            additionalStorms = listOf(17.5 to 143.0),
            targetHours = 6.7,
            deadlineHours = 24.0
        ),
        ScenarioChallenge(
            id = "three_storm_watch",
            title = "多风暴协同监测",
            description = "同时监测三枚风暴，兼顾路径、强度和地图负载。",
            objective = "模拟时间达到 12 小时时，仍有至少 3 枚活动风暴",
            environmentPresetId = "monsoon_trough",
            seed = 7005,
            startLatitude = 15.0,
            startLongitude = 135.0,
            additionalStorms = listOf(10.0 to 128.0, 22.0 to 145.0),
            targetHours = 12.0,
            deadlineHours = 36.0
        )
    )

    fun find(id: String?): ScenarioChallenge? = all.firstOrNull { it.id == id }

    /** Starts a fresh scenario explicitly; callers should confirm that the current sandbox will be replaced. */
    fun start(engine: StormEngine, id: String): ScenarioChallenge {
        val challenge = find(id) ?: throw IllegalArgumentException("未知挑战：$id")
        engine.resetForScenario(challenge.seed)
        engine.applyEnvironmentPreset(challenge.environmentPresetId)
        // Challenges are interactive by default: keep the player joystick enabled for the main storm.
        engine.manualControl = true
        engine.spawnMain(challenge.startLatitude, challenge.startLongitude)
        challenge.additionalStorms.forEach { (lat, lon) -> engine.spawnSubAt(lat, lon) }
        return challenge
    }

    fun evaluate(engine: StormEngine, challenge: ScenarioChallenge, startedAtHours: Double): ChallengeProgress {
        val elapsed = (engine.simulatedHours - startedAtHours).coerceAtLeast(0.0)
        val main = engine.selectedStorm()
        val mainAlive = main?.alive == true
        val complete: Boolean
        val fraction: Double
        val detail: String
        val failed: Boolean
        when (challenge.id) {
            "rapid_intensification" -> {
                val wind = main?.windMs ?: 0.0
                complete = wind >= 41.5
                fraction = (wind / 41.5).coerceIn(0.0, 1.0)
                detail = "当前主风暴风速 ${wind.fmt1()} / 41.5 m/s；已用时 ${elapsed.fmt1()} h"
                failed = !complete && elapsed >= challenge.deadlineHours
            }
            "shear_survival" -> {
                val survived = mainAlive && (main?.windMs ?: 0.0) >= 17.2
                complete = survived && elapsed >= challenge.targetHours
                fraction = (elapsed / challenge.targetHours).coerceIn(0.0, 1.0) * if (survived) 1.0 else 0.0
                detail = "已模拟 ${elapsed.fmt1()} / ${challenge.targetHours.fmt1()} h；主风暴状态：${if (survived) "仍活动" else "未满足"}"
                failed = !complete && (!mainAlive || elapsed >= challenge.deadlineHours)
            }
            "coastal_landfall" -> {
                val landHours = main?.overLandHours ?: 0.0
                complete = landHours >= challenge.targetHours
                fraction = (landHours / challenge.targetHours).coerceIn(0.0, 1.0)
                detail = "主台风陆地停留 ${landHours.fmt1()} / ${challenge.targetHours.fmt1()} h；总用时 ${elapsed.fmt1()} h"
                failed = !complete && elapsed >= challenge.deadlineHours
            }
            "fujiwhara_pair" -> {
                val interactions = engine.fujiwharaInteractionSteps
                complete = interactions >= FUJIWHARA_TARGET_STEPS
                fraction = (interactions.toDouble() / FUJIWHARA_TARGET_STEPS).coerceIn(0.0, 1.0)
                detail = "双风暴相互作用 ${interactions} / $FUJIWHARA_TARGET_STEPS 个物理步"
                failed = !complete && elapsed >= challenge.deadlineHours
            }
            "three_storm_watch" -> {
                val count = engine.activeStorms().size
                val enough = count >= 3
                complete = enough && elapsed >= challenge.targetHours
                fraction = (elapsed / challenge.targetHours).coerceIn(0.0, 1.0) * if (enough) 1.0 else 0.0
                detail = "活动风暴 ${count} / 3 枚；已模拟 ${elapsed.fmt1()} / ${challenge.targetHours.fmt1()} h"
                failed = !complete && elapsed >= challenge.deadlineHours
            }
            else -> {
                complete = false
                fraction = 0.0
                detail = "未知挑战类型"
                failed = true
            }
        }
        val score = if (!complete) 0 else (100.0 - elapsed / challenge.deadlineHours * 25.0).roundToInt().coerceIn(75, 100)
        return ChallengeProgress(challenge, complete, failed, fraction, elapsed, detail, score)
    }

    const val FUJIWHARA_TARGET_STEPS = 1_500L
    private fun Double.fmt1(): String = String.format(java.util.Locale.US, "%.1f", this)
}
