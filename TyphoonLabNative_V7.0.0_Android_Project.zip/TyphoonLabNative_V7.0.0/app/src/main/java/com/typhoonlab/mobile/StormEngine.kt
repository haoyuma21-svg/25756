package com.typhoonlab.mobile

import kotlin.math.*
import kotlin.random.Random
import org.json.JSONArray
import org.json.JSONObject

/** A compact replay sample for the main controlled storm. */
data class ReplayFrame(
    val simulatedHours: Double,
    val stormName: String,
    val latitude: Double,
    val longitude: Double,
    val windMs: Double,
    val pressureHpa: Double,
    val rainRateMmH: Double,
    val phase: String
)

/** Educational typhoon sandbox model. Not an operational numerical weather prediction model. */
data class Storm(
    val id: Long,
    var name: String,
    var latitude: Double,
    var longitude: Double,
    var windMs: Double = 28.0,
    var pressureHpa: Double = 990.0,
    var headingDeg: Double = 300.0,
    var speedKmh: Double = 42.0,
    var ageHours: Double = 0.0,
    var alive: Boolean = true,
    var isMain: Boolean = false,
    val history: MutableList<Pair<Double, Double>> = mutableListOf(),
    var maxGustMs: Double = windMs * 1.45,
    var radius34Km: Double = 150.0,
    var radius50Km: Double = 85.0,
    var radius64Km: Double = 42.0,
    var eyeRadiusKm: Double = 24.0,
    var rainRateMmH: Double = 35.0,
    var accumulatedRainMm: Double = 0.0,
    var coldWakeC: Double = 0.0,
    var phase: String = "发展中",
    var wasOnLand: Boolean = false,
    var overLandHours: Double = 0.0,
    var eyeWallCycleTimerHours: Double = 0.0,
    var eyeWallCycleCount: Int = 0,
    var riCheckAgeHours: Double = 0.0,
    var riCheckWindMs: Double = windMs,
    var windFieldExpansion: Double = 1.0,
    var pressureBiasHpa: Double = 0.0
) {
    fun category(): String = when {
        windMs < 17.2 -> "热带低压"
        windMs < 24.5 -> "热带风暴"
        windMs < 32.7 -> "强热带风暴"
        windMs < 41.5 -> "台风"
        windMs < 51.0 -> "强台风"
        windMs < 58.5 -> "超强台风"
        else -> "极强台风（游戏级）"
    }
}

class StormEngine(seed: Int = 20261031) {
    private var random = Random(seed)
    // Forecast generation has an isolated RNG so merely opening an ensemble does not
    // change the future physical evolution of the live storm simulation.
    private var forecastRandom = Random(seed xor 0x5F3759DF)
    private var nextId = 1L
    private var physicsAccumulatorSeconds = 0.0
    var physicsSteps: Long = 0L
        private set
    var droppedWallSeconds: Double = 0.0
        private set
    /** Number of fixed physics steps in which at least one close storm pair interacted. */
    var fujiwharaInteractionSteps: Long = 0L
        private set
    val storms: MutableList<Storm> = mutableListOf()
    val eventLog: MutableList<String> = mutableListOf()
    val replayTimeline: MutableList<ReplayFrame> = mutableListOf()
    // Reused by the fixed-step loop to avoid allocating a filtered List on every physics tick.
    private val activeStormScratch = ArrayList<Storm>(MAX_ACTIVE_STORMS)
    private var lastReplaySampleHours = -1.0
    var simulatedHours = 0.0
        private set

    // Game clock: 1x means one simulated hour per real-time minute.
    var seaSurfaceTemp = 29.0
    var humidity = 78.0
    var windShear = 9.0
    var oceanHeatContent = 65.0
    var steeringFlow = 1.0
    /** Approximate environmental steering direction used by the sandbox track model. */
    var steeringHeadingDeg = 290.0
    var landFriction = 1.0
    var simulationSpeed = 8.0
    var motionMultiplier = 1.0
    var joystickX = 0.0
    var joystickY = 0.0
    var manualControl = true
    var rapidIntensificationEnabled = true
    var rngSeed = seed

    fun spawnMain(lat: Double = 15.0, lon: Double = 135.0): Storm {
        storms.filter { it.isMain }.forEach { it.isMain = false }
        makeRoomForNewStorm()
        val id = nextId++
        val safeLat = lat.coerceIn(-45.0, 45.0)
        val safeLon = wrapLon(lon)
        val initialWind = 28.0 + random.nextDouble(0.0, 10.0)
        val storm = Storm(
            id = id,
            name = "台风-海燕$id",
            latitude = safeLat,
            longitude = safeLon,
            windMs = initialWind,
            pressureHpa = 1012.0 - initialWind * 0.78,
            headingDeg = 285.0,
            speedKmh = random.nextDouble(34.0, 50.0),
            isMain = true,
            wasOnLand = isApproxLand(safeLat, safeLon)
        )
        storm.history.add(storm.latitude to storm.longitude)
        refreshStructure(storm)
        storms.add(storm)
        record("${storm.name} 在 ${safeLat.fmt()}°N ${safeLon.fmt()}°E 生成")
        captureReplayFrame(force = true)
        return storm
    }

    fun spawnSub(): Storm = spawnSubAt(random.nextDouble(6.0, 28.0), random.nextDouble(105.0, 170.0))

    /** Spawn at an explicit location for mission setup and reproducible sandbox scenes. */
    fun spawnSubAt(latitude: Double, longitude: Double): Storm {
        require(activeStorms().size < MAX_ACTIVE_STORMS) { "同时活动的风暴最多 ${MAX_ACTIVE_STORMS} 个。" }
        pruneStoredStorms()
        val lat = latitude.coerceIn(-45.0, 45.0)
        val lon = wrapLon(longitude)
        val id = nextId++
        val initialWind = random.nextDouble(20.0, 31.0)
        val storm = Storm(
            id = id,
            name = "热带风暴-$id",
            latitude = lat,
            longitude = lon,
            windMs = initialWind,
            pressureHpa = random.nextDouble(985.0, 1005.0),
            headingDeg = random.nextDouble(235.0, 335.0),
            speedKmh = random.nextDouble(28.0, 48.0),
            wasOnLand = isApproxLand(lat, lon)
        )
        storm.history.add(storm.latitude to storm.longitude)
        refreshStructure(storm)
        storms.add(storm)
        record("${storm.name} 在 ${lat.fmt()}°N ${lon.fmt()}°E 生成")
        captureReplayFrame(force = true)
        return storm
    }

    /** Clear the previous simulation and initialize a reproducible mission scenario. */
    fun resetForScenario(seed: Int) {
        storms.clear()
        eventLog.clear()
        replayTimeline.clear()
        activeStormScratch.clear()
        simulatedHours = 0.0
        physicsAccumulatorSeconds = 0.0
        physicsSteps = 0L
        droppedWallSeconds = 0.0
        fujiwharaInteractionSteps = 0L
        lastReplaySampleHours = -1.0
        nextId = 1L
        joystickX = 0.0
        joystickY = 0.0
        motionMultiplier = 1.0
        simulationSpeed = 8.0
        setSeed(seed)
    }

    fun activeStorms(): List<Storm> = storms.filter { it.alive }
    fun selectedStorm(): Storm? = storms.firstOrNull { it.alive && it.isMain } ?: activeStorms().firstOrNull()

    private fun makeRoomForNewStorm() {
        pruneStoredStorms()
        if (activeStorms().size >= MAX_ACTIVE_STORMS) {
            val victim = storms.firstOrNull { it.alive && !it.isMain } ?: storms.firstOrNull { it.alive }
            victim?.let {
                it.alive = false
                record("活动风暴达到 ${MAX_ACTIVE_STORMS} 个上限，${it.name} 被移出活动模拟")
            }
        }
    }

    private fun pruneStoredStorms() {
        while (storms.size >= MAX_RETAINED_STORMS) {
            val removable = storms.firstOrNull { !it.alive } ?: storms.firstOrNull { !it.isMain } ?: storms.firstOrNull()
            if (removable == null) break
            removable.alive = false
            storms.remove(removable)
        }
    }

    fun cycleMainStorm(): Storm? {
        val alive = activeStorms()
        if (alive.isEmpty()) return null
        val currentIndex = alive.indexOfFirst { it.isMain }
        val next = alive[(currentIndex + 1).mod(alive.size)]
        alive.forEach { it.isMain = it.id == next.id }
        record("主控风暴切换为 ${next.name}")
        captureReplayFrame(force = true)
        return next
    }

    private fun captureReplayFrame(force: Boolean = false) {
        val storm = selectedStorm() ?: return
        if (!force && simulatedHours - lastReplaySampleHours < 0.25) return
        val frame = ReplayFrame(
            simulatedHours, storm.name, storm.latitude, storm.longitude,
            storm.windMs, storm.pressureHpa, storm.rainRateMmH, storm.phase
        )
        if (force && replayTimeline.lastOrNull()?.simulatedHours == simulatedHours) {
            replayTimeline[replayTimeline.lastIndex] = frame
        } else {
            replayTimeline.add(frame)
        }
        lastReplaySampleHours = simulatedHours
        // Keep the recent 240 simulated hours at 15-minute sampling intervals.
        while (replayTimeline.size > 960) replayTimeline.removeAt(0)
    }

    fun exportReplayTimeline(): String {
        val root = JSONObject()
        root.put("format", "TyphoonLab-Replay-v1")
        root.put("seed", rngSeed)
        root.put("simulatedHours", simulatedHours)
        val frames = JSONArray()
        replayTimeline.forEach { frame ->
            frames.put(JSONObject().apply {
                put("hours", frame.simulatedHours)
                put("name", frame.stormName)
                put("lat", frame.latitude)
                put("lon", frame.longitude)
                put("windMs", frame.windMs)
                put("pressureHpa", frame.pressureHpa)
                put("rainRateMmH", frame.rainRateMmH)
                put("phase", frame.phase)
            })
        }
        root.put("frames", frames)
        return root.toString(2)
    }

    /** Called from a Choreographer frame callback. deltaSeconds is wall-clock time. */
    /**
     * Engine optimization #1: fixed-step physics at 30 Hz, independent of display refresh.
     * Rendering may run at 60/90/120 Hz, but physical evolution is deterministic for the
     * same sequence of elapsed wall-clock time and seed. Excessive background lag is bounded.
     */
    fun advance(deltaSeconds: Double) {
        if (!deltaSeconds.isFinite() || deltaSeconds <= 0.0) return
        val safeDelta = deltaSeconds.coerceAtMost(MAX_WALL_DELTA_SECONDS)
        droppedWallSeconds += (deltaSeconds - safeDelta).coerceAtLeast(0.0)
        physicsAccumulatorSeconds = (physicsAccumulatorSeconds + safeDelta)
            .coerceAtMost(PHYSICS_STEP_SECONDS * MAX_PHYSICS_STEPS_PER_FRAME)
        var steps = 0
        while (physicsAccumulatorSeconds + 1e-9 >= PHYSICS_STEP_SECONDS && steps < MAX_PHYSICS_STEPS_PER_FRAME) {
            simulateStep(PHYSICS_STEP_SECONDS)
            physicsAccumulatorSeconds -= PHYSICS_STEP_SECONDS
            steps++
            physicsSteps++
        }
    }

    private fun simulateStep(deltaSeconds: Double) {
        val dtHours = (deltaSeconds.coerceAtMost(0.10) / 60.0 * simulationSpeed).coerceIn(0.0, 0.20)
        if (dtHours <= 0.0) return
        simulatedHours += dtHours

        // Engine optimization #2: reuse the active-storm buffer and compute shared
        // environmental terms once per step rather than once per storm. This avoids
        // short-lived lists and repeated math when several storms are active.
        activeStormScratch.clear()
        for (storm in storms) if (storm.alive) activeStormScratch.add(storm)
        val alive = activeStormScratch
        val oceanFactorBase = (seaSurfaceTemp - 26.0) * 0.25 + (oceanHeatContent - 45.0) * 0.016
        val moistureFactorBase = (humidity - 65.0) * 0.032
        val shearPenaltyBase = max(0.0, windShear - 8.0) * 0.14
        val rapidIntensificationEnvironmentReady = rapidIntensificationEnabled &&
            seaSurfaceTemp >= 28.0 && windShear < 10.0 && humidity >= 75.0

        // Simplified Fujiwhara interaction; deliberately presented as a sandbox effect.
        for (i in alive.indices) for (j in i + 1 until alive.size) {
            val a = alive[i]
            val b = alive[j]
            val dx = shortestLonDelta(a.longitude, b.longitude) * cos(Math.toRadians((a.latitude + b.latitude) / 2.0))
            val dy = b.latitude - a.latitude
            val distance = hypot(dx, dy)
            if (distance < 13.0 && distance > 0.3) {
                fujiwharaInteractionSteps++
                val influence = ((13.0 - distance) / 13.0) * 5.5 * dtHours
                a.headingDeg = wrap360(a.headingDeg + influence)
                b.headingDeg = wrap360(b.headingDeg - influence)
            }
        }

        for (storm in alive) {
            val previousCategory = storm.category()
            storm.ageHours += dtHours
            val wasLand = storm.wasOnLand

            var heading = storm.headingDeg
            if (storm.isMain && manualControl && (abs(joystickX) + abs(joystickY) > 0.06)) {
                heading = wrap360(Math.toDegrees(atan2(joystickX, -joystickY)))
                storm.headingDeg = heading
                storm.speedKmh = (34.0 + 34.0 * hypot(joystickX, joystickY)).coerceIn(24.0, 92.0)
            } else {
                val steeringError = shortestAngleDelta(heading, steeringHeadingDeg)
                val steeringResponse = (0.55 + steeringFlow * 0.55).coerceIn(0.35, 1.9)
                heading = wrap360(heading + steeringError.coerceIn(-2.2, 2.2) * dtHours * steeringResponse + random.nextDouble(-0.7, 0.7) * dtHours)
                storm.headingDeg = heading
                // Small steering-flow influence on translational speed.
                storm.speedKmh = (storm.speedKmh + (steeringFlow - 1.0) * 0.06 * dtHours).coerceIn(18.0, 75.0)
            }

            val travelKm = storm.speedKmh * motionMultiplier * dtHours
            val angle = Math.toRadians(heading)
            storm.latitude = (storm.latitude + cos(angle) * travelKm / 111.0).coerceIn(-60.0, 60.0)
            val cosine = cos(Math.toRadians(storm.latitude)).coerceAtLeast(0.18)
            storm.longitude = wrapLon(storm.longitude + sin(angle) * travelKm / (111.0 * cosine))

            val onLand = isApproxLand(storm.latitude, storm.longitude)
            storm.wasOnLand = onLand
            if (!wasLand && onLand) record("${storm.name} 模拟登陆：${storm.latitude.fmt()}°N ${storm.longitude.fmt()}°E")
            if (onLand) storm.overLandHours += dtHours else storm.overLandHours = max(0.0, storm.overLandHours - dtHours * 0.35)

            // Ocean wake: wind-driven surface cooling slowly decays as the storm moves away.
            val wakeBuild = max(0.0, storm.windMs - 25.0) * dtHours * 0.00075
            val wakeDecay = (0.004 + storm.speedKmh * 0.00003) * dtHours
            storm.coldWakeC = (storm.coldWakeC + wakeBuild - wakeDecay).coerceIn(0.0, 3.8)

            val landPenalty = if (onLand) 2.25 * landFriction else 0.0
            val eyeWallPhase = (storm.eyeWallCycleTimerHours / 88.0) * (Math.PI * 2.0)
            val eyeWallPenalty = if (storm.windMs >= 48.0) max(0.0, sin(eyeWallPhase)) * 0.48 else 0.0
            val noise = random.nextDouble(-0.12, 0.12)
            var tendency = oceanFactorBase + moistureFactorBase - shearPenaltyBase - landPenalty - storm.coldWakeC * 0.42 - eyeWallPenalty + noise
            if (rapidIntensificationEnvironmentReady && !onLand && storm.windMs in 25.0..58.0) {
                tendency += 0.28
            }
            storm.windMs = (storm.windMs + tendency * dtHours).coerceIn(8.0, 90.0)
            storm.pressureHpa = (1013.0 - storm.windMs * 0.80 + storm.pressureBiasHpa + random.nextDouble(-0.12, 0.12)).coerceIn(875.0, 1010.0)
            storm.eyeWallCycleTimerHours += dtHours
            if (storm.windMs >= 50.0) {
                val completedCycles = floor(storm.eyeWallCycleTimerHours / 88.0).toInt()
                if (completedCycles > storm.eyeWallCycleCount) {
                    storm.eyeWallCycleCount = completedCycles
                    record("${storm.name} 完成一次模拟眼墙置换周期")
                }
            }

            // Detect a rapid-intensification-like six-hour wind increase.
            if (storm.ageHours - storm.riCheckAgeHours >= 6.0) {
                val sixHourChange = storm.windMs - storm.riCheckWindMs
                if (sixHourChange >= 5.0 && storm.windMs >= 25.0 && !onLand) {
                    record("${storm.name} 出现快速增强信号：6 小时风速增加 ${sixHourChange.fmt()} m/s")
                }
                storm.riCheckAgeHours = storm.ageHours
                storm.riCheckWindMs = storm.windMs
            }

            storm.rainRateMmH = ((humidity - 42.0) * 0.82 + storm.windMs * 0.88).coerceIn(0.0, 180.0)
            storm.accumulatedRainMm += storm.rainRateMmH * dtHours
            refreshStructure(storm)
            storm.phase = when {
                storm.overLandHours >= 1.0 -> "登陆减弱"
                abs(storm.latitude) > 34.0 || seaSurfaceTemp < 24.0 -> "温带转化模拟"
                storm.ageHours < 8.0 -> "生成发展期"
                storm.windMs >= 58.5 -> "成熟超强阶段"
                storm.ageHours > 220.0 -> "衰亡阶段"
                else -> "海上维持阶段"
            }

            if (previousCategory != storm.category()) record("${storm.name} 强度等级变化：${previousCategory} → ${storm.category()}")
            val lastTrackPoint = storm.history.lastOrNull()
            if (lastTrackPoint == null || abs(lastTrackPoint.first - storm.latitude) + abs(shortestLonDelta(lastTrackPoint.second, storm.longitude)) > 0.012) {
                storm.history.add(storm.latitude to storm.longitude)
                if (storm.history.size > 1200) storm.history.removeAt(0)
            }

            if (storm.windMs < 17.0 || storm.ageHours > 360.0 || storm.overLandHours > 22.0) {
                storm.alive = false
                record("${storm.name} 已消散（${if (storm.overLandHours > 22.0) "长时间登陆" else "强度/生命史条件"}）")
            }
        }
        captureReplayFrame()
    }

    private fun refreshStructure(storm: Storm) {
        val wind = storm.windMs.coerceAtLeast(8.0)
        storm.maxGustMs = wind * 1.48
        storm.radius34Km = ((60.0 + wind * 3.15) * storm.windFieldExpansion).coerceIn(65.0, 520.0)
        storm.radius50Km = (20.0 + wind * 1.85).coerceIn(25.0, 260.0)
        storm.radius64Km = (8.0 + wind * 1.15).coerceIn(12.0, 180.0)
        storm.eyeRadiusKm = (38.0 - wind * 0.38).coerceIn(10.0, 32.0)
    }

    /** Apply a named environment setup without spawning, deleting, or rewriting any storm. */
    fun applyEnvironmentPreset(presetId: String): EnvironmentPreset {
        val preset = EnvironmentPresets.find(presetId) ?: throw IllegalArgumentException("未知环境预设：$presetId")
        seaSurfaceTemp = preset.seaSurfaceTempC.coerceIn(18.0, 33.0)
        humidity = preset.humidityPercent.coerceIn(30.0, 100.0)
        windShear = preset.windShearMs.coerceIn(0.0, 40.0)
        oceanHeatContent = preset.oceanHeatContent.coerceIn(0.0, 120.0)
        steeringFlow = preset.steeringFlow.coerceIn(0.2, 2.5)
        steeringHeadingDeg = wrap360(preset.steeringHeadingDeg)
        landFriction = preset.landFriction.coerceIn(0.2, 2.0)
        rapidIntensificationEnabled = preset.rapidIntensificationEnabled
        manualControl = false
        record("应用环境场景：${preset.title}（仅改变环境参数，不重置风暴）")
        return preset
    }

    /** A transparent educational index of environmental support, not an intensity forecast. */
    fun environmentalSupportIndex(storm: Storm? = selectedStorm()): Int {
        val thermal = ((seaSurfaceTemp - 24.0) / 8.0).coerceIn(0.0, 1.0) * 32.0
        val moisture = ((humidity - 50.0) / 50.0).coerceIn(0.0, 1.0) * 22.0
        val ocean = ((oceanHeatContent - 20.0) / 100.0).coerceIn(0.0, 1.0) * 26.0
        val shear = (1.0 - windShear / 25.0).coerceIn(0.0, 1.0) * 20.0
        val landPenalty = if (storm?.wasOnLand == true) 12.0 else 0.0
        return (thermal + moisture + ocean + shear - landPenalty).roundToInt().coerceIn(0, 100)
    }

    fun environmentalSupportLabel(index: Int = environmentalSupportIndex()): String = when {
        index >= 78 -> "环境支持较强"
        index >= 58 -> "环境支持中等偏强"
        index >= 38 -> "环境支持一般"
        else -> "环境支持偏弱"
    }

    fun setSelectedWindSpeed(valueMs: Double) {
        val storm = selectedStorm() ?: return
        storm.windMs = valueMs.coerceIn(8.0, 90.0)
        storm.pressureHpa = (1013.0 - storm.windMs * 0.80 + storm.pressureBiasHpa).coerceIn(875.0, 1010.0)
        refreshStructure(storm)
    }

    fun setSelectedPressure(valueHpa: Double) {
        val storm = selectedStorm() ?: return
        storm.pressureHpa = valueHpa.coerceIn(875.0, 1015.0)
        storm.pressureBiasHpa = storm.pressureHpa - (1013.0 - storm.windMs * 0.80)
    }

    fun triggerRapidIntensification() {
        val storm = selectedStorm() ?: return
        val before = storm.windMs
        storm.windMs = (storm.windMs + 7.5).coerceAtMost(82.0)
        storm.pressureHpa = (storm.pressureHpa - 9.0).coerceAtLeast(875.0)
        storm.pressureBiasHpa = storm.pressureHpa - (1013.0 - storm.windMs * 0.80)
        refreshStructure(storm)
        record("${storm.name}：人工触发快速增强实验，风速 ${before.fmt()} → ${storm.windMs.fmt()} m/s")
    }

    fun triggerEyewallReplacement() {
        val storm = selectedStorm() ?: return
        storm.windMs = (storm.windMs - 2.2).coerceAtLeast(28.0)
        storm.pressureHpa = (storm.pressureHpa + 3.0).coerceAtMost(1005.0)
        storm.eyeWallCycleCount += 1
        storm.windFieldExpansion = (storm.windFieldExpansion * 1.18).coerceAtMost(1.6)
        refreshStructure(storm)
        record("${storm.name}：人工触发眼墙置换实验，核心风速短暂下降、风圈扩大")
    }

    fun generateEnsemble(storm: Storm? = selectedStorm(), members: Int = 24, steps: Int = 18): List<List<Pair<Double, Double>>> {
        val source = storm ?: return emptyList()
        val tracks = mutableListOf<List<Pair<Double, Double>>>()
        repeat(members.coerceIn(4, 64)) {
            var lat = source.latitude
            var lon = source.longitude
            var heading = source.headingDeg + forecastRandom.nextDouble(-16.0, 16.0)
            var speed = source.speedKmh * forecastRandom.nextDouble(0.72, 1.3)
            val track = mutableListOf(lat to lon)
            repeat(steps.coerceIn(4, 48)) {
                heading = wrap360(heading + forecastRandom.nextDouble(-9.0, 9.0))
                speed = (speed + forecastRandom.nextDouble(-2.0, 2.0)).coerceIn(8.0, 85.0)
                val km = speed * 3.0
                val rad = Math.toRadians(heading)
                lat = (lat + cos(rad) * km / 111.0).coerceIn(-60.0, 60.0)
                lon = wrapLon(lon + sin(rad) * km / (111.0 * cos(Math.toRadians(lat)).coerceAtLeast(0.18)))
                track.add(lat to lon)
            }
            tracks.add(track)
        }
        record("为 ${storm.name} 生成 ${members.coerceIn(4, 64)} 条集合路径")
        return tracks
    }

    fun estimateSurgeMeters(storm: Storm? = selectedStorm()): Double {
        if (storm == null) return 0.0
        val windTerm = storm.windMs * storm.windMs / 2100.0
        val pressureTerm = ((1010.0 - storm.pressureHpa).coerceAtLeast(0.0)) * 0.012
        return (windTerm + pressureTerm).coerceIn(0.0, 6.5)
    }

    fun estimateRisk(storm: Storm? = selectedStorm()): Int {
        if (storm == null) return 0
        val wind = ((storm.windMs - 17.0) / 45.0 * 48.0).coerceIn(0.0, 48.0)
        val rain = (storm.rainRateMmH / 180.0 * 18.0).coerceIn(0.0, 18.0)
        val surge = (estimateSurgeMeters(storm) / 6.5 * 18.0).coerceIn(0.0, 18.0)
        val coastal = if (abs(storm.latitude) < 35.0) 12.0 else 4.0
        return (wind + rain + surge + coastal).roundToInt().coerceIn(0, 100)
    }

    fun warningLevel(risk: Int): String = when {
        risk >= 82 -> "红色预警"
        risk >= 65 -> "橙色预警"
        risk >= 45 -> "黄色预警"
        risk >= 25 -> "蓝色预警"
        else -> "暂无预警"
    }

    fun aiAdvice(): String {
        val storm = selectedStorm() ?: return "当前没有活动风暴。可先生成一个台风进行演练。"
        val risk = estimateRisk(storm)
        return when {
            risk >= 82 -> "极高模拟风险：优先完成危险区域人员转移，停止沿海海上作业，核查避难场所容量、医疗物资和通信备份。当前估算风暴潮 ${estimateSurgeMeters(storm).fmt()} m。"
            risk >= 65 -> "较高模拟风险：对低洼沿海社区启动分区疏散准备，检查排涝、电力和医疗力量。"
            risk >= 45 -> "中等模拟风险：加密观测，检查港口系泊、应急队伍和临时安置点。"
            else -> "当前模拟风险较低：继续监测路径变化，提前检查物资与应急通信。"
        }
    }

    fun setSeed(seed: Int) {
        rngSeed = seed
        random = Random(seed)
        forecastRandom = Random(seed xor 0x5F3759DF)
        physicsAccumulatorSeconds = 0.0
        record("随机种子设置为 $seed")
    }

    fun clearEventLog() = eventLog.clear()

    fun exportLifeHistory(): String {
        val root = JSONObject()
        root.put("format", "TyphoonLab-LifeHistory-v1")
        root.put("simulatedHours", simulatedHours)
        root.put("seed", rngSeed)
        val stormArray = JSONArray()
        storms.forEach { storm ->
            val item = JSONObject()
            item.put("id", storm.id)
            item.put("name", storm.name)
            item.put("alive", storm.alive)
            item.put("isMain", storm.isMain)
            item.put("latitude", storm.latitude)
            item.put("longitude", storm.longitude)
            item.put("headingDeg", storm.headingDeg)
            item.put("speedKmh", storm.speedKmh)
            item.put("ageHours", storm.ageHours)
            item.put("category", storm.category())
            item.put("phase", storm.phase)
            item.put("windMs", storm.windMs)
            item.put("pressureHpa", storm.pressureHpa)
            item.put("maxGustMs", storm.maxGustMs)
            item.put("rainRateMmH", storm.rainRateMmH)
            item.put("accumulatedRainMm", storm.accumulatedRainMm)
            item.put("radius34Km", storm.radius34Km)
            item.put("radius50Km", storm.radius50Km)
            item.put("radius64Km", storm.radius64Km)
            item.put("eyeRadiusKm", storm.eyeRadiusKm)
            item.put("coldWakeC", storm.coldWakeC)
            item.put("windFieldExpansion", storm.windFieldExpansion)
            item.put("pressureBiasHpa", storm.pressureBiasHpa)
            val points = JSONArray()
            storm.history.forEach { (lat, lon) -> points.put(JSONArray().put(lat).put(lon)) }
            item.put("track", points)
            stormArray.put(item)
        }
        root.put("storms", stormArray)
        root.put("events", JSONArray(eventLog))
        root.put("replay", JSONObject(exportReplayTimeline()))
        return root.toString(2)
    }

    fun restoreState(json: String) {
        require(json.length <= MAX_SCENARIO_JSON_CHARS) { "存档文件过大，已拒绝载入。" }
        val root = JSONObject(json)
        fun safeDouble(value: Double, fallback: Double, minValue: Double, maxValue: Double): Double =
            (if (value.isFinite()) value else fallback).coerceIn(minValue, maxValue)

        simulatedHours = safeDouble(root.optDouble("hours", 0.0), 0.0, 0.0, 10_000_000.0)
        rngSeed = root.optInt("seed", 20261031)
        random = Random(rngSeed)
        forecastRandom = Random(rngSeed xor 0x5F3759DF)
        physicsAccumulatorSeconds = 0.0
        physicsSteps = 0L
        droppedWallSeconds = 0.0
        fujiwharaInteractionSteps = root.optLong("fujiwharaInteractionSteps", 0L).coerceIn(0L, 9_000_000_000_000L)
        seaSurfaceTemp = safeDouble(root.optDouble("sst", 29.0), 29.0, 0.0, 40.0)
        humidity = safeDouble(root.optDouble("humidity", 78.0), 78.0, 0.0, 100.0)
        windShear = safeDouble(root.optDouble("shear", 9.0), 9.0, 0.0, 80.0)
        oceanHeatContent = safeDouble(root.optDouble("heat", 65.0), 65.0, 0.0, 200.0)
        simulationSpeed = safeDouble(root.optDouble("speed", 8.0), 8.0, 0.25, 32.0)
        motionMultiplier = safeDouble(root.optDouble("motion", 1.0), 1.0, 0.25, 4.0)
        steeringFlow = safeDouble(root.optDouble("steeringFlow", 1.0), 1.0, 0.2, 2.5)
        steeringHeadingDeg = wrap360(safeDouble(root.optDouble("steeringHeadingDeg", 290.0), 290.0, -720.0, 720.0))
        landFriction = safeDouble(root.optDouble("landFriction", 1.0), 1.0, 0.2, 3.0)
        manualControl = root.optBoolean("manualControl", true)
        rapidIntensificationEnabled = root.optBoolean("rapidIntensification", true)
        // Never resume a held virtual joystick after process recreation.
        joystickX = 0.0
        joystickY = 0.0
        storms.clear()
        eventLog.clear()
        replayTimeline.clear()
        lastReplaySampleHours = -1.0
        val array = root.optJSONArray("storms")
        nextId = 1L
        var activeCount = 0
        var mainAssigned = false
        if (array != null) {
            val startIndex = (array.length() - MAX_RETAINED_STORMS).coerceAtLeast(0)
            for (i in startIndex until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val lat = safeDouble(item.optDouble("lat", 15.0), 15.0, -60.0, 60.0)
                val lon = wrapLon(safeDouble(item.optDouble("lon", 135.0), 135.0, -540.0, 540.0))
                val wind = safeDouble(item.optDouble("wind", 25.0), 25.0, 8.0, 90.0)
                val id = item.optLong("id", nextId).coerceIn(1L, Long.MAX_VALUE - 1L)
                val aliveRequested = item.optBoolean("alive", true)
                val alive = aliveRequested && activeCount < MAX_ACTIVE_STORMS
                if (alive) activeCount++
                val mainRequested = item.optBoolean("main", false)
                val isMain = alive && mainRequested && !mainAssigned
                if (isMain) mainAssigned = true
                val storm = Storm(
                    id = id,
                    name = item.optString("name", "台风-${i + 1}").take(48),
                    latitude = lat,
                    longitude = lon,
                    windMs = wind,
                    pressureHpa = safeDouble(item.optDouble("pressure", 990.0), 990.0, 850.0, 1050.0),
                    headingDeg = wrap360(safeDouble(item.optDouble("heading", 285.0), 285.0, -720.0, 720.0)),
                    speedKmh = safeDouble(item.optDouble("speed", 42.0), 42.0, 0.0, 180.0),
                    ageHours = safeDouble(item.optDouble("age", 0.0), 0.0, 0.0, 100_000.0),
                    alive = alive,
                    isMain = isMain,
                    maxGustMs = safeDouble(item.optDouble("gust", wind * 1.45), wind * 1.45, 8.0, 150.0),
                    radius34Km = safeDouble(item.optDouble("r34", 150.0), 150.0, 0.0, 1000.0),
                    radius50Km = safeDouble(item.optDouble("r50", 85.0), 85.0, 0.0, 700.0),
                    radius64Km = safeDouble(item.optDouble("r64", 42.0), 42.0, 0.0, 500.0),
                    eyeRadiusKm = safeDouble(item.optDouble("eye", 24.0), 24.0, 0.0, 100.0),
                    rainRateMmH = safeDouble(item.optDouble("rainRate", 35.0), 35.0, 0.0, 500.0),
                    accumulatedRainMm = safeDouble(item.optDouble("rainTotal", 0.0), 0.0, 0.0, 100_000.0),
                    coldWakeC = safeDouble(item.optDouble("wake", 0.0), 0.0, 0.0, 10.0),
                    phase = item.optString("phase", "发展中").take(32),
                    overLandHours = safeDouble(item.optDouble("landHours", 0.0), 0.0, 0.0, 100_000.0),
                    eyeWallCycleTimerHours = safeDouble(item.optDouble("eyeTimer", 0.0), 0.0, 0.0, 100_000.0),
                    eyeWallCycleCount = item.optInt("eyeCycles", 0).coerceIn(0, 10_000),
                    riCheckAgeHours = safeDouble(item.optDouble("riAge", 0.0), 0.0, 0.0, 100_000.0),
                    riCheckWindMs = safeDouble(item.optDouble("riWind", wind), wind, 0.0, 120.0),
                    windFieldExpansion = safeDouble(item.optDouble("fieldExpansion", 1.0), 1.0, 0.5, 2.0),
                    pressureBiasHpa = safeDouble(item.optDouble("pBias", 0.0), 0.0, -100.0, 100.0)
                )
                storm.wasOnLand = item.optBoolean("onLand", isApproxLand(lat, lon))
                val history = item.optJSONArray("history")
                if (history != null) {
                    val historyStart = (history.length() - MAX_TRACK_POINTS).coerceAtLeast(0)
                    for (j in historyStart until history.length()) {
                        val pair = history.optJSONArray(j) ?: continue
                        if (pair.length() >= 2) {
                            val hLat = pair.optDouble(0, Double.NaN)
                            val hLon = pair.optDouble(1, Double.NaN)
                            if (hLat.isFinite() && hLon.isFinite()) {
                                storm.history.add(hLat.coerceIn(-60.0, 60.0) to wrapLon(hLon))
                            }
                        }
                    }
                }
                if (storm.history.isEmpty()) storm.history.add(lat to lon)
                storms.add(storm)
                nextId = max(nextId, storm.id + 1)
            }
        }
        if (storms.none { it.alive && it.isMain }) storms.firstOrNull { it.alive }?.isMain = true
        val events = root.optJSONArray("events")
        if (events != null) {
            val start = (events.length() - MAX_EVENT_LOG).coerceAtLeast(0)
            for (i in start until events.length()) eventLog.add(events.optString(i).take(300))
        }
        val replay = root.optJSONArray("replay")
        if (replay != null) {
            val start = (replay.length() - MAX_REPLAY_FRAMES).coerceAtLeast(0)
            for (i in start until replay.length()) {
                val frame = replay.optJSONObject(i) ?: continue
                val lat = frame.optDouble("lat", Double.NaN)
                val lon = frame.optDouble("lon", Double.NaN)
                val hours = frame.optDouble("hours", Double.NaN)
                if (!lat.isFinite() || !lon.isFinite() || !hours.isFinite()) continue
                replayTimeline.add(ReplayFrame(
                    safeDouble(hours, 0.0, 0.0, simulatedHours), frame.optString("name", "台风").take(48),
                    lat.coerceIn(-60.0, 60.0), wrapLon(lon),
                    safeDouble(frame.optDouble("windMs", 0.0), 0.0, 0.0, 120.0),
                    safeDouble(frame.optDouble("pressureHpa", 1010.0), 1010.0, 800.0, 1100.0),
                    safeDouble(frame.optDouble("rainRateMmH", 0.0), 0.0, 0.0, 500.0),
                    frame.optString("phase", "未知阶段").take(32)
                ))
            }
            lastReplaySampleHours = replayTimeline.lastOrNull()?.simulatedHours ?: -1.0
        }
        if (replayTimeline.isEmpty()) captureReplayFrame(force = true)
        record("模拟存档已恢复（边界校验完成）")
    }

    fun exportState(): String {
        val root = JSONObject()
        root.put("hours", simulatedHours)
        root.put("seed", rngSeed)
        root.put("fujiwharaInteractionSteps", fujiwharaInteractionSteps)
        root.put("sst", seaSurfaceTemp)
        root.put("humidity", humidity)
        root.put("shear", windShear)
        root.put("heat", oceanHeatContent)
        root.put("speed", simulationSpeed)
        root.put("motion", motionMultiplier)
        root.put("steeringFlow", steeringFlow)
        root.put("steeringHeadingDeg", steeringHeadingDeg)
        root.put("landFriction", landFriction)
        root.put("manualControl", manualControl)
        root.put("rapidIntensification", rapidIntensificationEnabled)
        val array = JSONArray()
        storms.forEach { storm ->
            val item = JSONObject()
            item.put("id", storm.id); item.put("name", storm.name)
            item.put("lat", storm.latitude); item.put("lon", storm.longitude)
            item.put("wind", storm.windMs); item.put("pressure", storm.pressureHpa)
            item.put("heading", storm.headingDeg); item.put("speed", storm.speedKmh)
            item.put("age", storm.ageHours); item.put("alive", storm.alive); item.put("main", storm.isMain)
            item.put("gust", storm.maxGustMs); item.put("r34", storm.radius34Km); item.put("r50", storm.radius50Km); item.put("r64", storm.radius64Km)
            item.put("eye", storm.eyeRadiusKm); item.put("rainRate", storm.rainRateMmH); item.put("rainTotal", storm.accumulatedRainMm)
            item.put("wake", storm.coldWakeC); item.put("phase", storm.phase); item.put("onLand", storm.wasOnLand)
            item.put("landHours", storm.overLandHours); item.put("eyeTimer", storm.eyeWallCycleTimerHours); item.put("eyeCycles", storm.eyeWallCycleCount)
            item.put("riAge", storm.riCheckAgeHours); item.put("riWind", storm.riCheckWindMs)
            item.put("fieldExpansion", storm.windFieldExpansion); item.put("pBias", storm.pressureBiasHpa)
            val history = JSONArray()
            storm.history.forEach { point -> history.put(JSONArray().put(point.first).put(point.second)) }
            item.put("history", history)
            array.put(item)
        }
        root.put("storms", array)
        root.put("events", JSONArray(eventLog))
        val replay = JSONArray()
        replayTimeline.forEach { frame ->
            replay.put(JSONObject().apply {
                put("hours", frame.simulatedHours); put("name", frame.stormName)
                put("lat", frame.latitude); put("lon", frame.longitude)
                put("windMs", frame.windMs); put("pressureHpa", frame.pressureHpa)
                put("rainRateMmH", frame.rainRateMmH); put("phase", frame.phase)
            })
        }
        root.put("replay", replay)
        return root.toString()
    }

    private fun record(message: String) {
        eventLog.add("T+${simulatedHours.roundToInt()}h  $message")
        if (eventLog.size > 240) eventLog.removeAt(0)
    }

    private fun Double.fmt(): String = String.format("%.1f", this)

    companion object {
        const val MAX_ACTIVE_STORMS = 12
        const val MAX_RETAINED_STORMS = 48
        const val MAX_TRACK_POINTS = 1200
        const val MAX_EVENT_LOG = 240
        const val MAX_REPLAY_FRAMES = 960
        const val MAX_SCENARIO_JSON_CHARS = 8 * 1024 * 1024
        private const val PHYSICS_STEP_SECONDS = 1.0 / 30.0
        private const val MAX_PHYSICS_STEPS_PER_FRAME = 8
        private const val MAX_WALL_DELTA_SECONDS = 0.25

        fun wrapLon(lon: Double): Double = ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
        fun wrap360(d: Double): Double = (d % 360.0 + 360.0) % 360.0
        private fun shortestLonDelta(a: Double, b: Double): Double = ((b - a + 540.0) % 360.0) - 180.0
        private fun shortestAngleDelta(from: Double, to: Double): Double = ((to - from + 540.0) % 360.0) - 180.0

        private fun isApproxLand(lat: Double, lon: Double): Boolean {
            fun inBox(w: Double, e: Double, s: Double, n: Double) = lon in w..e && lat in s..n
            return inBox(-168.0, -52.0, 8.0, 72.0) || inBox(-82.0, -34.0, -56.0, 12.0) ||
                inBox(-12.0, 42.0, -35.0, 37.0) || inBox(-12.0, 180.0, 5.0, 78.0) ||
                inBox(112.0, 154.0, -44.0, -10.0) || inBox(95.0, 155.0, -11.0, 6.0)
        }
    }
}
