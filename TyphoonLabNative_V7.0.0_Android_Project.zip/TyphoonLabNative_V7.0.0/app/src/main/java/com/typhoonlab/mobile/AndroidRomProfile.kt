package com.typhoonlab.mobile

/** Pure classifier kept independent from Android APIs so ROM detection can be regression-tested. */
enum class RomFamily { XIAOMI_HYPEROS, XIAOMI_MIUI, XIAOMI_UNKNOWN, OTHER }

data class RomProfile(
    val family: RomFamily,
    val displayName: String,
    val isXiaomiFamily: Boolean
)

object AndroidRomProfile {
    fun classify(
        manufacturer: String,
        brand: String,
        hyperOsVersion: String?,
        miuiVersion: String?
    ): RomProfile {
        val maker = manufacturer.trim().lowercase()
        val deviceBrand = brand.trim().lowercase()
        val xiaomi = listOf(maker, deviceBrand).any {
            it.contains("xiaomi") || it == "redmi" || it == "poco"
        }
        val hyper = hyperOsVersion?.trim().orEmpty()
        val miui = miuiVersion?.trim().orEmpty()
        return when {
            xiaomi && hyper.isNotEmpty() -> RomProfile(RomFamily.XIAOMI_HYPEROS, "澎湃 OS $hyper", true)
            xiaomi && miui.isNotEmpty() -> RomProfile(RomFamily.XIAOMI_MIUI, "MIUI $miui", true)
            xiaomi -> RomProfile(RomFamily.XIAOMI_UNKNOWN, "小米系系统（未能读取 ROM 版本）", true)
            else -> RomProfile(RomFamily.OTHER, "其他 Android 系统", false)
        }
    }
}
