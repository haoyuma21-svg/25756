package com.typhoonlab.mobile

/**
 * Pure Kotlin device/ROM identification. It deliberately avoids hidden Xiaomi APIs and
 * never requests autostart privileges; those controls remain under the user's system settings.
 */
data class AndroidDeviceProfile(
    val romLabel: String,
    val isXiaomiFamily: Boolean,
    val isHyperOs: Boolean,
    val isMiui: Boolean,
    val androidRelease: String,
    val apiLevel: Int,
    val minimumSdkSupported: Boolean,
    val guidance: List<String>
)

object DeviceCompatibility {
    const val MIN_SUPPORTED_API = 26
    const val TARGET_API = 36

    fun detect(
        manufacturer: String?,
        brand: String?,
        display: String?,
        androidRelease: String?,
        apiLevel: Int
    ): AndroidDeviceProfile {
        val build = display.orEmpty()
        val hyperMatch = Regex(
            "(?:HYPEROS\\s*)?(OS[123]\\.[0-9]+(?:\\.[0-9]+){0,3}|HYPEROS\\s+[0-9]+(?:\\.[0-9]+){0,3})",
            RegexOption.IGNORE_CASE
        ).find(build)
        val hyperOsVersion = hyperMatch?.value?.trim().orEmpty()
        val miuiMatch = Regex("MIUI\\s*([A-Za-z]*[0-9][A-Za-z0-9._-]*)?", RegexOption.IGNORE_CASE).find(build)
        val miuiVersion = miuiMatch?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }
            ?: if (miuiMatch != null) "版本号未公开" else ""
        val romProfile = AndroidRomProfile.classify(
            manufacturer = manufacturer.orEmpty(),
            brand = brand.orEmpty(),
            hyperOsVersion = hyperOsVersion,
            miuiVersion = miuiVersion
        )
        val isXiaomi = romProfile.isXiaomiFamily
        val isHyperOs = romProfile.family == RomFamily.XIAOMI_HYPEROS
        val isMiui = romProfile.family == RomFamily.XIAOMI_MIUI
        val rom = when (romProfile.family) {
            RomFamily.XIAOMI_HYPEROS -> "澎湃 OS / HyperOS（${romProfile.displayName}）"
            RomFamily.XIAOMI_MIUI -> "MIUI（${romProfile.displayName}）"
            RomFamily.XIAOMI_UNKNOWN -> "小米系系统（未能从构建标识确认 HyperOS/MIUI）"
            RomFamily.OTHER -> "Android / 其他厂商系统"
        }
        val guidance = buildList {
            if (apiLevel >= 36) {
                add("Android 16 / API 36：应用目标 API 36；使用系统 Insets 处理边到边布局，并通过 AndroidX 返回分发器接收返回操作。")
                add("Android 16 大屏设备可能忽略方向/宽高比限制；应用需在横竖屏、分屏和窗口缩放下重新布局。")
            } else if (apiLevel == 35) {
                add("Android 15 / API 35：目标 API 36 的应用运行在 Android 15 时同样采用边到边布局，需保留系统栏 Insets。")
            } else if (apiLevel >= MIN_SUPPORTED_API) {
                add("当前系统低于 Android 15；仍可运行，但系统栏和后台策略以本机系统版本为准。")
            } else {
                add("当前 Android API 低于最低支持版本 26，无法保证兼容。")
            }
            if (isXiaomi) {
                add("小米系系统：普通前台模拟不需要自启动权限；本应用不会注册开机自启接收器，也不会请求隐藏的厂商权限。")
                add("若长时间下载地图时系统限制后台活动，可到设置 > 应用 > 台风实验室 > 电池/省电策略中按需调整；菜单名称会因 MIUI/澎湃 OS 版本和地区不同。")
                add("自启动默认关闭是系统的隐私与省电策略；只有未来确实使用开机后台任务时才需要用户自行开启，本版本不要求开启。")
            } else {
                add("前台模拟无需特殊厂商权限；大文件下载建议保持应用在前台，系统可能在内存压力下终止后台进程。")
            }
            add("地图包使用系统文件选择器和应用可访问的存储位置，不申请旧式全盘存储权限。")
            add("MapLibre 含原生库；最终 APK 仍需检查 ZIP 16 KB 对齐及每个 ELF LOAD 段，并在 16 KB 页设备实测。")
        }
        return AndroidDeviceProfile(
            romLabel = rom,
            isXiaomiFamily = isXiaomi,
            isHyperOs = isHyperOs,
            isMiui = isMiui,
            androidRelease = androidRelease?.takeIf { it.isNotBlank() } ?: "未知",
            apiLevel = apiLevel,
            minimumSdkSupported = apiLevel >= MIN_SUPPORTED_API,
            guidance = guidance
        )
    }
}
