package com.typhoonlab.mobile

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URL
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

/**
 * Point query against Open-Meteo's forecast and marine model APIs.
 * Values are model-grid estimates/forecasts, not direct cyclone-center observations.
 * Requests are intentionally explicit/user-triggered and are never mixed into StormEngine.
 */
data class WeatherProbeSnapshot(
    val requestedLatitude: Double,
    val requestedLongitude: Double,
    val modelLatitude: Double,
    val modelLongitude: Double,
    val marineModelLatitude: Double?,
    val marineModelLongitude: Double?,
    val weatherTime: String,
    val timezone: String,
    val fetchedAtEpochMs: Long,
    val airTemperatureC: Double?,
    val relativeHumidityPercent: Double?,
    val apparentTemperatureC: Double?,
    val precipitationMm: Double?,
    val weatherCode: Int?,
    val cloudCoverPercent: Double?,
    val seaLevelPressureHpa: Double?,
    val windSpeedMs: Double?,
    val windDirectionDeg: Double?,
    val windGustMs: Double?,
    val seaSurfaceTemperatureC: Double?,
    val waveHeightM: Double?,
    val seaLevelHeightM: Double?,
    val oceanCurrentSpeedKmh: Double?,
    val oceanCurrentDirectionDeg: Double?,
    val marineTime: String?
) {
    fun toJson(): String = JSONObject().apply {
        put("requestedLatitude", requestedLatitude)
        put("requestedLongitude", requestedLongitude)
        put("modelLatitude", modelLatitude)
        put("modelLongitude", modelLongitude)
        marineModelLatitude?.let { put("marineModelLatitude", it) }
        marineModelLongitude?.let { put("marineModelLongitude", it) }
        put("weatherTime", weatherTime)
        put("timezone", timezone)
        put("fetchedAtEpochMs", fetchedAtEpochMs)
        airTemperatureC?.let { put("airTemperatureC", it) }
        relativeHumidityPercent?.let { put("relativeHumidityPercent", it) }
        apparentTemperatureC?.let { put("apparentTemperatureC", it) }
        precipitationMm?.let { put("precipitationMm", it) }
        weatherCode?.let { put("weatherCode", it) }
        cloudCoverPercent?.let { put("cloudCoverPercent", it) }
        seaLevelPressureHpa?.let { put("seaLevelPressureHpa", it) }
        windSpeedMs?.let { put("windSpeedMs", it) }
        windDirectionDeg?.let { put("windDirectionDeg", it) }
        windGustMs?.let { put("windGustMs", it) }
        seaSurfaceTemperatureC?.let { put("seaSurfaceTemperatureC", it) }
        waveHeightM?.let { put("waveHeightM", it) }
        seaLevelHeightM?.let { put("seaLevelHeightM", it) }
        oceanCurrentSpeedKmh?.let { put("oceanCurrentSpeedKmh", it) }
        oceanCurrentDirectionDeg?.let { put("oceanCurrentDirectionDeg", it) }
        marineTime?.let { put("marineTime", it) }
        put("provider", PROVIDER_LABEL)
        put("schema", "typhoonlab-weather-probe-v1")
    }.toString()

    companion object {
        const val PROVIDER_LABEL = "Open-Meteo Forecast + Marine API"

        fun fromJson(json: String): WeatherProbeSnapshot {
            require(json.toByteArray(StandardCharsets.UTF_8).size <= 8192) { "气象缓存超过 8 KiB 限制" }
            val root = JSONObject(json)
            require(root.optString("schema") == "typhoonlab-weather-probe-v1") { "气象缓存版本不支持" }
            val snapshot = WeatherProbeSnapshot(
                requestedLatitude = root.getDouble("requestedLatitude"),
                requestedLongitude = root.getDouble("requestedLongitude"),
                modelLatitude = root.getDouble("modelLatitude"),
                modelLongitude = root.getDouble("modelLongitude"),
                marineModelLatitude = root.optionalDouble("marineModelLatitude"),
                marineModelLongitude = root.optionalDouble("marineModelLongitude"),
                weatherTime = root.optString("weatherTime", "未知"),
                timezone = root.optString("timezone", "UTC"),
                fetchedAtEpochMs = root.optLong("fetchedAtEpochMs", 0L),
                airTemperatureC = root.optionalDouble("airTemperatureC"),
                relativeHumidityPercent = root.optionalDouble("relativeHumidityPercent"),
                apparentTemperatureC = root.optionalDouble("apparentTemperatureC"),
                precipitationMm = root.optionalDouble("precipitationMm"),
                weatherCode = root.optionalInt("weatherCode"),
                cloudCoverPercent = root.optionalDouble("cloudCoverPercent"),
                seaLevelPressureHpa = root.optionalDouble("seaLevelPressureHpa"),
                windSpeedMs = root.optionalDouble("windSpeedMs"),
                windDirectionDeg = root.optionalDouble("windDirectionDeg"),
                windGustMs = root.optionalDouble("windGustMs"),
                seaSurfaceTemperatureC = root.optionalDouble("seaSurfaceTemperatureC"),
                waveHeightM = root.optionalDouble("waveHeightM"),
                seaLevelHeightM = root.optionalDouble("seaLevelHeightM"),
                oceanCurrentSpeedKmh = root.optionalDouble("oceanCurrentSpeedKmh"),
                oceanCurrentDirectionDeg = root.optionalDouble("oceanCurrentDirectionDeg"),
                marineTime = root.optString("marineTime").takeIf { it.isNotBlank() }
            )
            require(snapshot.requestedLatitude.isFinite() && snapshot.requestedLatitude in -90.0..90.0) { "气象缓存纬度无效" }
            require(snapshot.requestedLongitude.isFinite() && snapshot.requestedLongitude in -180.0..180.0) { "气象缓存经度无效" }
            require(snapshot.modelLatitude.isFinite() && snapshot.modelLatitude in -90.0..90.0) { "天气模式网格纬度无效" }
            require(snapshot.modelLongitude.isFinite() && snapshot.modelLongitude in -180.0..180.0) { "天气模式网格经度无效" }
            require(snapshot.marineModelLatitude == null || snapshot.marineModelLatitude in -90.0..90.0) { "海洋模式网格纬度无效" }
            require(snapshot.marineModelLongitude == null || snapshot.marineModelLongitude in -180.0..180.0) { "海洋模式网格经度无效" }
            require(snapshot.fetchedAtEpochMs > 0L) { "气象缓存时间无效" }
            return snapshot
        }

        private fun JSONObject.optionalDouble(name: String): Double? {
            if (!has(name) || isNull(name)) return null
            return optDouble(name, Double.NaN).takeIf { it.isFinite() }
        }

        private fun JSONObject.optionalInt(name: String): Int? {
            if (!has(name) || isNull(name)) return null
            return optInt(name, Int.MIN_VALUE).takeIf { it != Int.MIN_VALUE }
        }
    }
}

object WeatherModelClient {
    private const val WEATHER_ENDPOINT = "https://api.open-meteo.com/v1/forecast"
    private const val MARINE_ENDPOINT = "https://marine-api.open-meteo.com/v1/marine"
    private const val CONNECT_TIMEOUT_MS = 12_000
    private const val READ_TIMEOUT_MS = 18_000
    private const val MAX_RESPONSE_BYTES = 1_500_000L

    /** Fetch a single point. Marine fields are nullable when the model has no data at that point. */
    fun fetch(latitude: Double, longitude: Double): WeatherProbeSnapshot {
        require(latitude.isFinite() && latitude in -90.0..90.0) { "纬度超出范围" }
        require(longitude.isFinite() && longitude in -180.0..180.0) { "经度超出范围" }
        check(!Thread.currentThread().isInterrupted) { "请求已取消" }

        val lat = String.format(Locale.US, "%.5f", latitude)
        val lon = String.format(Locale.US, "%.5f", longitude)
        val weatherQuery = listOf(
            "latitude" to lat,
            "longitude" to lon,
            "current" to "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m",
            "wind_speed_unit" to "ms",
            "temperature_unit" to "celsius",
            "timezone" to "auto"
        )
        val weather = fetchJson(buildUrl(WEATHER_ENDPOINT, weatherQuery))
        val current = weather.optJSONObject("current") ?: throw IOException("天气模型响应缺少 current 数据")

        check(!Thread.currentThread().isInterrupted) { "请求已取消" }
        val marineQuery = listOf(
            "latitude" to lat,
            "longitude" to lon,
            "current" to "sea_surface_temperature,wave_height,sea_level_height_msl,ocean_current_velocity,ocean_current_direction",
            "cell_selection" to "sea",
            "timezone" to "auto"
        )
        // Marine grids do not cover every inland/coastal point. Preserve the weather result
        // and leave unavailable ocean values null rather than inventing zeroes.
        val marine = try {
            fetchJson(buildUrl(MARINE_ENDPOINT, marineQuery))
        } catch (interrupted: InterruptedException) {
            throw interrupted
        } catch (_: Exception) {
            null
        }
        val marineCurrent = marine?.optJSONObject("current")

        return WeatherProbeSnapshot(
            requestedLatitude = latitude,
            requestedLongitude = longitude,
            modelLatitude = weather.optDouble("latitude", latitude),
            modelLongitude = weather.optDouble("longitude", longitude),
            marineModelLatitude = marine?.optDouble("latitude", Double.NaN)?.takeIf { it.isFinite() },
            marineModelLongitude = marine?.optDouble("longitude", Double.NaN)?.takeIf { it.isFinite() },
            weatherTime = current.optString("time", "未知"),
            timezone = weather.optString("timezone", "UTC"),
            fetchedAtEpochMs = System.currentTimeMillis(),
            airTemperatureC = current.optionalDouble("temperature_2m"),
            relativeHumidityPercent = current.optionalDouble("relative_humidity_2m"),
            apparentTemperatureC = current.optionalDouble("apparent_temperature"),
            precipitationMm = current.optionalDouble("precipitation"),
            weatherCode = current.optionalInt("weather_code"),
            cloudCoverPercent = current.optionalDouble("cloud_cover"),
            seaLevelPressureHpa = current.optionalDouble("pressure_msl"),
            windSpeedMs = current.optionalDouble("wind_speed_10m"),
            windDirectionDeg = current.optionalDouble("wind_direction_10m"),
            windGustMs = current.optionalDouble("wind_gusts_10m"),
            seaSurfaceTemperatureC = marineCurrent?.optionalDouble("sea_surface_temperature"),
            waveHeightM = marineCurrent?.optionalDouble("wave_height"),
            seaLevelHeightM = marineCurrent?.optionalDouble("sea_level_height_msl"),
            oceanCurrentSpeedKmh = marineCurrent?.optionalDouble("ocean_current_velocity"),
            oceanCurrentDirectionDeg = marineCurrent?.optionalDouble("ocean_current_direction"),
            marineTime = marineCurrent?.optString("time")?.takeIf { !it.isNullOrBlank() }
        )
    }

    private fun buildUrl(endpoint: String, parameters: List<Pair<String, String>>): String =
        endpoint + "?" + parameters.joinToString("&") { (key, value) ->
            "${encode(key)}=${encode(value)}"
        }

    private fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())

    private fun fetchJson(urlText: String): JSONObject {
        val url = URI(urlText).toURL()
        require(url.protocol.equals("https", true)) { "只允许 HTTPS 气象数据源" }
        val connection = (url.openConnection() as HttpsURLConnection).apply {
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            requestMethod = "GET"
            // The fixed API endpoints do not require redirects. Refuse redirects rather than
            // allowing a downgrade or an unexpected host hop.
            instanceFollowRedirects = false
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "TyphoonLab-Android/7.0.0")
        }
        try {
            val status = connection.responseCode
            if (status in 300..399) throw IOException("气象服务返回重定向，已按固定 HTTPS 数据源策略拒绝")
            if (!connection.url.protocol.equals("https", true)) throw IOException("气象服务重定向到非 HTTPS 地址，已拒绝")
            if (status !in 200..299) throw IOException("气象服务返回 HTTP $status")
            val declared = connection.contentLengthLong
            if (declared > MAX_RESPONSE_BYTES) throw IOException("气象服务响应超过安全大小限制")
            val output = ByteArrayOutputStream(if (declared in 1..MAX_RESPONSE_BYTES) declared.toInt() else 32 * 1024)
            connection.inputStream.use { input ->
                val buffer = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("气象数据请求已取消")
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count.toLong()
                    if (total > MAX_RESPONSE_BYTES) throw IOException("气象服务响应超过安全大小限制")
                    output.write(buffer, 0, count)
                }
            }
            val body = output.toString(StandardCharsets.UTF_8.name())
            if (body.isBlank()) throw IOException("气象服务返回空响应")
            return try { JSONObject(body) } catch (e: Exception) {
                throw IOException("气象服务 JSON 格式无效", e)
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun JSONObject.optionalDouble(name: String): Double? {
        if (!has(name) || isNull(name)) return null
        return optDouble(name, Double.NaN).takeIf { it.isFinite() }
    }

    private fun JSONObject.optionalInt(name: String): Int? {
        if (!has(name) || isNull(name)) return null
        return optInt(name, Int.MIN_VALUE).takeIf { it != Int.MIN_VALUE }
    }
}
