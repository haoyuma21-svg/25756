package com.typhoonlab.mobile

/** Basin-level summary for the local simulation only; never represents live operational warnings. */
data class BasinRegion(
    val id: String,
    val name: String,
    val centerLatitude: Double,
    val centerLongitude: Double,
    val description: String
)

data class BasinStatus(
    val region: BasinRegion,
    val stormCount: Int,
    val strongestWindMs: Double,
    val lowestPressureHpa: Double?,
    val maximumRisk: Int,
    val strongestStormName: String?
) {
    val stateLabel: String
        get() = when {
            stormCount == 0 -> "暂无模拟风暴"
            maximumRisk >= 80 -> "极高模拟风险"
            maximumRisk >= 60 -> "高模拟风险"
            maximumRisk >= 40 -> "中等模拟风险"
            else -> "持续监测"
        }
}

data class GlobalSituation(
    val simulatedHours: Double,
    val activeStormCount: Int,
    val strongestWindMs: Double,
    val lowestPressureHpa: Double?,
    val highestRisk: Int,
    val regions: List<BasinStatus>
)

object GlobalCommandCenter {
    val basins = listOf(
        BasinRegion("wpac", "西北太平洋", 20.0, 140.0, "菲律宾海、日本以南与西北太平洋"),
        BasinRegion("epac", "东北太平洋", 18.0, -125.0, "墨西哥以西至中太平洋东部"),
        BasinRegion("natl", "北大西洋", 25.0, -60.0, "加勒比海、墨西哥湾与北大西洋"),
        BasinRegion("nind", "北印度洋", 15.0, 80.0, "阿拉伯海与孟加拉湾"),
        BasinRegion("swind", "南印度洋", -20.0, 65.0, "南印度洋热带海域"),
        BasinRegion("auspac", "澳洲—南太平洋", -18.0, 150.0, "澳大利亚北部与南太平洋西部"),
        BasinRegion("satl", "南大西洋", -20.0, -25.0, "南大西洋热带海域")
    )

    fun build(engine: StormEngine): GlobalSituation {
        val active = engine.activeStorms()
        val byBasin = basins.map { basin ->
            val storms = active.filter { belongsTo(it, basin.id) }
            val strongest = storms.maxByOrNull { it.windMs }
            BasinStatus(
                region = basin,
                stormCount = storms.size,
                strongestWindMs = strongest?.windMs ?: 0.0,
                lowestPressureHpa = storms.minOfOrNull { it.pressureHpa },
                maximumRisk = storms.maxOfOrNull { engine.estimateRisk(it) } ?: 0,
                strongestStormName = strongest?.name
            )
        }
        return GlobalSituation(
            simulatedHours = engine.simulatedHours,
            activeStormCount = active.size,
            strongestWindMs = active.maxOfOrNull { it.windMs } ?: 0.0,
            lowestPressureHpa = active.minOfOrNull { it.pressureHpa },
            highestRisk = active.maxOfOrNull { engine.estimateRisk(it) } ?: 0,
            regions = byBasin
        )
    }

    fun locate(storm: Storm, basinId: String): Boolean = belongsTo(storm, basinId)

    private fun belongsTo(storm: Storm, basinId: String): Boolean {
        val lat = storm.latitude
        val lon = StormEngine.wrapLon(storm.longitude)
        return when (basinId) {
            // The dateline wraps to -180° in StormEngine.wrapLon; include that sliver
            // in the western Pacific instead of misclassifying it as the eastern Pacific.
            "wpac" -> lat in -5.0..60.0 && (lon >= 100.0 || lon <= -170.0)
            "epac" -> lat in 0.0..50.0 && lon in -170.0..-100.0
            "natl" -> lat in 0.0..55.0 && lon in -100.0..-10.0
            "nind" -> lat in 0.0..35.0 && lon in 40.0..100.0
            "swind" -> lat in -45.0..0.0 && lon in 20.0..100.0
            "auspac" -> lat in -45.0..0.0 && (lon >= 100.0 || lon <= -170.0)
            "satl" -> lat in -45.0..0.0 && lon in -70.0..20.0
            else -> false
        }
    }
}
