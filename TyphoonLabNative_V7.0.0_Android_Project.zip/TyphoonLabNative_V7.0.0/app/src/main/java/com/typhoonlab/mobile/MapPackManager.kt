package com.typhoonlab.mobile

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Offline PMTiles library.
 * - 60 GB decimal quota, checked with Long counters.
 * - Streaming import/download; archives are never loaded into memory.
 * - HTTPS download supports HTTP Range resume where the server supports it.
 */
object MapPackManager {
    const val MAX_MAP_PACK_STORAGE_BYTES: Long = 60_000_000_000L
    private const val BUFFER_BYTES = 2 * 1024 * 1024
    private const val RESERVED_FREE_BYTES = 256L * 1024L * 1024L

    data class Volume(val label: String, val root: File, val availableBytes: Long, val totalBytes: Long)
    data class Pack(val name: String, val file: File, val bytes: Long)
    data class PartialDownload(val name: String, val url: String, val file: File, val volume: Volume, val bytes: Long)

    fun volumes(context: Context): List<Volume> {
        val dirs = context.getExternalFilesDirs(Environment.DIRECTORY_DOCUMENTS)
            .filterNotNull()
            .map { File(it, "TyphoonLab/MapPacks") }
        val candidates = (dirs + File(context.filesDir, "MapPacks")).distinctBy { it.absolutePath }
        return candidates.mapNotNull { dir ->
            runCatching {
                dir.mkdirs()
                val stat = StatFs(dir.absolutePath)
                Volume(
                    label = if (dir.absolutePath.contains("/Android/data/")) {
                        if (dir.absolutePath.contains("emulated")) "手机内部存储" else "外置存储卡 / 设备卷"
                    } else "应用内部存储",
                    root = dir,
                    availableBytes = stat.availableBytes,
                    totalBytes = stat.totalBytes
                )
            }.getOrNull()
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        var name = "satellite.pmtiles"
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val i = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = cursor.getString(i) ?: name
            }
        }
        return name
    }

    fun declaredSize(context: Context, uri: Uri): Long {
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val i = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && !cursor.isNull(i)) cursor.getLong(i) else -1L
            } else -1L
        } ?: -1L
    }

    /** PMTiles v3 is the supported archive format for the current native map source. */
    fun validateHeader(context: Context, uri: Uri): Boolean {
        val declared = declaredSize(context, uri)
        if (declared in 1 until 127L) return false
        return runCatching { context.contentResolver.openInputStream(uri)?.use { validateHeader(it) } ?: false }.getOrDefault(false)
    }

    fun validateFileHeader(file: File): Boolean = runCatching {
        file.length() >= 127L && FileInputStream(file).buffered().use { validateHeader(it) }
    }.getOrDefault(false)

    private fun validateHeader(input: java.io.InputStream): Boolean {
        val header = ByteArray(8)
        var total = 0
        while (total < header.size) {
            val n = input.read(header, total, header.size - total)
            if (n < 0) break
            total += n
        }
        val expected = "PMTiles".toByteArray(Charsets.US_ASCII)
        return total == 8 && expected.indices.all { header[it] == expected[it] } && header[7].toInt() == 3
    }

    /** Copies in 2 MiB chunks. Existing package is preserved until the new copy is complete. */
    fun importPack(
        context: Context,
        uri: Uri,
        volume: Volume,
        onProgress: (copied: Long, total: Long) -> Unit
    ): File {
        val safeName = safePackageName(displayName(context, uri))
        val total = declaredSize(context, uri)
        if (total > 0 && volume.availableBytes < total + RESERVED_FREE_BYTES) {
            throw IllegalStateException("存储空间不足：文件约 ${formatBytes(total)}，可用空间 ${formatBytes(volume.availableBytes)}")
        }
        val target = File(volume.root, safeName)
        val temp = File(volume.root, "$safeName.importing")
        val backup = File(volume.root, "$safeName.backup")
        val usedElsewhere = listPacks(context).filterNot { it.file.absolutePath == target.absolutePath }.sumOf { it.bytes }
        val partialBytes = partialDownloads(context).sumOf { it.bytes }
        if (usedElsewhere + partialBytes + maxOf(0L, total) > MAX_MAP_PACK_STORAGE_BYTES) {
            throw IllegalStateException("游戏离线地图资源配额为 60 GB。当前已使用 ${formatBytes(usedElsewhere)}，本次文件 ${formatBytes(total)}，超过配额。")
        }
        var copied = 0L
        try {
            val input = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("无法读取所选文件")
            input.use { src ->
                BufferedOutputStream(FileOutputStream(temp, false), BUFFER_BYTES).use { out ->
                    val buffer = ByteArray(BUFFER_BYTES)
                    while (true) {
                        if (Thread.currentThread().isInterrupted) {
                            throw InterruptedException("离线地图导入已暂停；原地图包保持不变。")
                        }
                        val count = src.read(buffer)
                        if (count < 0) break
                        out.write(buffer, 0, count)
                        copied += count.toLong()
                        ensureCapacity(volume, copied)
                        if (usedElsewhere + partialBytes + copied > MAX_MAP_PACK_STORAGE_BYTES) {
                            throw IllegalStateException("已达到游戏离线地图资源 60 GB 配额（已安装包 + 未完成下载 + 本次导入）。")
                        }
                        if (copied % (16L * 1024L * 1024L) < buffer.size) onProgress(copied, total)
                    }
                    out.flush()
                }
            }
            if (total > 0L && copied != total) {
                throw IllegalStateException("本地文件读取长度不完整：实际复制 ${formatBytes(copied)}，文件提供器声明 ${formatBytes(total)}。原影像包未被替换。")
            }
            if (!validateFileHeader(temp)) throw IllegalStateException("文件并非受支持的 PMTiles v3 影像包")
            replaceAtomically(temp, target, backup)
            onProgress(copied, if (total > 0) total else copied)
            return target
        } catch (e: Exception) {
            temp.delete()
            if (backup.exists() && !target.exists()) backup.renameTo(target)
            throw e
        }
    }

    /**
     * Downloads a PMTiles archive via HTTPS. If a previous .part file exists, Range is requested.
     * If the host does not support range requests, the partial file is safely restarted.
     * Cancellation intentionally keeps the partial archive and its private URL sidecar for resume.
     */
    fun downloadPack(
        context: Context,
        urlText: String,
        requestedName: String,
        volume: Volume,
        shouldCancel: () -> Boolean = { false },
        onProgress: (downloaded: Long, total: Long) -> Unit
    ): File {
        val parsedUri = runCatching { java.net.URI(urlText.trim()) }.getOrElse { throw IllegalArgumentException("下载地址格式不正确") }
        require(parsedUri.scheme.equals("https", true) && !parsedUri.host.isNullOrBlank() && parsedUri.userInfo == null) {
            "只允许 HTTPS 下载地址，且不能在 URL 中嵌入账号密码。"
        }
        val parsed = parsedUri.toURL()
        volume.root.mkdirs()
        val safeName = safePackageName(requestedName.ifBlank { parsed.path.substringAfterLast('/').ifBlank { "satellite.pmtiles" } })
        val target = File(volume.root, safeName)
        val part = File(volume.root, "$safeName.part")
        val sidecar = File(volume.root, "$safeName.part.url")
        if (target.exists()) throw IllegalStateException("同名影像包已经存在，请先在地图仓库中删除或换一个名称。")

        if (sidecar.exists()) {
            val savedUrl = runCatching { sidecar.readText(Charsets.UTF_8) }.getOrDefault("")
            if (savedUrl.isNotBlank() && savedUrl != urlText.trim()) {
                throw IllegalStateException("发现同名未完成下载，但下载地址不同。请换一个包名或删除旧的未完成下载。")
            }
            if (savedUrl.isBlank()) sidecar.writeText(urlText.trim(), Charsets.UTF_8)
        } else {
            sidecar.writeText(urlText.trim(), Charsets.UTF_8)
        }

        val alreadyUsed = listPacks(context).sumOf { it.bytes }
        val otherPartialBytes = partialDownloads(context).filterNot { it.file.absolutePath == part.absolutePath }.sumOf { it.bytes }
        if (alreadyUsed + otherPartialBytes + part.length() > MAX_MAP_PACK_STORAGE_BYTES) throw IllegalStateException("未完成下载也会占用 60 GB 地图配额，请先清理地图包。")
        ensureCapacity(volume, 0L)

        var offset = part.length()
        var connection: HttpURLConnection? = null
        try {
            connection = (parsed.openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 30_000
                requestMethod = "GET"
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", "TyphoonLab-Android/7.0.0")
                setRequestProperty("Accept", "application/vnd.pmtiles, application/octet-stream, */*")
                setRequestProperty("Accept-Encoding", "identity")
                if (offset > 0L) setRequestProperty("Range", "bytes=$offset-")
            }
            val status = connection.responseCode
            if (!connection.url.protocol.equals("https", true)) throw IllegalStateException("下载服务重定向到了非 HTTPS 地址，已拒绝连接。")
            if (status == 416 && offset > 0L) {
                val contentRange = connection.getHeaderField("Content-Range") ?: ""
                val remoteTotal = contentRange.substringAfterLast('/', "").toLongOrNull()
                if (remoteTotal != null && remoteTotal == part.length() && validateFileHeader(part)) {
                    if (target.exists()) throw IllegalStateException("目标地图包名称已被占用，请换一个名称。")
                    if (!part.renameTo(target)) throw IllegalStateException("断点文件已完整，但无法完成安全改名。")
                    sidecar.delete()
                    onProgress(target.length(), target.length())
                    return target
                }
                throw IllegalStateException("服务器拒绝当前断点（HTTP 416），已保留残留文件。请删除该任务后重新下载。")
            }
            if (status !in 200..299) throw IllegalStateException("下载服务器返回 HTTP $status")

            val append = offset > 0L && status == HttpURLConnection.HTTP_PARTIAL
            if (!append) offset = 0L
            val contentLength = connection.contentLengthLong
            if (status == HttpURLConnection.HTTP_OK && contentLength < 0L) {
                throw IllegalStateException("下载服务器没有提供文件总长度（Content-Length）。为避免把不完整的超大影像误装成完整文件，本版本要求服务器提供文件长度。")
            }
            var total = if (contentLength >= 0L) offset + contentLength else -1L
            if (status == HttpURLConnection.HTTP_PARTIAL) {
                val contentRange = connection.getHeaderField("Content-Range") ?: ""
                val match = Regex("^bytes (\\d+)-(\\d+)/(\\d+)$", RegexOption.IGNORE_CASE).matchEntire(contentRange.trim())
                val rangeStart = match?.groupValues?.get(1)?.toLongOrNull()
                val rangeEnd = match?.groupValues?.get(2)?.toLongOrNull()
                val rangeTotal = match?.groupValues?.get(3)?.toLongOrNull()
                if (match == null || rangeStart != offset || rangeEnd == null || rangeTotal == null || rangeEnd < rangeStart) {
                    throw IllegalStateException("服务器返回的 Content-Range 无效或未提供完整文件长度，已拒绝拼接。请删除残留任务后重新下载。")
                }
                if (rangeEnd + 1L != rangeTotal) {
                    throw IllegalStateException("服务器只返回了文件的一部分区间，不是完整剩余数据；为防止生成损坏影像包，已拒绝拼接。")
                }
                if (contentLength >= 0L && rangeEnd - rangeStart + 1L != contentLength) {
                    throw IllegalStateException("服务器分段长度与 Content-Length 不一致，已拒绝拼接。")
                }
                total = rangeTotal
            }
            if (total > 0L && alreadyUsed + otherPartialBytes + total > MAX_MAP_PACK_STORAGE_BYTES) {
                throw IllegalStateException("下载文件预计会超过 60 GB 地图资源配额。")
            }
            val remainingBytes = if (total > 0L && append) (total - offset).coerceAtLeast(0L) else total
            if (remainingBytes > 0L && volume.availableBytes < remainingBytes + RESERVED_FREE_BYTES) {
                throw IllegalStateException("设备存储空间不足：预计还需要 ${formatBytes(remainingBytes)}，当前可用 ${formatBytes(volume.availableBytes)}。")
            }

            var downloaded = offset
            BufferedInputStream(connection.inputStream, BUFFER_BYTES).use { input ->
                BufferedOutputStream(FileOutputStream(part, append), BUFFER_BYTES).use { output ->
                    val buffer = ByteArray(BUFFER_BYTES)
                    while (true) {
                        if (shouldCancel() || Thread.currentThread().isInterrupted) {
                            throw InterruptedException("下载已暂停，部分文件已保留，可稍后继续。")
                        }
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        downloaded += count.toLong()
                        ensureCapacity(volume, downloaded - offset)
                        if (alreadyUsed + otherPartialBytes + downloaded > MAX_MAP_PACK_STORAGE_BYTES) {
                            throw IllegalStateException("下载达到 60 GB 地图资源配额，已暂停并保留部分文件。")
                        }
                        if (downloaded % (4L * 1024L * 1024L) < buffer.size) onProgress(downloaded, total)
                    }
                    output.flush()
                }
            }
            if (total > 0L && part.length() != total) {
                throw IllegalStateException("下载连接提前结束：当前 ${formatBytes(part.length())}，服务器声明 ${formatBytes(total)}。已保留已下载部分，可稍后续传。")
            }
            if (!validateFileHeader(part)) {
                throw IllegalStateException("下载已结束，但文件头不是 PMTiles v3。请检查下载链接是否直接指向 .pmtiles 文件。")
            }
            if (target.exists()) throw IllegalStateException("目标地图包名称已被占用，请换一个名称；原文件未被覆盖。")
            if (!part.renameTo(target)) throw IllegalStateException("下载完成，但无法将临时文件安全改名。可检查存储空间和文件权限后重试。")
            sidecar.delete()
            onProgress(target.length(), target.length())
            return target
        } catch (e: Exception) {
            // Keep .part + .url to allow a later Range resume unless it is an invalid archive.
            if (e.message?.contains("文件头不是 PMTiles") == true) {
                part.delete()
                sidecar.delete()
            }
            throw e
        } finally {
            connection?.disconnect()
        }
    }

    fun partialDownloads(context: Context): List<PartialDownload> = volumes(context).flatMap { volume ->
        volume.root.listFiles { file -> file.isFile && file.name.endsWith(".part") }
            ?.mapNotNull { part ->
                val sidecar = File(part.parentFile, "${part.name}.url")
                val url = runCatching { sidecar.readText(Charsets.UTF_8) }.getOrDefault("")
                if (url.isBlank()) null else PartialDownload(part.name.removeSuffix(".part"), url, part, volume, part.length())
            } ?: emptyList()
    }.sortedByDescending { it.bytes }

    fun deletePartial(item: PartialDownload): Boolean {
        val sidecar = File(item.file.parentFile, "${item.file.name}.url")
        return item.file.delete() && (!sidecar.exists() || sidecar.delete())
    }

    private fun safePackageName(input: String): String {
        val base = input.substringBeforeLast('.', input)
            .replace(Regex("[^A-Za-z0-9_\\u4e00-\\u9fa5-]"), "_")
            .trim('_', '-', '.')
            .ifBlank { "satellite" }
        return "$base.pmtiles"
    }

    private fun ensureCapacity(volume: Volume, bytesWritten: Long) {
        val currentAvailable = runCatching { StatFs(volume.root.absolutePath).availableBytes }.getOrDefault(volume.availableBytes)
        if (currentAvailable < RESERVED_FREE_BYTES || bytesWritten > maxOf(0L, volume.availableBytes - RESERVED_FREE_BYTES)) {
            throw IllegalStateException("存储空间接近不足，已暂停写入。请至少保留 ${formatBytes(RESERVED_FREE_BYTES)} 供系统使用。")
        }
    }

    private fun replaceAtomically(temp: File, target: File, backup: File) {
        if (backup.exists() && !target.exists()) backup.renameTo(target) else backup.delete()
        if (target.exists() && !target.renameTo(backup)) throw IllegalStateException("无法安全备份旧影像包，已取消替换。")
        if (!temp.renameTo(target)) {
            if (backup.exists()) backup.renameTo(target)
            throw IllegalStateException("新影像包无法完成原子替换，旧文件已尝试恢复。")
        }
        backup.delete()
    }

    /** Total quota usage includes installed archives and resumable partial downloads. */
    fun usedBytes(context: Context): Long = listPacks(context).sumOf { it.bytes } + partialDownloads(context).sumOf { it.bytes }

    fun listPacks(context: Context): List<Pack> = volumes(context).flatMap { volume ->
        volume.root.listFiles { file -> file.isFile && file.extension.equals("pmtiles", true) }
            ?.map { Pack(it.name, it, it.length()) } ?: emptyList()
    }.distinctBy { it.file.absolutePath }.sortedByDescending { it.bytes }

    fun formatBytes(bytes: Long): String {
        if (bytes < 0) return "未知"
        val gb = bytes / 1_000_000_000.0
        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            bytes >= 1_000_000 -> String.format("%.1f MB", bytes / 1_000_000.0)
            else -> "$bytes B"
        }
    }
}
