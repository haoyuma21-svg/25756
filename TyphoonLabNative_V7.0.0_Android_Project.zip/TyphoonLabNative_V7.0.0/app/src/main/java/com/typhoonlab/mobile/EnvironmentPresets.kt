package com.typhoonlab.mobile

/** Reusable environmental setups. These are sandbox presets, not observed real-world states. */
data class EnvironmentPreset(
    val id: String,
    val title: String,
    val description: String,
    val seaSurfaceTempC: Double,
    val humidityPercent: Double,
    val windShearMs: Double,
    val oceanHeatContent: Double,
    val steeringFlow: Double,
    val steeringHeadingDeg: Double,
    val landFriction: Double,
    val rapidIntensificationEnabled: Boolean
)

object EnvironmentPresets {
    val all: List<EnvironmentPreset> = listOf(
        EnvironmentPreset(
            "wpac_favorable", "西北太平洋有利增强", "暖海温、高湿、较弱风切变，适合研究增强过程。",
            30.2, 86.0, 5.5, 90.0, 1.05, 295.0, 1.0, true
        ),
        EnvironmentPreset(
            "high_shear", "强风切变抑制", "较强垂直风切变，观察台风结构受扰与强度受抑。",
            28.1, 73.0, 22.0, 55.0, 1.15, 285.0, 1.0, false
        ),
        EnvironmentPreset(
            "coastal_landfall", "近岸登陆演练", "设置近岸环境与较强陆地摩擦；需将风暴移动到陆地附近才能触发登陆衰减。",
            28.4, 82.0, 8.0, 66.0, 0.95, 300.0, 1.55, true
        ),
        EnvironmentPreset(
            "cool_dry", "冷海温干燥环境", "较低海温、较低湿度和偏强风切变，观察风暴逐渐减弱。",
            25.5, 60.0, 16.0, 35.0, 0.90, 265.0, 1.0, false
        ),
        EnvironmentPreset(
            "monsoon_trough", "季风槽扰动环境", "偏高湿度与中等风切变，用于多风暴生成和相互作用实验。",
            29.4, 82.0, 13.0, 72.0, 1.25, 275.0, 1.0, true
        )
    )

    fun find(id: String): EnvironmentPreset? = all.firstOrNull { it.id == id }
}
