package com.typhoonlab.mobile

import kotlin.math.abs

/** Pure map geometry helpers for keeping tracks from drawing across the whole world at the dateline. */
object TrackGeometry {
    /** Input points are (latitude, longitude). A dateline crossing starts a new line segment. */
    fun splitAtAntimeridian(points: List<Pair<Double, Double>>): List<List<Pair<Double, Double>>> {
        if (points.size < 2) return emptyList()
        val result = ArrayList<List<Pair<Double, Double>>>()
        var current = ArrayList<Pair<Double, Double>>()
        var previous: Pair<Double, Double>? = null

        for (point in points) {
            val valid = point.first.isFinite() && point.second.isFinite() &&
                point.first in -90.0..90.0 && point.second in -180.0..180.0
            if (!valid) {
                if (current.size >= 2) result.add(current.toList())
                current = ArrayList()
                previous = null
                continue
            }
            val prior = previous
            if (prior != null && abs(point.second - prior.second) > 180.0) {
                if (current.size >= 2) result.add(current.toList())
                current = ArrayList()
            }
            current.add(point)
            previous = point
        }
        if (current.size >= 2) result.add(current.toList())
        return result
    }
}
