plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.typhoonlab.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.typhoonlab.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 70
        versionName = "7.0.0-android16-xiaomi"
        vectorDrawables.useSupportLibrary = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        // Keep native libraries uncompressed and page-aligned in the APK/AAB package.
        // This is necessary packaging hygiene, but does not prove that each .so ELF is
        // itself 16 KB compatible; inspect the final artifact with the supplied audit script.
        jniLibs.useLegacyPackaging = false
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")

    // Native Android map renderer; OpenGL backend is chosen for broader device compatibility.
    implementation("org.maplibre.gl:android-sdk-opengl:13.7.1")
}
