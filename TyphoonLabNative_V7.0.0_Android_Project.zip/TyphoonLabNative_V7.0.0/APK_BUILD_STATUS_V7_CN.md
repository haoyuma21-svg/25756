# Typhoon Lab V7.0.0 APK 构建与安装状态

检查日期：2026-10-31

**当前状态：APK 尚未生成**

## 本轮实际尝试

已在开发容器中执行：

```bash
./gradlew --no-daemon clean assembleDebug
```

Gradle Wrapper 需要下载 Gradle 8.14.6，但访问 `services.gradle.org` 时 DNS 解析失败，实际报错：

```text
curl: (6) Could not resolve host: services.gradle.org
```

因此构建未进入 Android Gradle Plugin 编译阶段，未生成 APK 或 AAB。

## 当前环境缺少的工具

| 工具/环境 | 当前状态 |
|---|---|
| Android SDK / ANDROID_HOME / ANDROID_SDK_ROOT | 未安装/未设置 |
| Android Build-Tools（aapt、apksigner、zipalign） | 未找到 |
| Android NDK / llvm-readelf | 未找到 |
| ADB | 未找到 |
| PowerShell | 未找到 |
| Gradle 8.14.6 Wrapper 缓存 | 未缓存，必须联网下载 |
| APK 文件 | 未生成 |
| 已连接 Android 真机 | 当前构建容器不可见 |

容器中只有 OpenJDK 21；项目编译目标仍为 Java 17，云端工作流会单独配置 JDK 17。

## 安装尝试结论

由于没有 APK、ADB 或可访问的 Android 真机，安装步骤无法开始。本轮没有执行 `adb install`，也没有在手机上点击 APK。**因此不能声称已经安装成功。**

## 已添加的替代构建方式

### A. GitHub Actions 云端构建（推荐）

项目包含 `.github/workflows/android-apk.yml`。上传整个工程至用户自己的 GitHub 仓库后，可在手机浏览器中打开 Actions，选择 `Typhoon Lab Android APK` 并运行。云端会配置 JDK 17、Android SDK 36、Build-Tools 36 和 NDK，执行构建与 APK 检查，成功后上传 `TyphoonLab-V7.0.0-Android-Debug-APK` Artifact。

该工作流文件已通过 YAML 结构检查，但**尚未在用户 GitHub 仓库触发实际云构建**。因此 Artifact 尚未产生。

### B. Termux 手机本机编译（实验性）

`PHONE_INSTALL_NO_ANDROID_STUDIO_V7_CN.md` 提供 Termux 方案。它无需 Android Studio 或电脑，但依赖第三方工具和手机本机 SDK/Gradle 下载；没有在 Typhoon Lab V7 上实测成功，不能作为已验证构建渠道。

### C. Windows 命令行构建（不安装 Android Studio）

可只安装 JDK 17、Android SDK Command-line Tools、平台、Build-Tools、NDK 和 Python，然后运行 `tools/build_debug_apk.ps1`。这是命令行构建，不需要 Android Studio IDE。

## 预计 APK 名称与位置（仅在构建成功后）

- 项目 Gradle 原始输出：`app/build/outputs/apk/debug/app-debug.apk`
- Windows/云端整理文件：`dist/TyphoonLab-V7.0.0-debug.apk`

以上是构建脚本定义的预期路径，不代表当前路径下已有 APK。

## 安装安全

- 生成后必须验证包名 `com.typhoonlab.mobile`、版本 `7.0.0-android16-xiaomi`、versionCode `70`、APK 签名和 16 KB 对齐。
- Debug APK 在不同电脑或云端环境可能使用不同的 Debug 证书，不能保证直接覆盖安装 V6.5。
- 安装失败时不要自动卸载旧版；先导出模拟存档并备份离线 PMTiles 地图包，再决定后续操作。
