# Typhoon Lab V6.2.0 源码与模拟审查报告

审查对象：Android 原生工程 `com.typhoonlab.mobile`，versionName `6.2.0-scenario-map-engine`，versionCode `63`，target/compile SDK 36。

## 1. 已执行且通过

| 检查 | 结果 | 说明 |
|---|---|---|
| 台风核心固定步长回归 | PASS | 30/60/90/120 Hz 输入下，10 秒墙钟时间得到相同 300 个 30 Hz 物理步 |
| 模拟时间推进 | PASS | 默认 8× 时累计约 1.333333 小时 |
| 集合预报隔离 | PASS | 打开集合预报不改变主模拟 RNG 后续结果 |
| 风暴数量边界 | PASS | 12 个活动风暴上限行为正确 |
| 高负载模拟 | PASS | 32× 压力用例完成 |
| 全球海盆分类 | PASS | 七大海盆测试通过 |
| 日期变更线轨迹 | PASS | 跨 ±180° 经度拆分线段；无效坐标产生断点 |
| 环境场景预设 | PASS | 五个场景可查找；不重置现有风暴；不改变随机种子 |
| 引导气流持久化 | PASS | 新存档保存方向；旧存档缺字段时回退 290° |
| 环境诊断指数 | PASS | 输入边界和强风切变单调性测试通过 |
| 天气/海洋数据客户端 | PASS | 独立 Kotlin 编译及完整/缺字段 JSON 往返测试通过 |
| Android XML | PASS | `app/src/main` 下 XML 解析通过 |
| 源码审计脚本 | PASS | 版本、Manifest、HTTPS、缓存、60 GB 配额、预设、地图几何与 CI 合约检查通过 |
| Kotlin parser scan | PASS | 未发现语法解析诊断；Android 依赖缺失导致的语义编译仍不能在此环境验证 |
| Python 检查脚本 | PASS | `py_compile` 通过 |
| GitHub Actions 工作流结构 | PASS | workflow_dispatch、API 36 构建、审计步骤和 Artifact 上传步骤均存在；使用 checkout v7 / setup-java v6 / setup-android v4 / upload-artifact v7 |
| ADB 安装助手 | PASS | 单设备安装、多设备保护、显式序列号选择、无自动卸载均通过伪 ADB 测试 |

## 2. 修正的构建检查风险

- APK ZIP 对齐检查与 ELF LOAD 段检查合并为严格流程。
- APK 不包含预期 native `.so` 时不再静默警告通过。
- Windows 构建脚本必须找到 NDK `llvm-readelf` 并通过 ELF 16 KB 检查，之后才复制最终 APK 与计算哈希；不再在 ELF 检查失败时留下看似成功的输出。
- ADB 安装脚本只对单一授权设备或显式指定设备执行 `install -r`，多设备未指定 serial 时停止，不卸载旧应用。
- 包名、versionCode、签名证书、ZIP alignment、ELF LOAD `p_align` 分开核验。

## 3. 环境阻塞与未验证项目

本会话构建容器没有 Android SDK、SDK Manager、Build-Tools、AAPT、APK Signer、Zipalign、NDK 或 ADB。Gradle 8.14.6 不在本地缓存，首次下载依赖外网，但当前容器 DNS 无法解析 Gradle 分发域名。执行 `tools/build_debug_apk.sh` 返回退出码 20，明确提示找不到 Android SDK。

因此，下列项目没有通过，也不能声称通过：

- 完整 `assembleDebug` 编译；
- APK 生成与签名验证；
- 最终 MapLibre `.so` 的 ZIP/ELF 16 KB 对齐；
- Android 16 真机安装、启动、生命周期与长期稳定性；
- GPU 实际 FPS、热量、电池与低内存压力；
- HTTPS 地图下载断点续传实测。

当前输出目录中没有本次新生成的 `.apk` 或 `.aab`。

## 4. 风险边界

静态检查和独立 JVM 模拟测试不能证明零 Bug，也不能代替 Android SDK 全量编译及设备验收。环境预设、支持指数和台风路径均属教学沙盒模型，不是业务预报。高清卫星影像不随工程捆绑，必须使用合法来源 PMTiles v3 离线包。
