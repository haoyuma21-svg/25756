# V6.1.1 APK 构建状态报告

## 结论

**本次没有生成 APK。** 不能在没有 Android SDK、Build Tools 和可用 Gradle 发行包的环境中凭空生成真正可安装的 Android APK，因此本工程没有把 ZIP、HTML 或空文件冒充安装包。

## 实际探测（最终 V6.1.1 源码复核时再次执行）

| 组件 | 本次容器状态 |
|---|---|
| Java | OpenJDK 21.0.12，可用 |
| Kotlin CLI | 可用 |
| Android SDK / SDK Manager | 未安装 |
| Android Build Tools / aapt2 | 未安装 |
| apksigner / zipalign | 未安装 |
| Android NDK / llvm-readelf | 未安装 |
| Gradle 8.14.6 缓存 | 未缓存 |
| Gradle Wrapper 下载 | 失败：DNS 无法解析 `services.gradle.org` |

执行 `./tools/build_debug_apk.sh`，脚本返回 exit code `20`：`BLOCKED: 未找到 Android SDK`。再次执行 `./gradlew --version`，返回 exit code `6`；`curl` 明确返回：`Could not resolve host: services.gradle.org`。因此 Gradle 本身和 Android 插件依赖都无法在此容器中完成引导。最终工作目录内没有生成 `.apk` 或 `.aab` 文件。

## APK 构建方式

在安装 Android Studio、JDK、SDK Platform 36 和 Build-Tools 的电脑上：

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"
./tools/build_debug_apk.sh
```

脚本会：

1. 运行 `clean assembleDebug`。
2. 检查输出 APK 存在且非空。
3. 使用 `apksigner verify` 检查 Debug 签名。
4. 使用 `zipalign -c -P 16` 检查 APK 内未压缩原生库 16 KB zip 对齐。
5. 使用 `readelf` 检查每个 `.so` 的 ELF LOAD 段对齐。
6. 输出 `dist/TyphoonLab-V6.1.1-debug.apk` 与 SHA-256 校验文件。

这会产生可侧载的 Debug APK。Google Play/正式发行还要配置单独的 release 签名密钥，并完成政策及设备测试。


## 安装包阶段之后的补丁

首次 V6.1.0 安装包构建尝试之后，源码追加了 V6.1.1 气象探针历史档案功能（最多 24 条），并在最终复核中补入天气/海洋独立网格坐标、固定 HTTPS 重定向策略、缓存记录校验与 JSON 往返测试。因此最终源码版本为 versionCode 62。最终 V6.1.1 构建脚本已再次实际运行，但环境检查仍阻止进入 Gradle 构建；APK 仍未生成。
