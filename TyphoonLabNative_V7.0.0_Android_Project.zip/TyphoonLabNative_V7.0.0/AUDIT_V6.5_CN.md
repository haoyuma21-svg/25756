# Typhoon Lab V6.5.0 全面大排查报告

审查范围：仅 Android 原生应用（Android 15 / API 35、Android 16 / API 36；小米澎湃 OS / HyperOS、MIUI）。Windows 脚本仅作为 Android APK 构建和安装主机工具，不属于其他应用平台。

## 1. 发布身份与构建配置

| 项目 | 核验值 | 结果 |
|---|---|---|
| applicationId | `com.typhoonlab.mobile` | 通过源码核验 |
| versionName | `6.5.0-android16-xiaomi` | 通过源码核验 |
| versionCode | `65` | 通过源码核验 |
| minSdk | 26 / Android 8.0 | 通过源码核验 |
| compileSdk | 36 | 通过源码核验 |
| targetSdk | 36 / Android 16 | 通过源码核验 |
| Java target | 17 | 通过源码核验 |
| AGP / Kotlin / Gradle | 8.13.2 / 2.3.21 / 8.14.6 | 版本配置核验；未完成 Gradle 项目构建 |
| 地图 SDK | MapLibre Native Android OpenGL 13.7.1 | 依赖声明核验；未完成 APK 链接检查 |

## 2. Android 15 / Android 16 适配审查

- `targetSdk=36`，Android 15（API 35）和 Android 16（API 36）落在目标系统范围。
- 使用 `WindowCompat.setDecorFitsSystemWindows(window, false)` 与 `WindowInsetsCompat` 处理系统栏、显示切口和 IME。
- 启用 AndroidX 返回分发器及预测性返回处理。
- Activity 声明支持方向、屏幕尺寸、最小尺寸、屏幕布局和键盘变化；不锁定方向/宽高比。
- 使用 Storage Access Framework 管理地图包；Manifest 只声明 INTERNET 与 ACCESS_NETWORK_STATE，不申请旧式全盘文件权限。
- Android 15/16 的真实边到边窗口、横竖屏、分屏、返回手势和大屏窗口测试尚未在设备或模拟器执行。

## 3. 澎湃 OS / HyperOS / MIUI 适配审查

- 通过公开 `Build.MANUFACTURER`、`Build.BRAND`、`Build.DISPLAY` 和 `Build.VERSION.INCREMENTAL` 识别系统构建信息。
- 分类器覆盖 HyperOS / 澎湃 OS OS1、OS2、OS3 常见标识、MIUI、小米系但无法识别版本、非小米 Android。
- ROM 分类独立单元测试通过。
- 不调用隐藏小米 API，不申请开机自启动、后台弹窗、悬浮窗或忽略电池优化权限。
- 提供系统应用信息/电池设置入口；用户可在系统设置中调整后台限制。
- 不同地区、运营商和小米设备固件可能隐藏或改变属性；ROM 自动识别属于尽力识别，不等于小米官方认证。
- 未在真实 HyperOS / MIUI 手机上进行安装、后台下载、进程回收或省电策略验收。

## 4. 引擎与地图审查

- 物理引擎保持固定 30 Hz 步长，显示刷新率与物理步长分离。
- 自适应刷新预算只影响装饰性地图标记/几何和仪表盘刷新，不改变物理步长。
- 省电模式、系统热状态、活动风暴数量会调节非关键地图更新。
- 活动风暴上限、集合预报随机流隔离、延迟追赶限制、日期变更线轨迹断开均已纳入核心回归测试。
- PMTiles v3 与 60,000,000,000 字节地图资源配额保留。
- Android Auto Backup / Device Transfer 排除超大 `MapPacks`，防止地图包占用云备份空间。
- 地图实际渲染 FPS、GPU/内存占用、温升、60 GB 文件系统压力和真实离线瓦片读取仍需目标手机实测。

## 5. 安全与权限审查

- 明文流量关闭（`usesCleartextTraffic=false`）。
- Manifest 最小权限为 INTERNET 与 ACCESS_NETWORK_STATE。
- 无开机接收器、无自动启动任务、无悬浮窗/后台弹窗权限。
- 地图文件通过系统文件选择器访问。
- Windows 安装助手校验包名、版本、最低/目标 SDK、签名、设备授权和设备 API。
- 安装助手仅调用 `adb install -r`；不会自动卸载应用或清除数据。
- 多设备时要求明确选择目标设备；未授权设备会阻止安装。

## 6. 实际执行的测试

| 检查 | 实际结果 |
|---|---|
| `tools/tests/audit_v65.py` | 通过 |
| `tools/tests/install_assistant_static_test.py` | 通过 |
| `tools/tests/kotlin_lexical_audit.py` | 通过（10 个 Kotlin 文件；仅词法/括号扫描，不是类型检查） |
| `tools/run_device_compatibility_test.sh` | 通过：HyperOS OS1/OS2/OS3、MIUI、未知小米 ROM、其他 Android、minSdk guard |
| `tools/run_core_smoke_test.sh` | 通过：30/60/90/120 Hz 下均为 300 个物理步；集合隔离、12 风暴上限、32×、七大海盆、日期变更线、延迟限制、环境预设、引导方向、地图轨迹、自适应预算 |
| WeatherProbe JSON 往返测试 | 通过：完整/稀疏/空字段、schema guard、坐标边界、8 KiB 限制 |
| Kotlin parser scan | 通过：未发现 Kotlin 解析语法诊断；Android/AndroidX/MapLibre 语义编译受缺少 SDK 依赖阻塞 |
| Android XML | 6 个 XML 文件解析通过 |
| Shell 脚本语法 | `bash -n` 通过 |
| Python 工具/测试 | `py_compile` 通过 |
| Windows PowerShell | 当前环境无 PowerShell，未执行；仅静态检查 |
| 整套组合审计脚本 | 曾超过单条命令运行时间；拆分后的各独立子测试已逐项执行并通过 |

## 7. APK 构建尝试与真实状态

实际执行：

```text
./gradlew --no-daemon assembleDebug
```

实际结果：

```text
curl: (6) Could not resolve host: services.gradle.org
APK_BUILD_EXIT_CODE=6
```

容器缺少 Android SDK / sdkmanager / Build-Tools / aapt / aapt2 / apksigner / zipalign / NDK / llvm-readelf / adb / PowerShell。Gradle 8.14.6 发行包未缓存，下载因 DNS 失败而无法继续。

再次检查工程目录，没有生成 `.apk` 或 `.aab`。因此：

- 没有可供安装的 APK 文件。
- 没有可供验证的 APK Manifest 或 APK 签名。
- 没有对 MapLibre `.so` 进行最终 ZIP 16 KB 对齐和 ELF LOAD 16 KB 对齐验证。
- 没有 Android 15 / 16 模拟器或真机运行结果。
- 没有 MIUI / HyperOS 真机结果。

## 8. 一键构建与安装助手

Windows Android 构建主机入口：

- `tools/build_and_install_one_click.bat`：先构建、再校验 APK、最后安装。
- `tools/build_debug_apk.ps1`：单独构建与校验。
- `tools/install_one_click.bat` / `tools/install_one_click.ps1`：安装已校验的 APK。

构建门禁检查包名/版本/minSdk/targetSdk、`apksigner`、`zipalign -P 16` 和每个原生库 ELF LOAD 段 16 KB 对齐。检查工具缺失或检查失败时拒绝把 APK 标记为最终产物。

Windows 脚本未能在当前 Linux 容器执行；安装助手静态测试通过。安装脚本只能在有 Android SDK Platform-Tools、ADB、Windows PowerShell 和已授权 Android 手机的 Windows 电脑上使用。

## 9. 最终结论

**源码与可在当前容器执行的独立测试通过；APK 构建未完成，无法宣称已有安装包。**

V6.5 当前交付为 Android-only 工程源码和 Windows 一键构建/安装助手。Android 15 / 16 与 HyperOS / MIUI 已进行源码适配和纯 Kotlin 兼容性测试，但必须在真实系统设备上继续验收。不能将源码审计或模拟核心测试替代 APK 构建、原生库 16 KB 对齐检查及真机测试。
