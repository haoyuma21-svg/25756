# Typhoon Lab V7.0.0 两轮全面检查报告

检查日期：2026-10-31  
版本：`7.0.0-android16-xiaomi` / `versionCode=70`  
包名：`com.typhoonlab.mobile`

## 检查结论

**源代码与测试检查：通过（不等于 APK / 真机验收）**

两轮源码、引擎、设备适配逻辑、数据往返、脚本及发布配置检查均已执行。测试范围内没有发现 Kotlin 解析语法错误或关键模拟回归。**这不是 Android 真机验收，也不是 APK 端到端构建通过报告**：当前构建环境无法下载 Gradle，且没有 Android SDK 与安装工具，因此尚未生成 APK、也未能在实体手机上安装验证。详见 `APK_BUILD_STATUS_V7_CN.md`。

## 第一轮：引擎、玩法和设备适配检查

| 检查项 | 结果 | 实测内容 |
|---|---|---|
| 核心引擎 Smoke Test | 通过 | 30/60/90/120 Hz 输入运行 10 秒均执行 300 个固定物理步；8× 下模拟时间约 1.3333 小时 |
| 高负载和边界 | 通过 | 12 枚活动风暴上限、32× 模拟倍率、有限数值状态、回放帧与事件日志边界 |
| 旧有引擎回归 | 通过 | 集合预报 RNG 隔离、7 个全球海盆、日期变更线分段、卡顿时间夹断、环境预设与引导气流存档 |
| V7 情景挑战 | 通过 | 5 项任务目录、开始时清空上一局模拟状态、目标评分、主台风摇杆默认启用、多风暴初始化、藤原步数持久化 |
| 集合预报诊断 | 通过 | 跨 ±180° 经度的圆周平均、平均离散距离、P90 离散距离 |
| 设备兼容逻辑 | 通过 | HyperOS OS1/OS2/OS3 特征、MIUI、小米未知 ROM、其他 Android、minSdk 下限保护 |
| 天气探针往返测试 | 通过 | 完整/稀疏字段、null 字段、schema 与坐标边界 |
| Kotlin 解析扫描 | 通过（解析层） | 未发现 expecting/unexpected tokens 等解析语法诊断；因缺少 Android/AndroidX/MapLibre 类路径，不能作为类型检查或完整编译结论 |

核心引擎关键实测摘要：

- 刷新率输入：30、60、90、120 Hz。
- 同样 10 秒墙钟时间均得到 300 个物理步；物理步长保持 30 Hz。
- 默认模拟倍率 8× 时，同样时间产生约 1.3333 小时模拟时间。
- 最大活动风暴 12 枚；测试 32× 高倍率及 12 风暴高负载状态没有出现非有限数值。

## 第二轮：发布完整性、配置与文档检查

| 检查项 | 结果 | 实测内容 |
|---|---|---|
| V7 静态发布审计 | 通过 | versionCode 70、versionName、minSdk 26、compile/targetSdk 36、JDK target 17、MapLibre 依赖 |
| Android Manifest 与资源 XML | 通过 | 权限基线、网络明文策略、边到边系统栏/键盘处理相关实现、全部 XML 可解析 |
| 安装助手静态测试 | 通过 | 包名/版本检查、签名检查、`adb install -r`、不自动卸载旧版 |
| Kotlin 词法审计 | 通过 | 12 个 Kotlin 文件的注释、字符串和分隔符平衡 |
| GitHub Actions YAML | 通过 | YAML 结构可解析；手动触发、构建、APK 签名/对齐检查与 Artifact 上传步骤齐全 |
| 工作流动作版本 | 通过 | 使用 checkout v7、setup-java v6、setup-android v4、upload-artifact v7 |
| Shell/Python 脚本语法 | 通过 | bash -n 与 Python py_compile |
| 版本和文档一致性 | 通过 | V7 更新日志、使用手册、手机安装指南、项目状态、脚本引用一致 |
| 压缩包完整性 | 通过 | V7 工程 ZIP 已生成并通过 `unzip -t`；77 个工程文件；隐藏目录 `.github/workflows/` 已包含；未将 APK/AAB 假装打包 |

## 已知限制和未完成项目

1. `./gradlew --no-daemon clean assembleDebug` 已实际执行，但 Gradle Wrapper 无法从 `services.gradle.org` 下载 Gradle 8.14.6，终端返回 DNS 错误：`curl: (6) Could not resolve host: services.gradle.org`。
2. 当前容器没有设置 `ANDROID_HOME` / `ANDROID_SDK_ROOT`，也找不到 Android SDK、Build-Tools、NDK、`adb`、`aapt`、`apksigner`、`zipalign` 或 PowerShell。
3. 未发现 APK/AAB 文件，因此不能执行签名、16 KB ELF 对齐或手机安装验证。
4. HyperOS/MIUI、Android 15/16 目前完成的是源码适配和逻辑测试，未在真实机型上完成认证。
5. Termux 本机编译被列为实验性备选方案，没有对 Typhoon Lab V7 做过手机编译验证。

## 总结

V7.0 的源代码和逻辑测试达到可交付源码工程的检查标准；APK 构建及真机安装仍需在具备 Gradle 网络访问、Android SDK/NDK 或云端 GitHub Actions 的环境中完成。不得把源码测试通过表述为 APK 已成功构建或已安装。
