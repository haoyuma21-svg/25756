# V6.0 最终发布排查报告（三轮审查的最终轮）

检查对象：Typhoon Lab V6.0 源码工程  
applicationId：`com.typhoonlab.mobile`  
versionName：`6.0.0-global-weather-command` / versionCode `60`

## 最终静态审查

| 检查项目 | 结果 | 说明 |
|---|---|---|
| compileSdk / targetSdk | PASS（配置） | 36 / 36，目标 Android 16 |
| minSdk / JVM | PASS（配置） | API 26 / Java 17 bytecode |
| AGP / Gradle / Kotlin | PASS（版本兼容核对） | AGP 8.13.2、Gradle 8.14.6、KGP 2.3.21；版本范围与 API 36 构建相符 |
| Android 16 edge-to-edge | PASS（源码） | WindowCompat + systemBars/displayCutout 安全区 |
| 大屏、折叠与 resize | PASS（源码） | resizable Activity，处理方向、screenSize、smallestScreenSize、screenLayout |
| predictive back | PASS（源码） | AndroidX OnBackPressedDispatcher + manifest 开关 |
| MapView 生命周期 | PASS（源码审查） | start/resume 状态门控、单一 dispose 入口 |
| 自动/手动大存档 | PASS（源码审查） | AtomicFile 原子写入、fsync、备份恢复、旧 SharedPreferences 迁移 |
| 存档安全界限 | PASS（源码审查） | JSON 字符长度和文件字节上限；不将大型状态放入 Binder Bundle |
| 后台导入/下载 UI | PASS（源码审查） | Activity 销毁后不再回调 UI；本地复制响应线程中断 |
| 地图包配额 | PASS（源码审查） | 60,000,000,000 字节；已安装与未完成包均计入；下载计算避免残片重复计数 |
| PMTiles | PASS（源码审查） | 当前接受 PMTiles v3；文件头校验、临时文件和备份替换路径保留 |
| 离线影像图层 | PASS（源码审查） | 切换前清理旧图层/数据源，避免重复叠加 |
| 模拟物理 | PASS（独立核心测试） | 30 Hz 固定步长，显示刷新率不影响物理步数 |
| 物理循环优化 | PASS（源码审查+核心测试） | 活动风暴复用 buffer，共用环境系数每步预计算 |
| 地图渲染优化 | PASS（源码审查） | 风圈/雨带 LOD，历史路径抽稀，移动标记和复杂图层不同频率更新 |
| 集合 RNG 隔离 | PASS（独立核心测试） | 生成集合预报不改变物理演化随机流 |
| 风暴边界 | PASS（独立核心测试） | 活动 12、保留 48、历史轨迹/事件/回放均设上限 |
| 全球气象中心 | PASS（独立核心测试） | 七大海盆聚合、风险/风速/气压统计、日期变更线归类 |
| Android XML | PASS | 4 个 XML 文件解析通过 |
| shell 脚本 | PASS | Gradle wrapper、影像构建、16 KB 检查、源码审计与核心 smoke 脚本语法通过 |
| Kotlin parser scan | PASS（语法层） | 未发现 parser 语法错误；缺少 Android/MapLibre 类路径，完整语义类型检查无法完成 |
| Gradle assemble / APK / AAB | NOT RUN | 当前环境无 Android SDK 与完整 Gradle Android 依赖环境 |
| 16 KB ZIP/ELF alignment | NOT RUN | 必须对最终 APK/AAB 提取出的原生 `.so` 执行脚本检查 |
| Android 16 / 16 KB 真机 | NOT RUN | 当前无对应实体设备或模拟器 |
| GPU FPS / 温度 / 电量 | NOT RUN | 核心算法回归通过不等于实际 GPU 帧率与热功耗验证 |
| HTTPS 真实服务器续传 | NOT RUN | 未针对特定地图包服务器做端到端网络测试 |
| 全球实时观测数据 | NOT INCLUDED | 全球气象中心明确显示本地模拟态势 |
| 全球高清离线卫星影像 | NOT INCLUDED | 用户需自行导入拥有合法使用权的 PMTiles v3 影像包 |

## 三轮审查记录

### 第一轮：更新前基线排查

见 `AUDIT_PRE_V6_CN.md`。在 V5.4 基线上列出 10 项风险，包括 Android 16 targetSdk、edge-to-edge、MapView 生命周期、恢复状态、刷新率耦合、边界检查、地图渲染压力、全球态势缺失和 16 KB 原生库检查。

### 第二轮：功能和更新后全量排查

见 `AUDIT_POST_UPDATE_CN.md`。修正 AtomicFile 存档、后台 UI 回调、导入中断、GeoJSON 重复更新、LOD 和日期变更线分区后，重新运行核心回归。

### 第三轮：最终发布排查

再次检查 Gradle/Manifest 配置、XML、shell 脚本、核心逻辑、地图包配额与文档；无 Kotlin parser 语法错误，所有能在当前环境运行的检查通过。所有未能执行的设备/产物验证均保留为 NOT RUN，不伪装成通过。

## 核心测试结果

使用真实 `StormEngine.kt` 与 `GlobalCommandCenter.kt`，测试时仅以轻量 stub 提供 Android `org.json` API 的签名；此 smoke test不覆盖 JSON 文本的真正解析和恢复：

- 30、60、90、120 Hz 输入分别推进 10 秒：模拟时长约 `1.333333333 h`，全部完成 300 个 30 Hz 物理步；路径与强度在容差内一致。
- 生成 32 条集合路径不扰动物理 RNG。
- 活动风暴 12 个上限、超限拒绝有效。
- 32×模拟速度、4×平移倍率、12 个活动风暴运行 20 秒：风暴经纬度/风速/气压保持有限值，回放和事件记录不超过硬上限。
- 全球 7 海盆聚合、日期变更线分类通过。
- 2 秒异常卡顿被限制并计入 dropped wall time。

可复现命令：`tools/run_core_smoke_test.sh`。源码配置审查：`tools/audit_source_v6.sh`。

## 发布阻断项

**当前状态为“源码交付”，不是 APK 已验收。** 正式发布前必须使用 Android Studio 安装 SDK Platform 36 / Build Tools，执行 Gradle assemble 和 bundle；对最终 APK 运行 `tools/check_apk_16kb_alignment.sh`；再在 Android 16 和 16 KB 页设备完成启动、旋转/折叠、后台恢复、地图导入/续传、长时间模拟和帧率/温度/功耗测试。
