# V6.1 气象探针功能完成后全量排查报告

审查对象：Typhoon Lab V6.1.0 / V6.1.1 源码（Android 原生）  
审查日期：2026-10-31  
审查范围：气象模型客户端、主界面异步调用、缓存/历史档案、网络策略、版本元数据、原生地图资源管理。

## 检查结果

| 检查项目 | 结果 | 说明 |
|---|---|---|
| 版本元数据 | PASS | versionName `6.1.1-weather-probe-archive`，versionCode 62；compile/target API 36，min API 26 |
| Manifest / XML | PASS | XML 可解析；INTERNET 权限存在；明文 HTTP 禁止；Activity 可调整窗口 |
| 气象 URL | PASS（静态） | Forecast 与 Marine 均为固定 HTTPS 主机；不允许 HTTP 明文；拒绝 3xx 重定向 |
| 请求线程 | PASS（源码） | IO 放入单线程 executor；避免同一 Activity 重复并发；UI 结果经安全回调返回 |
| 超时 / 响应大小 | PASS（源码） | connect 12 秒、read 18 秒；读取过程逐块检查 1.5 MB 总响应上限 |
| 用户坐标 | PASS（源码） | 经纬度 finite 与地理范围校验；使用 locale-independent URL 参数格式 |
| 数据缺失处理 | PASS（源码） | 海洋数据可为空；缺失显示“无数据”，不填 0 |
| 网格坐标与时间 | PASS（源码） | 天气网格和海洋网格坐标、模式时间分开展示 |
| 海洋网格选择 | PASS（源码） | 明确请求 `cell_selection=sea`；海流速度按 API 默认 km/h 显示，方向表示流向 |
| HTTP 缓存 / 重定向 | PASS（源码） | 关闭 URLConnection 缓存；固定 API endpoint 不需要跳转，重定向被拒绝 |
| 模拟参数隔离 | PASS（静态） | 外部天气/海洋数值不会自动写入 StormEngine 参数 |
| 本机缓存 | PASS（源码） | 保存最后一次有效查询；异常时可以回退至本机缓存 |
| 历史档案 | PASS（源码） | 最多 24 条、单条 8 KB 上限；坏记录会在写入时清理；可逐条查看和复制 JSON |
| JSON 序列化测试 | PASS | 完整字段与缺失海洋字段往返测试通过；错误 schema、超范围坐标会被拒绝 |
| 离线地图约束 | PASS（静态） | PMTiles v3、HTTPS 下载、Range 校验、60 GB 配额保留 |
| 完整 APK | BLOCKED | 无 Android SDK / Build Tools / apksigner；Gradle Wrapper distribution 无法下载 |
| Android 16 真机 / 16 KB 页 | NOT RUN | 需要 APK 与相应设备或模拟器 |

## 本轮发现并修正

1. 天气网格和海洋网格不一定重合；新增 marine model latitude/longitude 与 marine timestamp 单独存储和展示。
2. 海洋 API 默认使用公制海流速度 km/h；界面以“流向”而不是“来向”标示方向。
3. 海洋请求明确偏好海洋网格单元，避免海岸附近误用陆地单元。
4. 关闭网络缓存，避免“刷新查询”误读 URLConnection 缓存内容。
5. 对固定 HTTPS API 拒绝重定向，避免意外跳转到未预期主机或协议。
6. 缓存恢复增加天气/海洋模式坐标、请求坐标和时间戳边界验证。
7. 历史记录写入前清理损坏或不兼容 JSON，防止坏数据长期占用 24 条配额。
8. 查询进度提示的关闭按钮改为“后台继续”，消除关闭提示却误以为请求取消的歧义。

## 无法执行的检查

当前环境没有 Android SDK、SDK Manager、aapt2、apksigner、zipalign 和 Android NDK；Gradle 8.14.6 发行包也未缓存。完整 Android 工程编译、依赖解析、APK 签名、MapLibre 原生库 ELF 16 KB 对齐和真机运行均不应标成 PASS。

