# V6.5.0 APK 构建状态报告

<badge>当前没有 APK</badge>

结论：**本次环境未能生成 APK 或 AAB。** 已提供 Windows Android 一键构建与安装助手；该助手是电脑侧工具，不是手机安装 APK，也不是已经构建的 APK。

## 本次最终构建尝试

执行命令：

```text
./gradlew --no-daemon assembleDebug
```

结果：

```text
curl: (6) Could not resolve host: services.gradle.org
APK_BUILD_EXIT_CODE=6
```

Gradle 8.14.6 尚未缓存。当前容器无可用 DNS 下载 Gradle 发行包，因此构建在 Gradle 启动前停止，并未进入 Android 编译阶段。

## 本机缺少的工具

- Android SDK / sdkmanager / android.jar
- Build-Tools / aapt / aapt2 / apksigner / zipalign
- Android NDK / llvm-readelf
- Android Platform-Tools / adb
- Windows PowerShell

当前仅有 JDK 21 与 Kotlin CLI；这些无法替代完整 Android Gradle 构建链。

再次检查工程目录，没有发现 `.apk` 或 `.aab` 文件。因此没有可直接安装的文件，也不能验证最终 APK 签名或 16 KB `.so` 对齐。

## 一键构建并安装（Windows 电脑）

1. 安装 Android Studio、JDK 17、Python 3。
2. SDK Manager 安装 Android SDK Platform 36、Build-Tools、Platform-Tools 与 Android NDK。
3. 手机开启 USB 调试并授权电脑。
4. 解压工程，双击 `tools/build_and_install_one_click.bat`。
5. 脚本先运行 Gradle `assembleDebug`，再检查 APK 包名、版本、minSdk、targetSdk、签名、ZIP 16 KB 对齐和所有原生 `.so` ELF LOAD 段 16 KB 对齐；全部通过才会执行安装。

单独构建：`tools/build_debug_apk.ps1`

单独安装：`tools/install_one_click.bat`

输出目标：`dist/TyphoonLab-V6.5.0-debug.apk`

安装器只执行 `adb install -r`，不会自动卸载旧应用或清除数据；签名不同会拒绝覆盖。多台设备连接时需要选择目标设备。

## 状态边界

- 源码审查与独立模拟测试通过不代表 APK 构建成功。
- 当前没有 APK，因此签名、aapt Manifest、zipalign 和 ELF 16 KB 检查尚未实际运行。
- Windows PowerShell 脚本在本环境无 PowerShell 的情况下只完成静态检查，尚未执行。
- Android 15、Android 16、MIUI 和澎湃 OS 真机验收尚未执行。
