# V6.1.1 最终超级大排查报告

检查对象：Typhoon Lab Android 原生项目  
applicationId：`com.typhoonlab.mobile`  
versionName：`6.1.1-weather-probe-archive`  
versionCode：`62`  
检查日期：2026-10-31

## 最终核验结果

| 检查类别 | 结论 | 可复现证据 / 限制 |
|---|---|---|
| 版本配置 | PASS | build.gradle.kts versionCode 62 / versionName 6.1.1 |
| Android API 目标 | PASS（配置） | min 26 / compile 36 / target 36 |
| Gradle / AGP / Kotlin | PASS（静态兼容核对） | AGP 8.13.2 / Gradle 8.14.6 / Kotlin Gradle Plugin 2.3.21；完整依赖同步未执行 |
| Manifest 安全 | PASS（静态） | INTERNET 权限；usesCleartextTraffic=false；exported launcher Activity |
| Android XML | PASS | 所有 `app/src/main/**/*.xml` 由 Python ElementTree 解析 |
| Shell 脚本语法 | PASS | Wrapper、地图包生成、16 KB 检查、Debug 构建、审计和核心测试脚本 `bash -n` |
| Python 静态审计 | PASS | version、API target、网络 endpoint、超时、响应上限、历史、60 GB、PMTiles v3 等断言通过 |
| WeatherModelClient 编译 | PASS（独立 JVM） | Kotlin CLI 编译 WeatherModelClient + 本地 org.json 测试兼容层；不是 Android app compile |
| 气象快照 JSON 往返 | PASS | 完整/缺失海洋字段数据 round-trip、错误 schema、超范围纬度拒绝测试通过 |
| StormEngine / GlobalCommandCenter | PASS（独立 JVM 回归） | 30/60/90/120 Hz 输入一致、300 固定物理步、ensemble RNG 隔离、12 风暴限制、32×压力、七大海盆、日期变更线与 lag clamp |
| MapPackManager | PASS（源码静态） | 60 GB decimal quota、HTTPS、Content-Range、PMTiles v3；未做 Android SAF/真服务器大文件 E2E |
| MainActivity Kotlin parser scan | PASS（语法级） | 无 `expecting` / unexpected token 等 parser 语法错误；缺 AndroidX/MapLibre classpath，无法做完整语义类型检查 |
| Gradle assembleDebug | BLOCKED | 未安装 Android SDK；Gradle distribution 下载因 DNS 失败 |
| APK 签名 / ZipAlign / ELF 16 KB | NOT RUN | 没有真实 APK、Build-Tools 和 NDK |
| Android 16 / 16 KB 真机 | NOT RUN | 没有对应设备/模拟器 |
| GPU FPS / 热 / 电池 | NOT RUN | 需在真机测量，不以帧回调频率代替 GPU FPS |
| 实时 API 集成测试 | NOT RUN | 当前容器网络不可用于端到端验证；只完成 API schema 源码与本地 JSON 测试 |

## 可执行审查结果

### 静态和源代码审计

运行：

```bash
./tools/audit_source_v6.sh
```

输出包含：
- `V6.1.1 SOURCE AUDIT PASS`
- `SHELL_SYNTAX_PASS`
- `WEATHER PROBE ROUND-TRIP TEST PASSED full=sparse=null-fields=schema-guard=coordinate-guard=PASS`
- `V6 CORE SMOKE TEST PASSED`

### 模拟核心回归

运行：

```bash
./tools/run_core_smoke_test.sh
```

结果：

```text
rates=[30, 60, 90, 120]Hz
simulatedHours=1.3333333333333373
physicsSteps=300
ensembleIsolation=PASS
stormCap=PASS
highLoad32x=PASS
globalBasins=7
datelineSeam=PASS
lagClamp=PASS
```

### Kotlin 主界面语法扫描

使用本机 Kotlin CLI 对 MainActivity、StormEngine、GlobalCommandCenter、MapPackManager、WeatherModelClient 进行 parser scan。因未提供 Android / AndroidX / MapLibre 编译 classpath，编译会报告大量 `unresolved reference`；本轮没有发现 Kotlin parser `expecting`、unexpected token 等语法诊断。该结果不能代替 Android Gradle 类型检查。

## APK 构建尝试

按用户要求在“APK 阶段”运行 `tools/build_debug_apk.sh`。脚本因缺少 `ANDROID_SDK_ROOT` / Android SDK 返回 exit code 20。随后检查 Gradle Wrapper，Gradle 8.14.6 未缓存，容器 DNS 无法解析 `services.gradle.org`，故无法下载发行包和 Android 插件依赖。

**当前交付是 V6.1.1 Android Studio 工程 ZIP，不是 APK。** 没有用空文件、ZIP 或 HTML 冒充 APK。APK、签名、16 KB 原生库、Android 16 真机安装都保持 BLOCKED / NOT RUN。

## 剩余发布门槛

1. 在联网 Android Studio 环境安装 SDK Platform 36、Build-Tools 35.0.0+、JDK 17+ 和 NDK。
2. 完成 Gradle sync 与 `clean assembleDebug`。
3. 对真实 APK 执行 `apksigner verify`、`zipalign -c -P 16` 和每个 `.so` ELF LOAD 段 16 KB 对齐检查。
4. 在 Android 16 设备验证 Edge-to-Edge、返回手势、旋转/窗口尺寸变化、MapView 生命周期、离线影像导入和缓存恢复。
5. 对天气与海洋 API 执行在线集成测试，并核对服务许可、署名与数据源选择。
6. 执行至少 30 分钟长时间模拟，记录真实 GPU FPS、内存、热和电池消耗。

