# Typhoon Lab V6.5.0 — Android 专项大更新

版本名：`6.5.0-android16-xiaomi`  
versionCode：`65`  
包名：`com.typhoonlab.mobile`

## 1. Android 设备适配中心

- 显示 Android API/版本、厂商/品牌/机型、ROM 构建标识、屏幕刷新率、内存档位、系统 RAM、内存页大小、省电状态与应用目录可用空间。
- 通过公开 Build 字段识别 HyperOS/澎湃 OS、MIUI、未知小米 ROM，不调用隐藏厂商接口。
- 提供应用信息与 Android 电池优化设置入口；不自动打开白名单。
- 不注册开机自启动、不请求后台弹窗/悬浮窗/电池优化白名单权限。

## 2. Android 15 / 16 界面与系统适配

- `compileSdk/targetSdk=36`、`minSdk=26`。
- Edge-to-edge 与 Insets 覆盖系统栏、刘海/挖孔、软键盘及安全区域。
- AndroidX 预测性返回、横竖屏、窗口尺寸变化与大屏重新布局。
- 使用 SAF 文件选择器管理离线地图，无旧式全盘存储权限。
- 重点目标为 Android 15（API 35）、Android 16（API 36）；MIUI/澎湃 OS 适配遵循公开 Android API 与系统设置流程。

## 3. 引擎自适应性能

- 新增 `AdaptiveFrameBudget`，每 2 秒读取一次省电模式与系统热状态，并结合活动风暴数量计算地图标记、地图几何、仪表盘刷新间隔。
- 修正 Android 热状态值映射：LIGHT=1、MODERATE=2、SEVERE=3、CRITICAL=4 及更高状态。
- 热状态或负载过高时优先降低装饰性地图层更新频率，物理模拟固定 30 Hz 不变。

## 4. 超大地图数据保护

- 增加 Android Auto Backup / Device Transfer 排除规则，MapPacks 目录不会被数十 GB 的地图包占用云备份或设备迁移容量。
- 模拟设置与小型存档保持系统备份能力。

## 5. 一键构建与安装助手

- Windows `.bat` 一键构建并安装；分离的 PowerShell 构建/安装助手。
- 安装前校验包名、版本、minSdk、targetSdk、签名及设备 API。
- 显示设备型号、Android 版本、MIUI/HyperOS 系统属性；多设备时要求显式选择。
- 仅执行 `adb install -r`，绝不自动卸载或清除用户数据。
- APK 构建成功门禁包含 APK 签名、ZIP 16 KB 对齐和 ELF LOAD 16 KB 对齐。

## 6. 已知限制

- 本开发容器缺 Android SDK/Build-Tools/NDK/ADB 且 Gradle 分发下载受 DNS 限制；本次未能生成 APK。
- 小米 ROM 识别根据公开构建信息，无法保证覆盖所有区域/运营商定制版。
- 兼容性代码尚未在真实 Android 15/16、HyperOS/MIUI 机型上验收。
- MapLibre `.so` 的最终 16 KB ELF 兼容性必须从构建 APK 实测，不能由源码配置推断。
