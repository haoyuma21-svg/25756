# Typhoon Lab V7.0.0 手机端安装指南（不需要 Android Studio）

## 先分清两个文件

工程 ZIP 是 Kotlin/Gradle 源码，**不是 APK**，不能直接点击 ZIP 安装。需要先生成 `TyphoonLab-V7.0.0-debug.apk`，再由 Android 安装器安装。

V7 提供两条无 Android Studio 路线。推荐路线 A：手机浏览器触发云端构建，手机只下载并安装 APK；路线 B：在 Android 手机的 Termux 内本机编译，属于高级实验方案。

## 路线 A：GitHub 云端构建（推荐，手机端只负责触发和安装）

### 第一次准备工程

1. 在 GitHub 创建自己的私有仓库。
2. 将 V7 工程文件上传到仓库根目录。需要包含隐藏目录 `.github/workflows/`。
3. 如果手机文件选择器隐藏了 `.github`，可在 GitHub 网页切换“桌面版网站”，用 **Add file → Create new file** 新建文件 `.github/workflows/android-apk.yml`，把工程 ZIP 内同名文件的完整内容粘贴进去并提交。
4. 提交所有文件。不要把密码、签名密钥或令牌写入源码仓库。

### 手机浏览器生成 APK

1. 手机浏览器登录自己的 GitHub 仓库。
2. 打开仓库的 **Actions** 页面。
3. 选择 **Typhoon Lab Android APK** 工作流。
4. 点击 **Run workflow → Run workflow**。
5. 打开刚创建的运行记录，等待步骤全部成功并显示绿色勾。
6. 到记录页面底部的 **Artifacts**，下载 `TyphoonLab-V7.0.0-Android-Debug-APK`。
7. 在手机文件管理器中解压下载的 ZIP，得到 `TyphoonLab-V7.0.0-debug.apk` 和 `.sha256` 校验文件。
8. 点击 `.apk` 文件安装。若系统提示，临时允许当前浏览器或文件管理器“安装未知应用”。安装完可以关闭该来源授权。

### Android 15/16、HyperOS/MIUI

- 设置中搜索“安装未知应用”，仅给本次下载 APK 所使用的浏览器或文件管理器授权。
- 小米官方说明的常见路径为“设置 → 安全与隐私 → 更多安全与隐私 → 特殊权限 → 安装未知应用”；不同 HyperOS/MIUI 版本可能略有不同。可参考[小米官方安装未知应用说明](https://www.mi.com/global/support/faq/details/KA-06974/)。
- 如遇风险提示，先核对下载来源、APK 文件名和 SHA-256，再决定是否继续。不要为安装应用而关闭整机安全防护。
- 若出现“应用未安装”或签名冲突，通常是设备上已有同包名 APK 的签名与新 APK 不同。请先导出游戏存档并备份自己导入的 PMTiles 地图包，再决定是否卸载旧版。不同 Debug 环境生成的证书可能不同，不能保证覆盖升级。

## 路线 B：Termux 手机本机编译（高级实验路线）

此路线不需要电脑、Android Studio 或 Root，但比路线 A 复杂，且**目前没有在 Typhoon Lab V7 项目上实机验证**。它依赖第三方开源 Termux Studio 工具；其公开说明要求 Android 11+、ARM64/aarch64 设备和约 3 GB 可用空间。请先阅读其仓库、许可证和安装脚本，再自行决定是否使用。

工具项目：<https://github.com/poordevcode/termux-android-studio>
Termux 建议从 F-Droid 或 Termux 官方 GitHub 获取，不要使用已过时的 Play 商店版本。

### 大致操作

1. 安装 Termux，打开后执行：

```bash
pkg update -y
pkg install -y git unzip
termux-setup-storage
```

2. 把 `TyphoonLabNative_V7.0.0_Android_Project.zip` 下载到手机“Download/下载”目录，并复制到 Termux 私有目录后解压。示例：

```bash
mkdir -p ~/TyphoonLabV7
cp ~/storage/downloads/TyphoonLabNative_V7.0.0_Android_Project.zip ~/TyphoonLabV7/
cd ~/TyphoonLabV7
unzip TyphoonLabNative_V7.0.0_Android_Project.zip
```

3. 按该工具仓库的最新 README 安装 Termux Studio。其仓库给出的安装方式是：

```bash
git clone https://github.com/poordevcode/termux-android-studio.git ~/termux-studio
bash ~/termux-studio/install.sh
source ~/.bashrc
studio doctor
```

4. 进入解压后的项目根目录（必须能看到 `settings.gradle.kts`、`gradlew` 和 `app/`），先备份工程，再让工具检查/适配：

```bash
cd ~/TyphoonLabV7/TyphoonLabNative_V7.0.0
studio load "$PWD"
```

5. 尝试构建 Debug APK：

```bash
studio build "$PWD" :app:assembleDebug
```

6. 如果构建成功，APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。检查文件存在后，用手机文件管理器打开 APK，通过系统安装器完成安装。也可以根据 Termux Studio 的当前版本说明使用 `studio run`。

**重要限制：** Termux Studio 是第三方工具，不是 Android 官方产品；其公开 README 的通用功能说明不代表 Typhoon Lab 这个组合（AGP 8.13.2、Kotlin 2.3.21、MapLibre Native、SDK 36、NDK）已经通过验证。若构建时报错，不要随意删除工程文件或降低 SDK/AGP 版本；保存完整错误日志，优先改用路线 A。

## 不使用 Android Studio 的电脑构建方法

Windows 电脑也可只装 JDK 17、Android SDK Command-line Tools、Android Platform 36、Build-Tools 36、NDK 和 Python 3，然后运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\build_debug_apk.ps1
```

不需要安装 Android Studio 图形界面。Android 官方亦提供[命令行 Gradle 构建方式](https://developer.android.com/build/building-cmdline)，以及独立 SDK 命令行工具，无需安装完整 Android Studio IDE。

## 重要安全与兼容说明

- 当前云端工作流生成的是 Debug APK，供测试使用，不是 Play 商店发布版。
- 工作流会检查包名、版本、签名、ZIP 16 KB 对齐和 native ELF LOAD 段对齐；检查失败就不会上传 APK。
- 云端构建通过不代表已在真实 Android 15/16、HyperOS 或 MIUI 设备上实机验收。
- APK 不含全球离线 PMTiles 地图数据；地图数据需另外准备。
- 如果你只拿到工程 ZIP，没有 APK，正确操作不是点击 ZIP 安装，而是先按路线 A 生成 APK，或尝试路线 B 本机编译。
