# Typhoon Lab V6.2.0 更新日志

版本号：`6.2.0-scenario-map-engine`  
versionCode：`63`  
applicationId：`com.typhoonlab.mobile`（保持不变，便于同签名证书下覆盖升级）

## 新功能

1. **环境场景预设**：新增西北太平洋有利增强、强风切变抑制、近岸登陆演练、冷海温干燥、季风槽扰动五组预设。只修改环境设置，不清除或重置当前风暴。预设是教学沙盒参数，不代表实时环境。
2. **环境支持诊断**：新增 0–100 环境支持指数，综合海温、湿度、海洋热含量、风切变和是否位于陆地。它是可解释的游戏诊断分数，不是快速增强概率或真实强度预报。
3. **环境引导气流方向**：自动路径不再固定朝 290°偏转，而是趋近用户设置的引导方向；`steeringFlow` 决定转向响应强度。手动摇杆控制仍优先。
4. **跨日期变更线轨迹分段**：历史轨迹从 +180° 跨到 -180° 时断开为两段，避免一条线横穿整张世界地图。无效坐标会形成断点，不会与相邻有效坐标误连。
5. **APK 自动构建通道**：加入 GitHub Actions 手动/推送构建工作流和 Windows PowerShell 构建脚本；输出带本机 Debug 签名、可侧载的 APK，构建后执行签名与 ZIP 16 KB 对齐检查。

## 模拟与兼容优化

- 加入 steeringHeadingDeg 存档字段；旧版存档缺少该字段时自动使用 290°，保持 V6.1.1 存档向前兼容。
- 引导方向角使用最短角差计算，跨越 0°/360° 时不会绕远路转向。
- 保留固定 30 Hz 物理步长、独立集合预报 RNG、12 个活动风暴上限和 32× 模拟倍率。
- 保持 applicationId `com.typhoonlab.mobile` 不变，versionCode 从 62 增加到 63。
- 保持 MapLibre Native、PMTiles v3 和 60 GB 地图资源配额格式不变。


## 安装包流水线加固

- GitHub Actions 更新为 checkout v7、setup-java v6、setup-android v4、upload-artifact v7，并启用 Gradle 依赖缓存。
- Linux/macOS 构建脚本使用 Python 进行 Build-Tools/NDK 工具版本选择，避免依赖 GNU `sort -V` 与 `find -maxdepth`。
- Windows 构建脚本在所有检查通过后才复制 APK 和生成 SHA-256。
- APK 需同时通过包名/versionCode/versionName、签名、ZIP 16 KB 对齐和每个 `.so` 的 ELF LOAD 16 KB 检查；缺少 ELF 检查工具时拒绝标记成功。

## 已执行测试

- V6 核心固定步长测试：30/60/90/120 Hz 相同输入输出一致。
- 环境预设边界与强风切变指数单调性测试。
- 引导方向会影响自动路径、状态导出/恢复会保留引导方向。
- 日期变更线轨迹分段和无效坐标断点测试。
- Android XML、源代码审计、Kotlin 语法扫描和 ZIP 完整性检查。

完整 Android APK 构建需要 Android SDK Platform 36、Build-Tools 和可访问 Gradle/Maven 仓库的环境。本会话容器没有 Android SDK，且当前 DNS 无法解析 Gradle 下载域名；因此未声称已生成 APK。工程内 `.github/workflows/android-apk.yml` 可在用户的 GitHub Actions 环境生成 APK artifact。
