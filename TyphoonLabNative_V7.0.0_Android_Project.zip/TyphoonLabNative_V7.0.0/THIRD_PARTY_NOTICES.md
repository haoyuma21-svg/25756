# 第三方组件与数据署名说明

## 软件依赖

- MapLibre Native Android：项目通过 Maven 依赖 `org.maplibre.gl:android-sdk-opengl` 引入。请在发布 APK 时随包保留对应版本的 BSD 2-Clause License 及其依赖的许可证声明。
- AndroidX / Material Components：由项目构建系统从 Google Maven 仓库获取，按其各自开源许可证发布。

本项目没有把第三方地图瓦片或卫星影像数据打包进 APK。

## 离线影像数据

影像 PMTiles 由使用者自行制作或导入。请确保来源授权允许下载、离线存储、派生处理及预期分发。若使用 Copernicus Sentinel 数据，按具体数据产品和 Copernicus Data Space 的使用条款保留必要声明；派生影像建议记录采集时间、产品 ID、处理步骤及 `Contains modified Copernicus Sentinel data [year]` 署名。

不要将禁止离线下载或再分发的商业地图瓦片批量抓取后制作成地图包。

## 气象数据服务（V6.1，可选联网）

- Open-Meteo Forecast API：应用在用户主动查询时请求天气模型网格数据。
- Open-Meteo Marine API：应用在用户主动查询时请求海洋模型变量。
- 服务文档：https://open-meteo.com/en/docs 与 https://open-meteo.com/en/docs/marine-weather-api
- 数据展示处保留 Open-Meteo 来源链接及模型提供方说明。使用者应遵守服务当前许可、署名、请求频率和商业使用条款；商业部署前应重新核验条款及套餐。
- Marine API 底层海洋产品的提供方随区域/变量而异，官方文档列出的来源包括 Copernicus Marine Service、ECMWF、NOAA/NCEP、DWD，以及 ERA5-Ocean / Copernicus Climate Change Service；具体模型以 API 选择结果和文档为准。
- 天气和海洋产品是模式估算/预报，并非现场测量或官方热带气旋业务分析。海平面高度在部分近岸/内陆位置精度有限，不应用于航海导航。
